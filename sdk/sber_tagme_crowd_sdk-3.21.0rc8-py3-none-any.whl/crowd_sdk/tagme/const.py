from datetime import date, timedelta
from enum import Enum
from typing import Optional, Tuple

TASK_SUBMIT_DATETIME_FORMAT = '%Y-%m-%dT%H:%M:%S.%fZ'  # "2022-05-19T06:13:08.963332Z"


class PeriodEnum(Enum):
    all = 'all'
    yesterday = 'yesterday'
    exact_date = 'exact_date'
    period = 'period'

    def get_start_and_end_date(
        self, exact_date: Optional[date] = None, date_start: Optional[date] = None, date_end: Optional[date] = None
    ) -> Tuple[Optional[date], Optional[date]]:
        if self is self.all:
            return None, None

        if self is self.yesterday:
            yesterday = date.today() - timedelta(days=1)
            return yesterday, yesterday

        if self is self.exact_date:
            if exact_date:
                return exact_date, exact_date
            if date_start and date_end and date_start == date_end:
                return date_start, date_end
            raise ValueError('For --period="exact_date" you need to specify --exact_date parameter')

        if date_start is None or date_end is None:
            raise ValueError(f'Period configuration error: specify --date-start {date_start} and --date-end {date_end}')

        if date_start > date_end:
            raise ValueError(f'Period configuration error: --date-start {date_start} > --date-end {date_end}')
        return date_start, date_end
