from crowd_sdk.tagme.http_client.client import (
    DEFAULT_CONFIG,
    ProjectConfig,
    TagmeBotClient,
    TagmeClient,
    TagmeClientAdvanced,
)
from crowd_sdk.tagme.http_client.stats_client import TagmeStatsClient
from crowd_sdk.tagme.http_client.sync_client import TagmeSyncClient

from .config import TagmeConfig

CrowdTagmeConfig = TagmeConfig
