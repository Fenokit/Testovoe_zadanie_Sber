from typing import Optional

import click

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced
from crowd_sdk.tagme.cli.group import tagme_commands
from crowd_sdk.tagme.config import TagmeConfig


async def clone_pool(
    config: TagmeConfig,
    pool_id: str,
    src_organization_id: Optional[str] = None,
    dst_organization_id: Optional[str] = None,
    move: bool = False,
) -> str:
    async with TagmeClientAdvanced(config) as client:
        pool = await client.clone_pool(
            pool_id=pool_id, organization_id=src_organization_id, dst_organization_id=dst_organization_id
        )
        if move:
            await client.delete_pool(pool_id=pool_id, organization_id=src_organization_id)
    return pool.uid


@tagme_commands.command(name='clone_pool')
@click.option('-p', '--pool-id', required=True)
@click.option('-o', '--organization-name', required=False, help='Organization key to clone pool from')
@click.option('--organization-id', required=False, help='Organization id to clone pool from')
@click.option('--target-organization-id', required=False, help='Organization to clone pool to')
@click.option('-m', '--move', required=False, is_flag=True)
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
def clone_pool_cli(
    pool_id: str,
    organization_name: Optional[str],
    organization_id: Optional[str],
    target_organization_id: str,
    move: bool,
    config_path: str,
) -> str:
    """
    clone users pool. If pool in another organization needed, add them to organization.
    use -o parameter to specify target organization
    use -m flag to remove source pool
    """
    config = TagmeConfig.cli_initialize(config_path, organization_name, organization_id)
    pool_id = get_event_loop().run_until_complete(
        clone_pool(
            config,
            pool_id=pool_id,
            src_organization_id=organization_id,
            dst_organization_id=target_organization_id,
            move=move,
        )
    )
    return pool_id
