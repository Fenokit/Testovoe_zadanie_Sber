import logging
from pathlib import Path
from typing import Optional, Tuple, Union

import click

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.tagme.cli.group import tagme_commands
from crowd_sdk.tagme.config import DEFAULT_CONFIG, TagmeConfig
from crowd_sdk.tagme.utils.pipeline import TagmePipeline

logger = logging.getLogger(__name__)


@tagme_commands.command(name='pipeline_sync')
@click.option('-o', '--organization', required=False, help='Organization key')
@click.option('-t', '--task-id', 'task_ids', required=False, help='Filter by tasks (multiple allowed)', multiple=True)
@click.option(
    '-p', '--project-id', 'project_ids', required=False, help='Filter by projects (multiple allowed)', multiple=True
)
@click.option('--dry-run', is_flag=True, default=False, help='Do not copy data, just print actions')
@click.option('--limit', required=False, help='Limit files to be uploaded', type=int)
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
@click.option('-n', '--batch-size', type=int, help='Number of parallel tasks to process', default=4)
@click.option('-e', '--executor', help='Executor name to filter tasks', default='cli')
def pipeline_sync_cli(
    organization: Optional[str],
    task_ids: Optional[Tuple[str]],
    project_ids: Optional[Tuple[str]],
    dry_run: bool,
    limit: Optional[int],
    config_path: Union[str, Path],
    batch_size: int,
    executor: str,
) -> None:
    """
    Run sync for tasks in pipelines
    Task configuration details in README.md
    """
    config = TagmeConfig.from_any(config_path)
    config.prompt_user_and_password_if_missing()
    config.org = organization or config.org

    get_event_loop().run_until_complete(
        pipeline_sync_cli_(
            config,
            task_ids=task_ids,
            project_ids=project_ids,
            dry_run=dry_run,
            limit=limit,
            batch_size=batch_size,
            executor=executor,
        )
    )


async def pipeline_sync_cli_(
    config: TagmeConfig,
    task_ids: Optional[Tuple[str]],
    project_ids: Optional[Tuple[str]],
    dry_run: bool,
    limit: Optional[int],
    batch_size: int,
    executor: str,
) -> None:
    pipe = TagmePipeline(executor=executor, config=config)
    logger.info(f'Pipeline will process org={config.org}')
    if not project_ids:
        project_ids = None

    tasks = await pipe.scan_tasks(task_ids=task_ids, project_ids=project_ids)
    await pipe.process_tasks(tasks, dry_run=dry_run, limit=limit, batch_size=batch_size)


@tagme_commands.command(name='pipeline_serve')
@click.option('-o', '--organization', required=False, help='Organization key')
@click.option('-t', '--task-id', 'task_ids', required=False, help='Filter by tasks (multiple allowed)', multiple=True)
@click.option(
    '-p', '--project-id', 'project_ids', required=False, help='Filter by projects (multiple allowed)', multiple=True
)
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
@click.option('-e', '--executor', help='Executor name to filter tasks', default='cli')
@click.option('-d', '--scan_delay', type=int, help='Delay between scans', default=600)
def pipeline_serve_cli(
    organization: Optional[str],
    task_ids: Optional[Tuple[str]],
    project_ids: Optional[Tuple[str]],
    config_path: Union[str, Path],
    executor: str,
    scan_delay: int,
) -> None:
    """
    Run sync for tasks in pipelines
    Task configuration details in README.md
    """
    config = TagmeConfig.from_any(config_path)
    config.prompt_user_and_password_if_missing()
    config.org = organization or config.org

    get_event_loop().run_until_complete(
        pipeline_serve_cli_(
            config,
            task_ids=task_ids,
            project_ids=project_ids,
            executor=executor,
            scan_delay=scan_delay,
        )
    )


async def pipeline_serve_cli_(
    config: TagmeConfig,
    task_ids: Optional[Tuple[str]],
    project_ids: Optional[Tuple[str]],
    executor: str,
    scan_delay: int,
) -> None:
    pipe = TagmePipeline(executor=executor, config=config, scan_delay=scan_delay)
    logger.info(f'Pipeline will process org={config.org}')
    if not project_ids:
        project_ids = None

    await pipe.run(task_ids=task_ids, project_ids=project_ids)
