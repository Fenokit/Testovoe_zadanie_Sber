#!/usr/bin/env python3
""" Console util for toloka managing """

import logging
from typing import List

import click

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.cv.upload_pdf import upload_pdf_cli
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced, TagmeConfig, types
from crowd_sdk.tagme.cli.bad_control import bad_control_delete_cli, bad_control_search_cli
from crowd_sdk.tagme.cli.clone_from_toloka import clone_from_toloka_cli
from crowd_sdk.tagme.cli.clone_pool import clone_pool_cli
from crowd_sdk.tagme.cli.clone_project import clone_project_cli
from crowd_sdk.tagme.cli.create_tests import qa_cli
from crowd_sdk.tagme.cli.download_task_data import download_dataset_data_cli, download_task_data_cli
from crowd_sdk.tagme.cli.download_task_datatable import download_task_datatable_cli
from crowd_sdk.tagme.cli.download_task_results import download_task_attachments_cli, download_task_results_cli
from crowd_sdk.tagme.cli.extend_task_results import extend_task_results_cli
from crowd_sdk.tagme.cli.find_projects import find_projects_by_predicate_cli
from crowd_sdk.tagme.cli.get_quality_stats import get_quality_stats_cli
from crowd_sdk.tagme.cli.group import tagme_commands
from crowd_sdk.tagme.cli.import_skills import export_skills_cli, import_skills_cli
from crowd_sdk.tagme.cli.pipeline import pipeline_serve_cli, pipeline_sync_cli
from crowd_sdk.tagme.cli.survey_summarizer import survey_summarizer_cli
from crowd_sdk.tagme.cli.upload_task_data import upload_dataset_data_cli, upload_task_data_cli

logger = logging.getLogger(__name__)


@tagme_commands.command(name='projects_list')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
@click.option('-a', '--archived/--visible', type=bool, help='Show list archived/visible projects', default=False)
def projects_list_cli(config_path: str, archived: bool) -> None:
    """
    Download dataset from task to specified directory
    """
    config = TagmeConfig.from_any(config_path)
    config.prompt_user_and_password_if_missing()
    projects: List[types.Project] = get_event_loop().run_until_complete(
        TagmeClientAdvanced(config=config_path).get_projects()
    )
    empty = True
    for project in projects:
        if project.is_archived ^ archived:
            continue
        empty = False
        logger.info(f'[archived={project.is_archived}] [uid={project.uid}] [name={project.name}]  {project.pools}')
    if empty:
        logger.info('Project list is empty')


tagme_commangs_collection = click.CommandCollection(
    sources=[
        clone_from_toloka_cli,
        clone_pool_cli,
        clone_project_cli,
        download_task_data_cli,
        download_task_results_cli,
        upload_task_data_cli,
        upload_dataset_data_cli,
        extend_task_results_cli,
        projects_list_cli,
        get_quality_stats_cli,
        pipeline_sync_cli,
        pipeline_serve_cli,
        import_skills_cli,
        upload_pdf_cli,
        bad_control_search_cli,
        bad_control_delete_cli,
        download_task_datatable_cli,
        download_dataset_data_cli,
        export_skills_cli,
        download_task_attachments_cli,
        survey_summarizer_cli,
        qa_cli,
        find_projects_by_predicate_cli,
    ]
)


def main() -> None:
    logging.basicConfig(
        format='%(message)s',
        level=logging.INFO,
    )
    tagme_commands()


if __name__ == '__main__':
    main()
