import json
import logging
from typing import Optional

import click

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced, TagmeConfig
from crowd_sdk.tagme.cli.group import tagme_commands
from crowd_sdk.tagme.types import FileType, TaskData, TaskFile, UpdateMetaDataRequest

logger = logging.getLogger(__name__)


async def get_task_data(tagme_client: TagmeClientAdvanced, task_id: str) -> TaskData:
    task = await tagme_client.get_task(task_id=task_id)
    print('----------')
    print('Task name:', task.name)
    print('Task description:', task.description)
    print('----------')
    return task


async def get_file_data(tagme_client: TagmeClientAdvanced, task_id: str, file_id: str) -> Optional[TaskFile]:
    file = await tagme_client.get_file(task_id, file_id)
    file_data = await tagme_client.download_file(task_id, file_id)
    metadata = await tagme_client.get_meta_data(task_id, file_id)
    print(metadata)
    try:
        data = json.loads(file_data)
        print('Data:', json.dumps(data, ensure_ascii=False, indent=2))
    except json.JSONDecodeError:
        print(f'The file {file.name} is binary')
        return None
    print('File ID:', file_id)
    print('----------')

    if not file.metadata or not file.metadata[0]:
        print('File has no control info')
        return None
    if not file.enabled:  # the file is issued to markers
        print('File already disabled')
        return None
    return file


async def remove_control(tagme_client: TagmeClientAdvanced, task: TaskData, file_id: str) -> None:
    flag = False
    try:
        if task.state.value == 'RUNNING':
            print(f'Stopping task {task.uid}')
            await tagme_client.stop_task(task.uid)  # stops the task if it was active
            flag = True

        print(f'Remove control item {file_id}')
        await tagme_client.disable_control_task(task.uid, file_id)  # disable this file
        file = await tagme_client.get_file(task.uid, file_id)  # update file info
        assert file.enabled is False  # the file is not issued to markers

    finally:
        if flag:
            print(f'Run task {task.uid}')
            await tagme_client.start_task(task.uid)  # starts a stopped task if it was active


async def bad_control_delete(config: TagmeConfig, task_id: str, file_id: str) -> None:
    client = TagmeClientAdvanced(config=config)
    try:
        task = await get_task_data(client, task_id=task_id)
        file = await get_file_data(client, task_id=task.uid, file_id=file_id)
        if not file:
            return
        user_input = input(f'Are you shure to delete the file {file.name} above? (yes/no): ')
        if user_input.lower() in ('y', 'yes'):
            await remove_control(client, task, file_id)
        else:
            print(f'Will not delete the file {file.name}')
    finally:
        await client.close()


async def fix_control_tasks(config: TagmeConfig, task_id: str) -> None:
    client = TagmeClientAdvanced(config=config)
    try:
        task = await get_task_data(client, task_id=task_id)
        task_files = await client.get_task_files(task.uid, types=[FileType.CONTROL, FileType.STUDY])

        for item in task_files:
            metadata = await client.get_meta_data(task_id, item.uid, item.metadata)
            assert metadata.control, f'Search for control task, got no meta control information for {item}'
            changed = False
            for k, v in metadata.control.items():
                if not isinstance(v, str):
                    continue
                if v.lower() == 'true':
                    changed = True
                    metadata.control[k] = True
                elif v.lower() == 'false':
                    changed = True
                    metadata.control[k] = False
                else:
                    try:
                        metadata.control[k] = float(v)
                        changed = True
                    except ValueError:
                        pass
            if changed:
                await client.update_meta_data(task_id, [UpdateMetaDataRequest(fileId=str(item.uid), data=metadata)])
    finally:
        await client.close()


async def bad_control_search_in_task(
    client: TagmeClientAdvanced, task_id: str, rate_threshold: float = 0.5, count_threshold: Optional[int] = None
) -> None:
    task = await client.get_task(task_id=task_id)
    result = await client.get_bad_control_items(task, rate_threshold, count_threshold)

    for row in result:
        print('')
        file = await get_file_data(client, task_id, row['item_id'])
        print('Контрольный ответ:', row['control'])
        print('Процент верных ответов:', 100 * row['rate'])
        print('Ответы пользователей:', json.dumps(row['user_answers'], ensure_ascii=True, indent=2))
        print('----------')
        if not file:
            continue
        user_input = input(f'Удалить контролку {file.name} описанную выше? (yes/no): ')
        if user_input.lower() in ('y', 'yes'):
            await remove_control(client, task, row['item_id'])
        else:
            print(f'Не удалил {file.name}')


async def bad_control_search(
    config: TagmeConfig,
    task_id: Optional[str] = None,
    project_id: Optional[str] = None,
    rate_threshold: float = 0.5,
    count_threshold: Optional[int] = None,
) -> None:
    client = TagmeClientAdvanced(config=config)
    try:
        if task_id and project_id:
            raise ValueError('Specify only one: task_id or project_id')
        if not task_id and not project_id:
            raise ValueError('Specify one of: task_id or project_id')

        if task_id:
            await bad_control_search_in_task(client, task_id=task_id)
        elif project_id:
            for task in await client.get_tasks(project_id=project_id):
                await bad_control_search_in_task(client, task.uid, rate_threshold, count_threshold)
    finally:
        await client.close()


@tagme_commands.command(name='bad_control_delete')
@click.option('-t', '--task-id', required=True, help='Task id')
@click.option('-f', '--file-id', required=True, help='File id')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
def bad_control_delete_cli(task_id: str, file_id: str, config_path: str) -> None:
    """
    Delete specified control item
    """
    config = TagmeConfig.from_any(config_path)
    config.prompt_user_and_password_if_missing()
    get_event_loop().run_until_complete(bad_control_delete(config, task_id, file_id))


@tagme_commands.command(name='bad_control_search')
@click.option('-t', '--task-id', help='Task id')
@click.option('-p', '--project-id', help='Project id')
@click.option('-r', '--rate-threshold', default=0.5, type=int, help='Project id')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
def bad_control_search_cli(task_id: str, project_id: str, rate_threshold: int, config_path: str) -> None:
    """
    Search, show and ask for deletion control items with low good answers ratio
    """
    config = TagmeConfig.from_any(config_path)
    config.prompt_user_and_password_if_missing()
    get_event_loop().run_until_complete(bad_control_search(config, task_id, project_id, rate_threshold))


@tagme_commands.command(name='fix_control_data')
@click.option('-t', '--task-id', help='Task id', required=True)
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
def fix_control_tasks_cli(task_id: str, config_path: str) -> None:
    """
    Download dataset from task to specified directory
    """
    config = TagmeConfig.from_any(config_path)
    config.prompt_user_and_password_if_missing()
    get_event_loop().run_until_complete(fix_control_tasks(config, task_id))
