import csv
import json
import logging
import sys
import tempfile
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple, Union
from uuid import uuid4

import click

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced, TagmeConfig
from crowd_sdk.tagme.cli.group import tagme_commands

logger = logging.getLogger(__name__)
MAX_SIZE = 500 * 1024 * 1024


def get_filepaths(dirs: Sequence[Union[str, Path]], files: Sequence[Union[str, Path]]) -> Tuple[List[Path], List[dict]]:
    errors = []
    filepaths = []
    if dirs is not None:
        for directory in dirs:
            directory = Path(directory)
            filenames = list(directory.iterdir())

            for filename in filenames:
                if str(filename).startswith('.'):
                    continue

                file_size = filename.stat().st_size
                if file_size > MAX_SIZE:
                    errors.append(
                        {
                            'filename': filename,
                            'status': 413,
                            'error': f'File {filename} is too large. Maximum size {MAX_SIZE}, actual size {file_size}',
                        }
                    )
                    continue
                filepaths.append(filename)

    for file in files:
        filepaths.append(Path(file))
    return filepaths, errors


async def upload_metadata(
    config: TagmeConfig,
    file: Union[str, Path],
    task_id: str,
    organization_id: Optional[str],
) -> None:
    with open(file, 'r') as f:
        meta_data = json.load(f)
    async with TagmeClientAdvanced(config) as client:
        await client.update_meta_data(task_id, meta_data, organization_id)


async def async_upload(
    config: TagmeConfig,
    task_id: str,
    dirs: Tuple[Union[str, Path]],
    files: Tuple[Union[str, Path], ...] = (),
    meta_path: Union[str, Path, None] = None,
    organization_id: Optional[str] = None,
) -> None:
    async with TagmeClientAdvanced(config) as client:
        logger.info('Preprocessing uploading info.')
        filepaths, errors = get_filepaths(dirs, files)
        if filepaths:
            result = await client.upload_files(task_id, filepaths, organization_id=organization_id)
            uploaded = len(result.created_files)

            logger.info(f'\nFiles successfully uploaded {uploaded}/{len(errors) + len(filepaths)}')

        if errors:
            error_text = 'Upload errors: \n'
            for e in errors:
                error_text += f"{e['filename']}: \n\tStatus code: {e['status']} \n\t{e['error']}\n"
            logger.info(error_text)

        if meta_path:
            with open(meta_path, 'r') as f:
                meta_data = json.load(f)
            await client.update_meta_data(task_id, meta_data, organization_id=organization_id)


async def async_ds_upload(
    config: TagmeConfig,
    dataset_id: str,
    dirs: Tuple[Union[str, Path]],
    files: Tuple[Union[str, Path], ...] = (),
    organization_id: Optional[str] = None,
) -> None:
    logger.info('Preprocessing uploading info.')
    filepaths, errors = get_filepaths(dirs, files)
    if filepaths:
        async with TagmeClientAdvanced(config) as client:
            result = await client.upload_dataset_files(dataset_id, filepaths, organization_id=organization_id)
        uploaded = len(result.created_files)

        logger.info(f'\nFiles successfully uploaded {uploaded}/{len(errors) + len(filepaths)}')

    if errors:
        error_text = 'Upload errors: \n'
        for e in errors:
            error_text += f"{e['filename']}: \n\tStatus code: {e['status']} \n\t{e['error']}\n"
        logger.info(error_text)


async def upload_task_data(
    config: TagmeConfig,
    task_id: str,
    dialog_path: Union[str, Path],
    meta_path: Union[str, Path, None],
    organization_id: Optional[str] = None,
) -> None:
    def __row_to_message(_row_data: dict) -> Dict[str, str]:
        message = {
            'author': _row_data.get('initiator', ''),
            'text': _row_data.get('message', ''),
            'id': str(uuid4()),
        }
        if 'date' in _row_data:
            message['date'] = _row_data['date']
        return message

    with open(dialog_path, 'r') as f:
        dict_reader = csv.DictReader(f)

    logger.info('Merging dialogs')
    dialogs: Dict[str, List[Dict[str, str]]] = {}
    for row_num, row_data in enumerate(dict_reader, start=2):
        dialog_id = row_data.get('dialogId')
        if dialog_id is None or dialog_id == '':
            logger.error(f'Invalid CSV file on row {row_num}')  # each CSV file row needs 'id' field
            sys.exit(1)

        messages: list = dialogs.setdefault(dialog_id, [])
        messages.append(__row_to_message(row_data))

    async with TagmeClientAdvanced(config) as client:
        if meta_path:
            with open(meta_path, 'r') as f:
                meta_data = json.load(f)
            await client.update_meta_data(task_id, meta_data, organization_id=organization_id)

        with tempfile.TemporaryDirectory() as tmpdirname:
            tmp_path = Path(tmpdirname)
            logger.info(f'created temporary directory: {tmp_path}')

            for d_id, d_value in dialogs.items():
                if '/' in d_id:
                    d_id = ''.join(d_id.split('/'))

                with open(tmp_path / f'{d_id}.json', 'w') as f:
                    json.dump({'messages': d_value}, f)

            dirs = (tmp_path,)

            await async_upload(client, task_id, dirs, organization_id=organization_id)  # type: ignore[arg-type]


@tagme_commands.command(name='upload_metadata')
@click.option(
    '-t',
    '--task-id',
    required=True,
    help='Task id to upload file',
)
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
@click.option('-f', '--file', 'file', type=click.Path(exists=True), help='Metadata file path')
@click.option('-o', '--organization-name', required=False, help='Organization key')
@click.option('--organization-id', required=False, help='Organization id')
def upload_metadata_cli(
    config_path: Union[str, Path],
    task_id: str,
    file: str,
    organization_name: Optional[str],
    organization_id: Optional[str],
) -> None:
    """
    Upload metadata for files
    """
    config = TagmeConfig.cli_initialize(config_path, organization_name, organization_id)

    get_event_loop().run_until_complete(upload_metadata(config, file, task_id, organization_id))
    logger.info("Metadata uploaded successfully")


@tagme_commands.command(name='upload')
@click.option(
    '-t',
    '--task-id',
    required=True,
    help='Task id to upload file',
)
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
@click.option('-tagme1', 'dialog_path', type=click.Path(exists=True), help='Dialogs old format from tagme 1.x support')
@click.option('-m', '--meta_path', help='Meta data file', default=None)
@click.option('-d', '--dir', 'dirs', type=click.Path(exists=True), multiple=True, help='Directory paths')
@click.option('-f', '--file', 'files', type=click.Path(exists=True), multiple=True, help='File paths')
@click.option('-o', '--organization-name', required=False, help='Organization key')
@click.option('--organization-id', required=False, help='Organization id')
def upload_task_data_cli(
    config_path: Union[str, Path],
    dialog_path: Optional[str],
    task_id: str,
    meta_path: Optional[str],
    dirs: Tuple[str],
    files: Tuple[str],
    organization_name: Optional[str],
    organization_id: Optional[str],
) -> None:
    """
    Upload files script
    """

    if dialog_path is not None and (dirs or files):
        logger.error('While uploading TagMe 1.x dialogs it is forbidden to upload other files')
        sys.exit(1)

    config = TagmeConfig.cli_initialize(config_path, organization_name, organization_id)
    if dialog_path is not None:
        logger.info('Start to upload TagMe 1.x dialogs')
        get_event_loop().run_until_complete(
            upload_task_data(
                config,
                task_id,
                dialog_path,
                meta_path,
                organization_id=organization_id,
            )
        )
        sys.exit()

    if not dirs and not files:
        logger.error('Upload files or directories were not specified!')
        sys.exit(1)

    get_event_loop().run_until_complete(
        async_upload(
            config,
            task_id,
            dirs,
            files,
            organization_id=organization_id,
        )
    )


@tagme_commands.command(name='upload_dataset')
@click.option(
    '-s',
    '--dataset-id',
    required=True,
    help='Task id to upload file',
)
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
@click.option('-d', '--dir', 'dirs', type=click.Path(exists=True), multiple=True, help='Directory paths')
@click.option('-f', '--file', 'files', type=click.Path(exists=True), multiple=True, help='File paths')
@click.option('-o', '--organization-name', required=False, help='Organization key')
@click.option('--organization-id', required=False, help='Organization id')
def upload_dataset_data_cli(
    config_path: Union[str, Path],
    dataset_id: str,
    dirs: Tuple[str],
    files: Tuple[str],
    organization_name: Optional[str],
    organization_id: Optional[str],
) -> None:
    """
    Upload files script
    """

    config = TagmeConfig.cli_initialize(config_path, organization_name, organization_id)

    if not dirs and files:
        logger.error('Upload files or directories were not specified!')
        sys.exit(1)

    get_event_loop().run_until_complete(
        async_ds_upload(
            config,
            dataset_id,
            dirs,
            files,
            organization_id=organization_id,
        )
    )
