from dataclasses import dataclass
from enum import Enum
from typing import Any, List, Optional, Tuple


@dataclass
class TaskQuality:
    uid: str
    name: str
    items_count: int
    quality: Optional[float]
    consistency: Optional[float]
    reward: float
    complete_data: bool = True


@dataclass
class ItemQuality:
    uid: str
    task_id: str
    quality: Optional[float]
    consistency: float
    reward: Optional[float]
    complete_data: bool = True


class StatsOutputType(Enum):
    TASK = 'task'
    ITEM = 'item'


class ConsistencyFilter(Enum):
    ALL_UNIQUE = 'all_unique'
    UNSURE = 'unsure'


class ResultAggregation(Enum):
    AGGREGATE = 'aggregate'
    SEPARATE = 'separate'


class AggregatedResults(list):
    def add(self, weight: float, result: Any) -> None:
        self.append(dict(weight=weight, result=result))

    def __getitem__(self, item: Any) -> 'AggregatedResults':
        if not isinstance(item, str):
            return super().__getitem__(item)

        new = AggregatedResults()
        for i in self:
            new.add(weight=i['weight'], result=i['result'][item])

        return new


@dataclass
class SyncSettings:
    fields: List[Tuple[str, str]]
    source_task: Optional[str] = None
    source_project: Optional[str] = None
    result_aggregation: ResultAggregation = ResultAggregation.SEPARATE
    consistency_filter: ConsistencyFilter = ConsistencyFilter.ALL_UNIQUE
    consistency_share_threshold: Optional[float] = None
    ignore_fields: Optional[List[str]] = None
    result_filter: str = 'all'
    executor: Optional[str] = None
    auto_create_task: bool = True
    auto_start_task: bool = False
    base_task: Optional[str] = None

    def __post_init__(self) -> None:
        assert (
            self.source_task or self.source_project
        ), 'Pipelines config should contain source_task or source_project value'

        if self.consistency_filter == ConsistencyFilter.UNSURE and self.consistency_share_threshold is None:
            assert False, 'missing `consistency_share_threshold` value for `unsure` consistency filter'

        if any(not x.startswith('result.') for x in self.ignore_fields or []):
            assert False, 'every field in `ignore_fields` should start with \'result.\''
