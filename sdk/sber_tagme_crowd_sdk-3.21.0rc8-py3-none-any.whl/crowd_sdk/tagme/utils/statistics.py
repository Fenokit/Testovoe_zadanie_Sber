import hashlib
import logging
import re
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import DefaultDict, Dict, List, Optional, Set, Tuple, Union

import aiohttp
from tqdm import tqdm

from crowd_sdk.core.utils.common import chunks
from crowd_sdk.db import DataBase
from crowd_sdk.db.config import CrowdConfig, DBConfig
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeStatsClient
from crowd_sdk.tagme.types import Assignment, Person, Project, TaskData

logger = logging.getLogger(__file__)

DATE_PATTERN = '%Y-%m-%d'
FORMAT = '%(message)s'

INSERT_HEADER = """
INSERT INTO events (stand, org_name, project_name, project_id, project_date, task_name, task_id, tags,
                    overlap, consistency, have_quality_control, control_passed, item_id,
                    assignment_id, start, finish, user_id, status, price)
VALUES """

EVENTS_QUERY = """
SELECT * FROM events
WHERE status != 'accepted' AND finish >= '{}' {}
"""


@dataclass
class SimpleOrganization:
    name: str
    uid: str


@dataclass
class PoolData:
    name: str
    uid: str
    person_id: str
    organization_id: str
    members_count: int


@dataclass
class PoolMarker:
    uid: str
    person_id: str


@dataclass
class UserItem:
    user_id: str
    fio: str
    email: str
    role: str


@dataclass
class EventItem:
    stand: str
    org_name: str
    project_name: str
    project_id: str
    task_name: str
    task_id: str
    overlap: int
    item_id: str
    assignment_id: str
    start: datetime
    finish: datetime
    user_id: str
    status: str
    price: Optional[float]
    project_date: Optional[datetime]
    accepted_at: Optional[datetime] = None
    tags: Optional[list] = None
    consistency: Optional[float] = None
    have_quality_control: bool = False
    control_passed: Optional[float] = None

    @staticmethod
    def from_assignment(
        assignment: Assignment, stand: str, task: TaskData, project: Project, org_name: str
    ) -> 'EventItem':
        control_passed = None

        if isinstance(assignment.control_passed, bool):
            control_passed = 1 if assignment.control_passed else 0

        tags = [tag.strip() for tag in re.split(';,.!?\t]', project.inner_comment) if tag]

        if assignment.result and 'themes' in assignment.result:
            tags += assignment.result['themes']
        assert assignment.end_date

        return EventItem(
            stand=stand,
            user_id=assignment.marker_id,
            item_id=assignment.item_id,
            task_id=assignment.task_id,
            assignment_id=make_assignment_id(assignment),
            start=assignment.start_date,
            finish=assignment.end_date,
            status=assignment.status.lower(),
            price=assignment.price,
            consistency=assignment.consistency,
            have_quality_control=assignment.control_passed is not None,
            control_passed=control_passed,
            org_name=org_name,
            project_id=project.uid,
            project_name=project.name,
            project_date=project.created_date,
            tags=tags,
            overlap=task.overlap,
            task_name=task.name,
            accepted_at=assignment.accepted_at,
        )


@dataclass
class TaskStatItem:
    task_id: str
    day: str
    assignments_count: int
    time_spent: Optional[float] = None


@dataclass
class TaskItem:
    task_id: str
    task_name: str
    objects_count: int
    marked_count: int
    download_completed: bool
    downloaded_count: int
    stand: str
    org_name: str
    url: str
    skill_id: Optional[str]
    project_id: Optional[str]
    author_id: Optional[str]
    author_email: Optional[str]
    task_type: Optional[str]
    data_type: Optional[str]
    created: Optional[datetime]
    finish: Optional[datetime]
    last_event: Optional[datetime]
    avg_mark_time: Optional[float]
    price: Optional[float] = 0

    def completed(self) -> bool:
        return self.downloaded_count >= self.objects_count

    def nothing_to_do(self, marked_count: int) -> bool:
        return self.marked_count >= marked_count


def make_assignment_id(assignment: Assignment) -> str:
    if assignment.assignment_id:
        return assignment.assignment_id
    s = assignment.marker_id + assignment.item_id + str(assignment.start_date)
    return hashlib.md5(s.encode('utf-8')).hexdigest()


def get_dict(d: dict) -> dict:
    if 'marks' in d and isinstance(d['marks'], list):
        for mark in d['marks']:
            if isinstance(mark, dict) and 'id' in mark:
                del mark['id']
    return d


def day_normalize(date: str) -> str:
    if date == 'today':
        return datetime.now().strftime(DATE_PATTERN)
    if date == 'yesterday':
        return (datetime.now() - timedelta(days=1)).strftime(DATE_PATTERN)
    if date:
        return date
    raise ValueError('date can\'t be None or empty')


class StatsCollector:
    """
    Collect TagMe markup events statistics
    """

    def __init__(
        self,
        stand: str = 'Cloud',
        verbose: bool = False,
        db_config: Union[str, Path, CrowdConfig, DBConfig] = DEFAULT_CONFIG,
    ) -> None:
        self._stand = stand
        self._projects: dict = {}
        self._orgs: dict = {}
        self._db: DataBase = DataBase(db_config)
        self._client = TagmeStatsClient()
        self._tasks: Dict[str, TaskData] = {}
        self._users: dict = {}
        self._project_configs: dict = {}
        logging.basicConfig(level=logging.DEBUG if verbose else logging.INFO, format=FORMAT)

        self.__init_dbs()

    def __init_dbs(self) -> None:
        logger.info('Loading db...')
        logger.info('Initialize cache data: projects, project_meta, users, pools')

        for user in self._db.select_dataclass('SELECT * FROM users', UserItem, tqdm_off=True):
            self._users[user.user_id] = user

    async def __get_project(self, project_id: str) -> Project:
        project = self._projects.get(project_id)
        if project:
            return project

        project = await self._client.get_project(
            project_id=project_id,
        )
        self._projects[project.uid] = project
        return project

    async def __get_task_data(self, task_id: str, force: bool = False) -> TaskData:
        task = self._tasks.get(task_id)
        if task and not force:
            return task

        task = await self._client.get_task(task_id)
        self._tasks[task_id] = task
        return task

    async def __get_organizations(self) -> List[SimpleOrganization]:
        orgs = await self._client.get_organizations()
        orgs = list(filter(lambda org: org.is_demo is not True, orgs))
        return list(map(lambda org: SimpleOrganization(name=org.name, uid=org.uid), orgs))

    async def update_task_data(self, last_days: int = 2, org_key: Optional[str] = None) -> None:
        """
        Update information about tasks, projects, pools and markers in pools
        """
        update_date_from = (datetime.now() - timedelta(days=last_days)).strftime(DATE_PATTERN)

        projects: List[Project] = []
        pools: List[PoolData] = []
        pool_markers: List[PoolMarker] = []

        organizations = await self.__get_organizations()
        if org_key:
            organizations = list(
                filter(lambda organization: org_key in (organization.uid, organization.name), organizations)
            )

        tasks: List[TaskData] = []

        for org in tqdm(organizations, "Collecting tasks"):
            tasks.extend(
                await self._client.get_tasks(
                    organization_id=org.uid,
                    update_date_from=update_date_from,
                )
            )

        for org in tqdm(organizations, "Collecting projects"):
            projects.extend(
                await self._client.get_projects(
                    organization_id=org.uid,
                    update_date_from=update_date_from,
                )
            )

        pool_ids: Set[Tuple[str, str]] = set()
        for project in projects:
            pool_ids.update(set((pool_id, project.organization_id) for pool_id in project.pools))

        tasks_stats = await self._client.get_list_task_statistics(update_date_from=update_date_from)
        old_task_ids = set(t.uid for t in tasks)
        task_ids_to_exclude = set(t.task_id for t in tasks_stats if t.task_id not in old_task_ids)
        task_ids = [task.uid for task in tasks if task.uid not in task_ids_to_exclude]
        for task_ids_ in chunks(task_ids, 100, "Collecting tasks stats"):
            tasks_stats.extend(await self._client.get_list_task_statistics(task_ids=task_ids_))
        for task_id in task_ids_to_exclude:
            tasks.append(await self._client.get_task(task_id))
        task_to_stat = {stat.task_id: stat for stat in tasks_stats}

        for task in tqdm(tasks, "Setting tasks stats"):
            stat = task_to_stat.get(task.uid, None)
            task.estimated_files_count = stat.total_objects_count if stat else 0

        for pool_id, organization_id in tqdm(pool_ids, "Processing pools"):
            try:
                pool = await self._client.get_pool(pool_id, with_markers=True)
            except aiohttp.ClientResponseError as exc:
                if exc.status != 404:
                    raise
                logging.warning(f'Error while getting pool {pool_id} org={organization_id}: {exc}')

            pool_data = PoolData(
                uid=pool.uid,
                name=pool.name,
                members_count=pool.members_count or 0,
                organization_id=pool.organization_id or organization_id,
                person_id=pool.person_id,
            )
            pools.append(pool_data)
            pool_markers.extend([PoolMarker(uid=pool_id, person_id=member.uid) for member in pool.members])

        self._db.upload_dataclass('tagme_orgs', organizations, conflict_err=False, conflict_upd=True)
        self._db.upload_dataclass('tagme_task', tasks, conflict_err=False, conflict_upd=True)
        self._db.upload_dataclass('tagme_project', projects, conflict_err=False, conflict_upd=True)
        self._db.upload_dataclass('tagme_groups', pools, conflict_err=False, conflict_upd=True)
        self._db.upload_dataclass('tagme_pool_marker', pool_markers, conflict_err=False, conflict_upd=True)

    async def run(self, org: Optional[str] = None, last_days: int = 2) -> None:
        """
        Run stats collection for the all available organizations for 'last_days'
        """
        for i in reversed(range(last_days)):
            day = (datetime.now() - timedelta(days=i)).strftime(DATE_PATTERN)
            await self.collect_date(org, day)

        await self.update_statuses(org=org)
        await self.update_task_data(last_days, org)

    async def collect_date(self, org: Optional[str] = None, date: str = 'today') -> None:
        """
        Run stats collection for the current time for all orgs and all tasks
        """
        logger.info(f'Collect organization statistics {date}')
        for o in await self.__get_organizations():
            if org != 'all' and org and org not in (o.uid, o.name):
                continue
            date = day_normalize(date)
            await self.__collect_org(o, date)

    async def __get_db_task_stats(self, day: str) -> Dict[str, Tuple[int, Optional[float]]]:
        task_stats = self._db.select_dataclass(
            f'SELECT * FROM task_day_stat WHERE day=\'{day}\';', TaskStatItem, tqdm_off=True
        )
        return {item.task_id: (item.assignments_count, item.time_spent) for item in task_stats}

    async def __set_db_task_stats(self, day: str, data: dict) -> int:
        task_stats = []
        for task_id, stats in data.items():
            assignments_count, time_spent = stats
            task_stats.append(
                TaskStatItem(
                    task_id=task_id,
                    day=day,
                    assignments_count=assignments_count,
                    time_spent=time_spent,
                )
            )
        return self._db.upload_dataclass(
            'task_day_stat', task_stats, conflict_err=False, conflict_upd=True, tqdm_off=True
        )

    async def __update_users(self, events: List[EventItem]) -> None:
        person_ids = list(set(event.user_id for event in events))
        persons: List[Person] = []
        for person_ids_ in chunks(person_ids, 100, tqdm_on="Collecting persons"):
            persons.extend(await self._client.get_persons(person_ids=person_ids_))
        users: List[UserItem] = []
        for person in persons:
            users.append(
                UserItem(
                    user_id=person.uid,
                    fio=person.first_name + ' ' + person.last_name,
                    email=person.email,
                    role='marker',
                )
            )
        self._db.upload_dataclass('users', users, conflict_err=False, conflict_upd=True, tqdm_off=True)

    async def __collect_org(self, org: SimpleOrganization, date: str) -> None:
        logger.info(f"Collecting date {date} for organization {org.name}")
        cache: Dict[str, Dict] = {'stats': {date: await self.__get_db_task_stats(date)}, 'events': {}}
        cache, _statuses = await self._client.collect_org_events(date, cache=cache, organization_id=org.uid)

        logger.info(f"{date} Collected org events for organization {org.name}")

        events = []
        for task_id, assignments in cache['events'].get(date, {}).items():  # type: ignore
            task = await self.__get_task_data(task_id=task_id)
            project = await self.__get_project(project_id=task.project_id)
            for assignment in assignments:
                events.append(EventItem.from_assignment(assignment, self._stand, task, project, org.name))

        self._db.upload_dataclass('events', events, conflict_err=False, conflict_upd=True, tqdm_off=True)

        await self.__update_users(events)
        await self.__set_db_task_stats(date, cache['stats'].get(date, {}))  # type: ignore

    def __collect_events_to_update(self, last_days: int = 21, org: Optional[str] = None) -> List[EventItem]:
        org_statement = f"AND org_name = '{org}'" if org is not None and org != "all" else ""
        end_date = (datetime.now() - timedelta(days=last_days)).strftime(DATE_PATTERN)
        query = EVENTS_QUERY.format(end_date, org_statement)
        db_result = self._db.select_dataclass(query, EventItem, tqdm_off=True)
        return list(db_result)

    async def __collect_events_statuses(self, task_id: str, events: List[EventItem], date_from: str) -> List[EventItem]:
        assignments = await self._client.get_task_assignments(task_id=task_id, date_from=date_from)
        assignment_to_status = {item.assignment_id: item.status for item in assignments if item.assignment_id}

        result: List[EventItem] = []
        for event in events:
            new_status = assignment_to_status.get(event.assignment_id, event.status)
            if event.status.lower() != new_status.lower():
                event.status = new_status
                result.append(event)
        return result

    def __update_one_status_batch(self, status: str, assignment_ids: List[str]) -> int:
        ids_list = f'({",".join(assignment_ids)})'
        query = f"update events set status = '{status}' where assignment_id in {ids_list}"
        rows_affected = self._db.custom_query(query)
        return rows_affected

    def __update_one_status(self, status: str, assignment_ids: List[str]) -> None:
        rows_affected = 0
        for assignment_ids_ in chunks(
            assignment_ids, 100, tqdm_on=f'Uploading new events with status "{status}" to database'
        ):
            rows_affected += self.__update_one_status_batch(status, assignment_ids_)
        logger.info(f'Updated {rows_affected} out of {len(assignment_ids)} events!')

    def __update_events_statuses(self, events: List[EventItem]) -> None:
        formatted_assignments_by_status: DefaultDict[str, Set[str]] = defaultdict(set)
        for event in events:
            formatted_assignments_by_status[event.status.lower()].add(f"'{event.assignment_id}'")

        for status, assignment_ids in formatted_assignments_by_status.items():
            if not assignment_ids:
                continue
            self.__update_one_status(status, list(assignment_ids))

    async def update_statuses(self, last_days: int = 21, org: Optional[str] = None) -> None:
        logger.info('Collecting events from database...')
        events_to_update = self.__collect_events_to_update(last_days, org)
        logger.info(f'Got {len(events_to_update)} events')

        events_by_task: DefaultDict[str, List[EventItem]] = defaultdict(list)
        for event in events_to_update:
            events_by_task[event.task_id].append(event)

        date_from = (datetime.now() - timedelta(days=last_days)).strftime(DATE_PATTERN)
        result: List[EventItem] = []
        for task_id, events in tqdm(events_by_task.items(), "Processing tasks"):
            result.extend(await self.__collect_events_statuses(task_id, events, date_from))
        logger.info(f'{len(result)} events need to be updated')

        self.__update_events_statuses(result)

    async def close(self) -> None:
        await self._client.close()
