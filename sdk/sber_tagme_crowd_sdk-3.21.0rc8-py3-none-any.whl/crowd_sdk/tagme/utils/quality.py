import hashlib
import logging
from collections import defaultdict
from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Union

import tqdm
from aiohttp import ClientResponseError
from Levenshtein import distance as levenshtein_distance

from crowd_sdk.tagme.types import ItemQuality, MetaData, MetaType, TaskData, TaskQuality, TaskResult, TaskState

if TYPE_CHECKING:
    from crowd_sdk.tagme import TagmeClientAdvanced

logger = logging.getLogger(__name__)


async def get_items_quality(task: TaskData, client: "TagmeClientAdvanced") -> List[ItemQuality]:
    logger.info(('task:', task.uid, task.state))
    if task.payload is None:
        logger.warning(f'missing payload of task {task.uid}')

    quality_config = parse_config(task.payload)
    results = await client.get_task_results(task_id=task.uid)

    if not results or not any(len(x.result) for x in results):
        return []

    logger.info(('items', len(results)))
    assign_per_items: Dict[tuple, int] = defaultdict(int)
    for r in results:
        assign_per_items[(len(r.result), len(r.skip or {}))] += 1

    logger.info(('assignments per items', dict(assign_per_items)))
    logger.info(f'files: {task.estimated_files_count} // overlap: {task.overlap}')

    try:
        filelist = await client.get_task_files(task.uid)
        meta_map = {x.uid: x.metadata for x in filelist}

    except ClientResponseError as e:
        if e.status != 403:
            raise

        logger.info('No access to file listing, progress can be slower')
        meta_map = {}

    items_meta = [
        (
            x,
            (
                await client.get_meta_data(task.uid, x.entity_id, types=[MetaType.CONTROL])
                if MetaType.CONTROL in meta_map.get(x.entity_id, [MetaType.CONTROL])
                else None
            ),
        )
        for x in tqdm.tqdm(results, 'loading meta')
        if x.result
    ]

    items_quality = [get_item_quality(item, meta, task, quality_config) for item, meta in items_meta]

    return items_quality


def parse_config(payload: Optional[dict]) -> 'QualityConfig':
    if not payload or 'quality' not in payload:
        algorithms = {'*': DEFAULT_ALGORITHM}
        config = QualityConfig(algorithms=algorithms)

    else:
        payload = payload['quality']
        assert isinstance(payload, dict)
        algorithms = payload.get('algorithms', {})
        assert isinstance(algorithms, dict), 'invalid quality algorithms in task payload'

        for v in algorithms.values():
            if v.upper() not in ALGORITHM_MAP:
                raise KeyError(f'`{v}` not in algorithm map, possible values: {",".join(ALGORITHM_MAP.keys())}')

        if '*' not in algorithms:
            algorithms['*'] = DEFAULT_ALGORITHM

        fields = payload.get('ignore_fields')
        config = QualityConfig(algorithms=algorithms, ignore_fields=fields)

    return config


async def get_task_quality(task: TaskData, client: "TagmeClientAdvanced") -> TaskQuality:
    quality, consistency, reward = None, None, 0.0

    items_quality = await get_items_quality(task, client)

    if items_quality:
        reward = sum(x.reward for x in items_quality if x.reward)

        finished_items_consistency = [x.consistency for x in items_quality if x.complete_data]
        if finished_items_consistency:
            consistency = sum(finished_items_consistency) / len(finished_items_consistency)

        control_items = [x.quality for x in items_quality if x.quality is not None]
        if control_items:
            quality = sum(control_items) / len(control_items)

    task_quality = TaskQuality(
        uid=task.uid,
        name=task.name,
        items_count=task.estimated_files_count or 0,
        quality=quality,
        consistency=consistency,
        reward=reward,
        complete_data=task.state == TaskState.DONE,
    )

    return task_quality


def get_item_consistency(item: list) -> float:
    # TODO support custom logic
    consistency_table: Dict[str, int] = defaultdict(int)
    for result in item:
        consistency_table[get_dict_hash(result)] += 1

    total = len(item)
    return sum(x**2 for x in consistency_table.values()) / total**2


def get_dict_hash(d: dict) -> str:
    s = '&'.join(f'{k}={v}' for k, v in sorted(d.items(), key=lambda i: i[0]))
    return hashlib.md5(s.encode()).hexdigest()


def get_item_quality(
    item: TaskResult, meta: Optional[MetaData], task: TaskData, config: 'QualityConfig'
) -> ItemQuality:
    result = [x['result'] for x in item.result.values()]
    if config.ignore_fields:
        result = list(map(deepcopy, result))
        for item_ in result:
            filter_dict(item_, config.ignore_fields)

    if not meta or not meta.control:
        quality = None

    else:
        quality = sum(get_result_quality(x, meta.control, config.algorithms) for x in result) / len(result)

    consistency = get_item_consistency(result)

    return ItemQuality(
        uid=item.uid,
        task_id=item.task_id,
        quality=quality,
        consistency=consistency,
        reward=len(result) * (task.price or 1),
        complete_data=len(result) == task.overlap,
    )


def get_result_quality(result: dict, control: dict, algorithms: Dict[str, str]) -> float:
    values = []

    for k, cv in control.items():
        if k not in result:
            continue

        rv = result[k]
        algorithm = ALGORITHM_MAP[algorithms.get(k, algorithms['*']).upper()]
        values.append(algorithm(rv, cv))

    return sum(values) / len(values) if values else 0


def strict_compare(result_value: Any, control_value: Any) -> float:
    return float(result_value == control_value)


def float_distance_compare(result_value: Union[int, float], control_value: Union[int, float]) -> float:
    if control_value == 0:
        return float(result_value == 0)  # to avoid division by zero. questionable solution

    distance = abs(result_value - control_value)
    rel_distance = distance / control_value
    quality = max(0.0, 1 - rel_distance)

    return quality


def string_distance_compare(result_value: str, control_value: str) -> float:
    distance = levenshtein_distance(result_value, control_value)
    quality = max(0.0, 1 - distance / len(control_value))
    return quality


def filter_dict(item: Dict, fields: List[str], skipfirst: int = 0) -> None:
    """
    inplace remove fields from dict
    """
    for field in fields:
        *_, tail = field.split('.', skipfirst)
        _filter_item(item, tail)


def _filter_item(item: Union[Dict, List[Dict]], field: str) -> None:
    if isinstance(item, list):
        for it in item:
            _filter_item(it, field)

    elif '.' not in field:
        assert isinstance(item, dict)
        item.pop(field, None)
        return

    else:
        key, tail = field.split('.', 1)
        item = item[key]
        _filter_item(item, tail)


@dataclass
class QualityConfig:
    algorithms: Dict[str, str]
    ignore_fields: Optional[List[str]] = None


DEFAULT_ALGORITHM = 'STRICT'
ALGORITHM_MAP: Dict[str, Callable[[Any, Any], float]] = {
    'STRICT': strict_compare,
    'FLOAT_DISTANCE': float_distance_compare,
    'STRING_DISTANCE': string_distance_compare,
}
