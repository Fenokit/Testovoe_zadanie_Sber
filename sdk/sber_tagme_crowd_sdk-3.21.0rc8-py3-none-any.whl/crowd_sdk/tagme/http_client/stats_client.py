import logging
import tempfile
from datetime import date, datetime, timedelta
from functools import partial
from pathlib import Path
from typing import Any, Callable, Coroutine, Dict, List, Optional, Tuple, Union

import pytz

from crowd_sdk.core.utils.common import cast_params
from crowd_sdk.core.utils.common import dataclass_from_dict as from_dict
from crowd_sdk.core.utils.jwt_client import JWTAPI, ResponseType
from crowd_sdk.tagme.config import DEFAULT_CONFIG, AuthConfig, CrowdConfig
from crowd_sdk.tagme.http_client.common import preprocess_archive
from crowd_sdk.tagme.http_client.datacls import (
    Assignment,
    ExportFormat,
    ExportTypes,
    FullOrganization,
    MarkersStatistic,
    Person,
    Pool,
    Project,
    TaskData,
    TasksStatistic,
    TaskStatisticsItem,
)

SECTION_NAME = "tagme_stats"
DEFAULT_PAGE_NUMBER = 1
DEFAULT_PAGE_SIZE = 100
DATE_PATTERN = "%Y-%m-%d"

logger = logging.getLogger(__name__)


def clear_none(d: Dict[str, Any]) -> Dict[str, Any]:
    for k in list(d.keys()):
        if d[k] is None:
            del d[k]
    return d


def parse_date_tuple(dt: Union[Tuple[int, int, int], str]) -> str:
    if isinstance(dt, str):
        return dt
    else:
        return date(*dt).strftime('%Y-%m-%d')


CrowdConfig.crowd_config_section(SECTION_NAME)(AuthConfig)


class TagmeStatsClient(JWTAPI):
    def __init__(self, config: Union[str, Path, AuthConfig] = DEFAULT_CONFIG):
        conf: Optional[AuthConfig] = None
        if isinstance(config, AuthConfig):
            conf = config
        else:
            conf = CrowdConfig.from_path(config).tagme_stats
        assert conf is not None, "fill tagme_stats section of config file"
        super().__init__(conf)

    async def __aenter__(self) -> 'TagmeStatsClient':
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def get_organizations(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
    ) -> List[FullOrganization]:
        url = "/api/v0/admin/organizations"
        resp = await self.get(url, params=cast_params(page=page, size=size, query=query))
        return [from_dict(data_class=FullOrganization, data=item) for item in resp['items']]

    async def get_list_task_statistics(
        self,
        task_ids: Optional[List[str]] = None,
        update_date_from: Optional[str] = None,
    ) -> List[TaskStatisticsItem]:
        url = "/api/v0/admin/statistics/tasks"
        resp = await self.get(
            url=url,
            params=cast_params(
                task_ids=task_ids,
                update_date_from=update_date_from,
                map_keys=[('task_ids', 'taskId[]')],
            ),
        )
        return [from_dict(data_class=TaskStatisticsItem, data=clear_none(task_stat_data)) for task_stat_data in resp]

    async def __fetch_statistics(
        self,
        url: str,
        from_date: Union[Tuple[int, int, int], str],  # year, month, day
        to_date: Union[Tuple[int, int, int], str],  # year, month, day
        types: List[Union[ExportTypes, str]] = None,
        file_format: ExportFormat = ExportFormat.CSV,
        **kwargs: Any,
    ) -> Tuple[List[TasksStatistic], List[MarkersStatistic]]:
        if types is None:
            types = [ExportTypes.MARKERS, ExportTypes.TASKS]
        from_date = parse_date_tuple(from_date)
        to_date = parse_date_tuple(to_date)

        params = cast_params(
            from_date=from_date,
            to_date=to_date,
            types=types,
            file_format=file_format,
            map_keys=[('from_date', 'from'), ('to_date', 'to'), ('types', 'types[]'), ('file_format', 'format')],
            **kwargs,
        )

        with tempfile.TemporaryDirectory() as temporary:
            tmp = Path(temporary)
            # add response_type=ResponseType.RAW_RESPONSE for response as raw bytes
            raw_resp = await self.get(url=url, params=params, response_type=ResponseType.RAW_RESPONSE)
            archive = tmp / 'archive.zip'
            target_dir = tmp / 'csv'
            # write data to archive
            with open(archive, 'wb') as f:
                f.write(raw_resp)

            return preprocess_archive(archive, target_dir)

    async def export_project_stats(
        self,
        project_id: str,
        from_date: Union[Tuple[int, int, int], str],  # year, month, day
        to_date: Union[Tuple[int, int, int], str],  # year, month, day
        types: List[Union[ExportTypes, str]] = None,
        file_format: ExportFormat = ExportFormat.CSV,
    ) -> Tuple[List[TasksStatistic], List[MarkersStatistic]]:
        url = f'api/v0/admin/statistics/project/{project_id}/export'
        return await self.__fetch_statistics(
            url=url,
            from_date=from_date,
            to_date=to_date,
            types=types,
            file_format=file_format,
        )

    async def export_org_stats(
        self,
        organization_id: str,
        from_date: Union[Tuple[int, int, int], str],  # year, month, day
        to_date: Union[Tuple[int, int, int], str],  # year, month, day
        types: List[Union[ExportTypes, str]] = None,
        file_format: ExportFormat = ExportFormat.CSV,
        hourly: Optional[bool] = None,
    ) -> Tuple[List[TasksStatistic], List[MarkersStatistic]]:
        url = f'api/v0/admin/statistics/organization/{organization_id}/export'
        return await self.__fetch_statistics(
            url=url,
            from_date=from_date,
            to_date=to_date,
            types=types,
            file_format=file_format,
            hourly=hourly,
        )

    async def export_admin_stats(
        self,
        from_date: Union[Tuple[int, int, int], str],  # year, month, day
        to_date: Union[Tuple[int, int, int], str],  # year, month, day
        types: List[Union[ExportTypes, str]] = None,
        file_format: ExportFormat = ExportFormat.CSV,
        with_demo_orgs: Optional[bool] = None,
    ) -> Tuple[List[TasksStatistic], List[MarkersStatistic]]:
        url = "/api/v0/admin/statistics/export"
        return await self.__fetch_statistics(
            url=url,
            from_date=from_date,
            to_date=to_date,
            types=types,
            file_format=file_format,
            with_demo_orgs=with_demo_orgs,
        )

    async def __get_projects(
        self,
        organization_id: str,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        archived: Optional[bool] = False,
        query: Optional[str] = None,
        update_date_from: Optional[str] = None,
    ) -> Tuple[List[Project], int, int]:
        url = "/api/v0/admin/markup_project"
        params = cast_params(
            organization_id=organization_id,
            page=page,
            size=size,
            archived=archived,
            query=query,
            update_date_from=update_date_from,
        )
        resp = await self.get(url=url, params=params)
        result = [from_dict(data_class=Project, data=_) for _ in resp['items']]
        page = resp['page']
        total = resp['total']
        return result, page, total

    async def __get_tasks(
        self,
        organization_id: str,
        project_id: Optional[str] = None,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        query: Optional[str] = None,
        update_date_from: Optional[str] = None,
    ) -> Tuple[List[TaskData], int, int]:
        url = 'api/v0/admin/tasks'
        params = cast_params(
            project_id=project_id,
            page=page,
            size=size,
            query=query,
            update_date_from=update_date_from,
            organization_id=organization_id,
        )
        resp = await self.get(url=url, params=params)
        result = [from_dict(data_class=TaskData, data=clear_none(task_data)) for task_data in resp['items']]
        page = resp['page']
        total = resp['total']
        return result, page, total

    async def get_pool(
        self,
        pool_id: str,
        with_markers: Optional[bool] = None,
    ) -> Pool:
        url = f"api/v0/admin/pool/{pool_id}"
        params = cast_params(withMarkers=with_markers)
        resp = await self.get(url=url, params=params)
        if isinstance(resp, dict):
            cleared_members = [item for item in resp.get('members', []) if item.get('person') is not None]
            resp['members'] = cleared_members
        return from_dict(data_class=Pool, data=resp)

    async def __get_pools(
        self,
        organization_id: str,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
    ) -> Tuple[List[Pool], int, int]:
        url = "api/v0/admin/pools"
        params = cast_params(page=page, size=size, organization_id=organization_id)
        resp = await self.get(url=url, params=params)
        result = [from_dict(data_class=Pool, data=item) for item in resp['items']]
        page = resp['page']
        total = resp['total']
        return result, page, total

    @staticmethod
    def __infer_pagination_params(page: Optional[int], size: Optional[int]) -> Tuple[int, int, Optional[int]]:
        assert (page is None) == (size is None), "page and size parameters must be only passed together"
        page_number = page or DEFAULT_PAGE_NUMBER
        page_size = size or DEFAULT_PAGE_SIZE
        total = None
        return page_number, page_size, total

    @staticmethod
    async def __run_with_pagination(
        func: Callable[..., Coroutine[Any, Any, Tuple[List, Any, Any]]], page: Optional[int], size: Optional[int]
    ) -> List:
        page_number, page_size, total = TagmeStatsClient.__infer_pagination_params(page, size)
        result: List = []
        while total is None or (page_number - 1) * page_size < total:
            items, page_number, total = await func(page=page_number, size=page_size)
            result.extend(items)
            if page is not None and size is not None:
                break
            page_number += 1
        return result

    async def get_projects(
        self,
        organization_id: str,
        page: Optional[int] = None,
        size: Optional[int] = None,
        archived: Optional[bool] = False,
        query: Optional[str] = None,
        update_date_from: Optional[str] = None,
    ) -> List[Project]:
        func = partial(
            self.__get_projects,
            organization_id=organization_id,
            archived=archived,
            query=query,
            update_date_from=update_date_from,
        )
        return await self.__run_with_pagination(func, page=page, size=size)

    async def get_tasks(
        self,
        organization_id: str,
        project_id: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
        update_date_from: Optional[str] = None,
    ) -> List[TaskData]:
        func = partial(
            self.__get_tasks,
            project_id=project_id,
            organization_id=organization_id,
            query=query,
            update_date_from=update_date_from,
        )
        return await self.__run_with_pagination(func, page=page, size=size)

    async def get_pools(
        self,
        organization_id: str,
        page: Optional[int] = None,
        size: Optional[int] = None,
    ) -> List[Pool]:
        func = partial(self.__get_pools, organization_id=organization_id)
        return await self.__run_with_pagination(func, page=page, size=size)

    @staticmethod
    def __to_msk_date(d: Optional[str]) -> Optional[date]:
        if not d:
            return None
        return datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=pytz.timezone('Europe/Moscow')).date()

    @staticmethod
    def __check_dates(x: date, a: Optional[date], b: Optional[date]) -> bool:
        return (not a or a <= x) and (not b or x <= b)

    async def get_task_assignments(
        self,
        task_id: str,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
    ) -> List[Assignment]:
        date_from_date = self.__to_msk_date(date_from)
        date_to_date = self.__to_msk_date(date_to)
        if date_from:
            date_from = (datetime.strptime(date_from, "%Y-%m-%d") - timedelta(days=1)).strftime(DATE_PATTERN)

        url = "api/v0/admin/assignments"
        params = cast_params(
            task_id=task_id,
            date_from=date_from,
            date_to=date_to or datetime.now().strftime('%Y-%m-%d'),
            file_format=ExportFormat.JSON,
            map_keys=[('file_format', 'format')],
        )
        resp = await self.get(
            url=url,
            params=params,
        )

        assignments = [from_dict(data_class=Assignment, data=item) for item in resp]

        result: List[Assignment] = []
        for a in assignments:
            assert a.end_date
            if self.__check_dates(a.end_date.date(), date_from_date, date_to_date):
                result.append(a)

        return result

    async def get_task(self, task_id: str) -> TaskData:
        url = f'api/v0/admin/tasks/{task_id}'
        resp = await self.get(url=url)
        return from_dict(data_class=TaskData, data=resp)

    async def get_project(self, project_id: str) -> Project:
        url = f'api/v0/admin/markup_project/{project_id}'
        resp = await self.get(
            url=url,
        )
        return from_dict(data_class=Project, data=resp)

    async def __get_persons(
        self,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        query: Optional[str] = None,
        emails: Optional[List[str]] = None,
        with_organizations: Optional[bool] = None,
        person_ids: Optional[List[str]] = None,
    ) -> Tuple[List[Person], int, int]:
        url = 'api/v0/admin/persons'
        resp = await self.get(
            url=url,
            params=cast_params(
                page=page,
                size=size,
                query=query,
                emails=emails,
                withOrganizations=with_organizations,
                person_ids=person_ids,
                map_keys=[('person_ids', 'person_id[]'), ('emails', 'emails[]')],
            ),
        )
        result = [from_dict(data_class=Person, data=_) for _ in resp['items']]
        page = resp['page']
        total = resp['total']
        return result, page, total

    async def get_persons(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
        emails: Optional[List[str]] = None,
        with_organizations: Optional[bool] = None,
        person_ids: Optional[List[str]] = None,
    ) -> List[Person]:
        func = partial(
            self.__get_persons,
            query=query,
            emails=emails,
            with_organizations=with_organizations,
            person_ids=person_ids,
        )
        return await self.__run_with_pagination(func, page, size)

    async def collect_org_events(
        self,
        from_to_date: str,
        cache: Optional[dict],
        organization_id: str,
    ) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, str]]:
        if not cache:
            cache = {
                'stats': {},
                'events': {},
            }

        task_statistics, _marker_statistics = await self.export_org_stats(
            from_date=from_to_date,
            to_date=from_to_date,
            types=['tasks'],
            organization_id=organization_id,
        )

        statuses = {}
        exceptions = []
        for task_stat in sorted(task_statistics, key=lambda x: x.task_id):
            try:
                if from_to_date not in cache['stats']:
                    cache['stats'][from_to_date] = {}
                completed_assignments, time_spent = cache['stats'][from_to_date].get(task_stat.task_id, (0, 0))
                completed_calculated = task_stat.completed_assignments
                if completed_calculated == completed_assignments:
                    statuses[task_stat.task_id] = 'NOT_CHANGED'
                    continue

                values = await self.get_task_assignments(
                    task_id=task_stat.task_id, date_from=from_to_date, date_to=from_to_date
                )

                if from_to_date not in cache['events']:
                    cache['events'][from_to_date] = {}
                cache['events'][from_to_date][task_stat.task_id] = values

                time_spent = (
                    sum(
                        (x.end_date - x.start_date).total_seconds()
                        for x in values
                        if x.end_date and x.start_date and not x.skipped_at
                    )
                    * 0.1
                    / 3600
                )
                if from_to_date not in cache['stats']:
                    cache['stats'][from_to_date] = {}
                cache['stats'][from_to_date][task_stat.task_id] = (len(values), time_spent)
                statuses[task_stat.task_id] = 'OK'

            except Exception as exc:  # pylint: disable=broad-except
                statuses[task_stat.task_id] = 'ERROR'
                exceptions.append((task_stat.task_id, exc, task_stat.task_id))

            for task_id, e, url in exceptions:
                logger.info(f'Failed to collect {task_id} {e}: {url}')

        return cache, statuses
