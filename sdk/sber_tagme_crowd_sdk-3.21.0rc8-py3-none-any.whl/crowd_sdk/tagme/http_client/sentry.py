import re
from hashlib import md5
from typing import List, Optional

import sentry_sdk
from aiohttp.web_exceptions import HTTPUnauthorized
from sentry_sdk.integrations.asyncio import AsyncioIntegration

from crowd_sdk.tagme.config import TagmeConfig
from crowd_sdk.version import __version__

SENTRY_DSN = None
UID_PATTERN = re.compile('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')


def make_fingerprint(items: list) -> List[str]:
    result = []
    for item in items:
        if isinstance(item, str):
            if '\n' in item:
                continue

            result.append('<UID>'.join(UID_PATTERN.split(item)).split('?', 1)[0])

        else:
            result.append(str(item))

    return result


def filter_sentry(event: dict, hint: dict) -> Optional[dict]:
    if 'exc_info' in hint:
        exc_type, exc_value, tb = hint['exc_info']  # pylint: disable=unused-variable
        if isinstance(exc_value, (KeyboardInterrupt, HTTPUnauthorized)):
            return None

    elif 'logentry' in event:
        entry = event['logentry']
        if entry['message'].startswith('Request to %s %s failed'):
            event['fingerprint'] = [entry['message'], *make_fingerprint(entry['params'])]

            if 'taskflow/task/<UID>/item' in event['fingerprint'] and '404' in event['fingerprint']:
                return None

    return event


def init_sentry(config: TagmeConfig) -> None:
    config.sentry_dsn = config.sentry_dsn or SENTRY_DSN
    if config.disable_sentry:
        return
    if not config.sentry_dsn:
        return

    sentry_sdk.init(
        dsn=config.sentry_dsn,
        release=__version__,
        environment=config.stand,
        # with_locals=False,
        integrations=[
            AsyncioIntegration(),
        ],
        before_send=filter_sentry,
        debug=config.sentry_debug,
    )
    sentry_sdk.set_user(
        {
            "username": config.user
            or (md5(config.client_secret.encode()).hexdigest() if config.client_secret else 'cert user')
        }
    )
