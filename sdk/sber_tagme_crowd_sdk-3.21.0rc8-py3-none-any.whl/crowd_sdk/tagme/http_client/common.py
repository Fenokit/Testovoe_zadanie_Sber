import csv
import logging
import zipfile
from pathlib import Path
from typing import List, Tuple

from crowd_sdk.tagme.types import ExportTypes, MarkersStatistic, TasksStatistic

MAPPING_MARKERS_STATISTIC_KEYS = {
    'Дата': 'date',
    'Организация': 'organization',
    'Проект': 'project',
    'ID проекта': 'project_id',
    'Задача': 'task',
    'ID задачи': 'task_id',
    'ID разметчика': 'marker_id',
    'Email разметчика': 'email',
    'Email': 'email',
    'ФИО разметчика': 'fio',
    'ФИО': 'fio',
    'Выполнено заданий': 'marked',
    'Сделано заданий': 'marked',
    'Принято заданий': 'accepted',
    'Отклонено заданий': 'rejected',
    'Заданий на проверке': 'submitted',
    'Пропущено заданий': 'skipped',
    'Просрочено заданий': 'expired',
    'Среднее время на одно задание': 'avg_time',
    'Время ср. разметки объекта (с.)': 'avg_time',
    'Затраченное время на разметку': 'overall_time',
    'Время суммарное (ч.)': 'overall_time',
    'Качество ср.': 'avg_quality',
    'Стоимость сумм.': 'sum_price',
    'Затраты, у.е.': 'sum_price',
    'На приемке, у.е.': 'blocked_price',
    'Согласованность ср.': 'avg_consistency',
    'Согласованность': 'avg_consistency',
    'Начало работы': 'begin',
    'Окончание работы': 'end',
    'Группы': None,
}

MAPPING_TASKS_STATISTIC_KEYS = {
    'Дата': 'date',
    'Организация': 'organization',
    'Проект': 'project',
    'ID проекта': 'project_id',
    'Задача': 'task',
    'ID задачи': 'task_id',
    'Всего объектов (файлов)': 'count_items',
    'Размечено объектов (файлов)': 'completed_items',
    'Всего объектов': 'count_items',
    'Размечено объектов': 'completed_items',
    'Текущее значение перекрытия': 'overlap',
    'Перекрытие': 'overlap',
    'Всего заданий (с учетом перекрытия)': 'count_assignments',
    'Всего заданий': 'count_assignments',
    'Выполнено заданий': 'completed_assignments',
    'Принято заданий': 'accepted_assignments',
    'Отклонено заданий': 'rejected_assignments',
    'Заданий на проверке': 'submitted_assignments',
    'Сделано заданий': 'completed_assignments',
    'Пропущено заданий': 'skipped_assignments',
    'Просрочено заданий': 'expired_assignments',
    'Всего назначенных разметчиков': 'count_markers',
    'Кол-во разметчиков': 'count_markers',
    'Кол-во активных разметчиков': 'active_markers',
    'Среднее время на одно задание': 'avg_time',
    'Время ср. разметки объекта (с.)': 'avg_time',
    'Затраченное время на разметку': 'overall_time',
    'Время суммарное (ч.)': 'overall_time',
    'Качество ср.': 'avg_quality',
    'Стоимость сумм.': 'sum_price',
    'Затраты, у.е.': 'sum_price',
    'На приемке, у.е.': 'blocked_price',
    'Согласованность ср.': 'avg_consistency',
    'Тип задачи': 'task_type',
}


def preprocess_archive(achive: Path, target_dir: Path) -> Tuple[List[TasksStatistic], List[MarkersStatistic]]:
    tasks_statistic: List[TasksStatistic] = []
    markers_statistic: List[MarkersStatistic] = []

    with zipfile.ZipFile(achive) as zip_archive:
        zip_archive.extractall(target_dir)

    for file in target_dir.rglob('*.csv'):
        with open(file, newline='', encoding='utf-8') as csv_file:
            for row in csv.DictReader(csv_file, delimiter=','):
                params = dict(row.items())
                if ExportTypes.MARKERS.value.lower() in file.stem.lower():
                    parameters = {}
                    for k, v in params.items():
                        if k in MAPPING_MARKERS_STATISTIC_KEYS:
                            if v != '' and v is not None and MAPPING_MARKERS_STATISTIC_KEYS[k]:
                                parameters[MAPPING_MARKERS_STATISTIC_KEYS[k]] = v
                        else:
                            logging.warning(f'No key {k} in {list(MAPPING_MARKERS_STATISTIC_KEYS.keys())}')
                    markers_statistic.append(MarkersStatistic(**parameters))  # type: ignore
                if ExportTypes.TASKS.value.lower() in file.stem.lower():
                    parameters = {}

                    for k, v in params.items():
                        if k in MAPPING_TASKS_STATISTIC_KEYS:
                            if v != '' and v is not None and MAPPING_TASKS_STATISTIC_KEYS[k]:
                                parameters[MAPPING_TASKS_STATISTIC_KEYS[k]] = v
                        else:
                            logging.warning(f'No key {k} in {list(MAPPING_TASKS_STATISTIC_KEYS.keys())}')

                    tasks_statistic.append(TasksStatistic(**parameters))  # type: ignore

    return tasks_statistic, markers_statistic
