# pylint: disable=C0302
import json
import mimetypes
import tempfile
import warnings
from contextlib import ExitStack
from datetime import date
from pathlib import Path
from time import sleep
from typing import Any, Callable, Dict, Generator, Iterable, List, Optional, Sequence, Set, Tuple, Union

import urllib3
from requests import HTTPError

from crowd_sdk.core.utils.common import cast_params, chunks
from crowd_sdk.core.utils.common import dataclass_from_dict as from_dict
from crowd_sdk.core.utils.common import dataclass_to_dict, logger
from crowd_sdk.core.utils.http_client import HttpMethod
from crowd_sdk.core.utils.jwt_client import JWTSyncAPI, ResponseType, SyncHttpWrapper, Token
from crowd_sdk.tagme.config import DEFAULT_CLIENT_ID, DEFAULT_CONFIG, CrowdConfig, TagmeConfig
from crowd_sdk.tagme.http_client.common import preprocess_archive
from crowd_sdk.tagme.http_client.datacls import (
    EXPORT_SUFFIX,
    Assignment,
    CheckTaskResult,
    Dataset,
    DatasetFile,
    Employee,
    ErrorMarkersResponse,
    ExportFormat,
    ExportTypes,
    FileMetaData,
    FileType,
    FullOrganization,
    InviteApplication,
    InviteData,
    InviteRequest,
    MarkerSkill,
    MarkersStatistic,
    MarkupResult,
    MarkupResults,
    MarkupResultSortField,
    MarkupReview,
    MarkupTask,
    MetaData,
    MetaType,
    MethodData,
    Organization,
    OrganizationConfig,
    Person,
    Pool,
    Project,
    ProjectStatistic,
    SetMarkerSkillResponse,
    Skill,
    SortOrder,
    SPInfo,
    TaskData,
    TaskDataRequest,
    TaskFile,
    TaskflowTaskData,
    TaskHierarchy,
    TaskResult,
    TasksStatistic,
    TaskState,
    TaskStatisticsItem,
    TaskStats,
    TaskStatsAdvanced,
    UpdateMetaDataRequest,
    UploadFilesResult,
)
from crowd_sdk.tagme.http_client.sentry import init_sentry
from crowd_sdk.tagme.utils.datacls import SyncSettings

BATCH_SIZE = 16
UPLOAD_ATTEMPTS = 100


def clear_none(d: Dict[str, Any]) -> Dict[str, Any]:
    for k in list(d.keys()):
        if d[k] is None:
            del d[k]
    return d


def parse_date_tuple(dt: Union[Tuple[int, int, int], str]) -> str:
    if isinstance(dt, str):
        return dt
    else:
        return date(*dt).strftime('%Y-%m-%d')


def find_attachments(data: Any) -> Generator[str, None, None]:
    if isinstance(data, dict):
        for _, item in data.items():
            if isinstance(item, str) and 'attachment' in item:
                yield item
            elif isinstance(item, (dict, list)):
                yield from find_attachments(item)

    elif isinstance(data, list):
        for item in data:
            if isinstance(item, str) and 'attachment' in item:
                yield item
            elif isinstance(item, (dict, list)):
                yield from find_attachments(item)


def str_or_data(src: str) -> Any:
    if isinstance(src, int):
        return src
    try:
        return json.loads(src)
    except json.JSONDecodeError:
        return src


def row_to_task(row: Dict[str, Any]) -> Dict[str, Any]:  # pylint: disable=R0912
    task_data = {}
    control_data = {}
    premarkup_data = {}
    hint = {}
    file_path = None
    file_id = None

    for key, value in row.items():
        if key.startswith('GOLDEN:'):
            key = key[len('GOLDEN:') :]
            if value:
                control_data[key] = str_or_data(value)
        elif key.startswith('HINT:'):
            key = key[len('HINT:') :]
            if value:
                hint[key] = value
        elif key.startswith('PREMARKUP:'):
            key = key[len('PREMARKUP:') :]
            if value:
                premarkup_data[key] = str_or_data(value)
        elif key.startswith('BASELINE:'):
            key = key[len('BASELINE:') :]
            if value:
                premarkup_data[key] = str_or_data(value)
        elif key.startswith('INPUT:'):
            key = key[len('INPUT:') :]
            task_data[key] = str_or_data(value)
        elif key == 'PATH':
            file_path = value
        elif key == 'ID':
            file_id = value

    res = {
        'task': task_data,
        'file_path': file_path,
        'id': file_id,
    }
    if premarkup_data:
        res['premarkup'] = premarkup_data
    if control_data:
        res['control'] = control_data
    if hint:
        res['hint'] = '\n'.join(list(hint.values()))
    return res


class TagmeSyncClient(JWTSyncAPI):  # pylint: disable=too-many-public-methods
    def __init__(
        self,
        config: Union[str, Path, dict, CrowdConfig, TagmeConfig] = DEFAULT_CONFIG,
        http: Optional[SyncHttpWrapper] = None,
    ) -> None:
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        self.config: TagmeConfig = TagmeConfig.from_any(config)
        super().__init__(http=http, config=self.config)

        init_sentry(self.config)
        self.__org: Optional[Organization] = None
        self.__orgs: List[Organization] = []
        self.token_marker = Token(self.config, self.auth_http)
        self.token_orgs: Dict[str, Token] = {}

    def __enter__(self) -> 'TagmeSyncClient':
        return self

    async def __exit__(self, *args: Any) -> None:
        self.close()

    def get_org_token(self, org_id: Optional[str] = None) -> Token:
        filled_org_id = org_id or self.get_current_organization_id()
        token = self.token_orgs.get(filled_org_id)
        if not token:
            auth_headers = {'Content-Type': 'application/x-www-form-urlencoded', 'Organization-id': filled_org_id}
            token = Token(self.config, self.auth_http, auth_headers)
            self.token_orgs[filled_org_id] = token
        return token

    def marker_header(self) -> Dict[str, str]:
        return {'Authorization': f'{self.auth_type} {self.token_marker.get_access_token()}'}

    def request(self, method: HttpMethod, url: str, headers: Optional[Dict[str, str]] = None, **kwargs: Any) -> Any:
        headers = headers or {}

        if 'Authorization' not in headers:
            if self.config.client_id == DEFAULT_CLIENT_ID:
                kw_org_id = (
                    kwargs.pop('organization_id', False)
                    or kwargs.pop('org_id', False)
                    or kwargs.pop('orgId', False)
                    or kwargs.get('params', {}).get('organization_id')
                    or kwargs.get('params', {}).get('org_id')
                    or kwargs.get('params', {}).get('orgId')
                )
                if not kw_org_id and isinstance(kwargs.get('json', {}), dict):
                    kw_org_id = kwargs.get('json', {}).get('organization_id')

                token_object = self.get_org_token(kw_org_id)
                token = token_object.get_access_token()
            else:
                token = self.token_marker.get_access_token()

            headers['Authorization'] = f'{self.auth_type} {token}'

        return self._request(method, url, verify=self.ca_cert, cert=self.cl_cert, headers=headers, **kwargs)

    # -----------------------------------------------------------------------------
    #                                  CLIENT
    # -----------------------------------------------------------------------------

    def get_self_person(self, with_organizations: bool = False) -> Person:
        url = 'api/v0/selfperson'
        resp = self.get(url=url, params=cast_params(withOrganizations=with_organizations), headers=self.marker_header())
        return from_dict(data_class=Person, data=resp)

    def get_current_organization(self) -> Organization:
        if self.__org is None:
            return self.set_organization(self.config.org)
        return self.__org

    def get_current_organization_id(self) -> str:
        return (self.get_current_organization()).uid

    def get_current_organization_name(self) -> str:
        return (self.get_current_organization()).name

    def set_organization(self, org_key: Optional[str]) -> Organization:
        orgs = self.get_organizations()
        for org in sorted(orgs, key=lambda x: 0 if 'CUSTOMER' in x.roles else 1):
            if org_key in (org.uid, org.name) or org_key is None:
                self.__org = org
                return org
        raise KeyError(f'Organization "{org_key}" not found in {orgs}')

    def get_organization(self, org_key: Optional[str] = None) -> Organization:
        if self.__org:
            if org_key is None or org_key in (self.__org.uid, self.__org.name):
                return self.__org
        for org in self.get_organizations():
            if org_key is None:
                return org
            if org_key in (org.uid, org.name):
                return org
        raise KeyError(f'Organization "{org_key}" not found in {self.__orgs}')

    def get_organizations(self) -> List[Organization]:
        if not self.__orgs:
            person = self.get_self_person(with_organizations=True)
            self.__orgs = person.organizations or []
        assert self.__orgs, 'There\'s no organizations for user'
        return self.__orgs

    # -----------------------------------------------------------------------------
    #                                  PROJECT
    # -----------------------------------------------------------------------------

    def get_projects(
        self,
        with_tasks_count: bool = False,
        archived: Optional[bool] = False,
        organization_id: Optional[str] = None,
        query: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        is_bookmarked: Optional[bool] = None,
        is_pipelined: Optional[bool] = None,
        update_date_from: Optional[str] = None,
    ) -> List[Project]:
        organization_id = organization_id or self.get_current_organization_id()
        url = 'api/v0/markup_project'
        params = cast_params(
            organization_id=organization_id,
            withTasksCount=with_tasks_count,
            archived=archived,
            query=query,
            page=page,
            size=size,
            is_bookmarked=is_bookmarked,
            is_pipelined=is_pipelined,
            update_date_from=update_date_from,
        )
        resp = self.get(url=url, params=params)
        return [from_dict(data_class=Project, data=_) for _ in resp['items']]

    def get_project(
        self, project_id: str, with_tasks_count: bool = False, organization_id: Optional[str] = None
    ) -> Project:
        url = f'api/v0/markup_project/{project_id}'
        resp = self.get(url=url, params=cast_params(withTasksCount=with_tasks_count, organization_id=organization_id))
        return from_dict(data_class=Project, data=resp)

    def create_project(
        self,
        name: str,
        description: Optional[str] = None,
        organization_id: Optional[str] = None,
        inner_comment: Optional[str] = None,
    ) -> Project:
        organization_id = organization_id or self.get_current_organization_id()
        url = 'api/v0/markup_project'
        json_data = cast_params(
            name=name, organization_id=organization_id, description=description, inner_comment=inner_comment
        )
        resp = self.post(url=url, params=cast_params(organization_id=organization_id), json=json_data)
        return from_dict(data_class=Project, data=resp)

    def update_project(
        self,
        project_id: str,
        name: str,
        organization_id: Optional[str] = None,
        description: Optional[str] = None,
        inner_comment: Optional[str] = None,
        pipeline: Optional[Union[SyncSettings, dict]] = None,
        is_pipeline_enabled: Optional[bool] = None,
    ) -> Project:
        organization_id = organization_id or self.get_current_organization_id()
        url = f'api/v0/markup_project/{project_id}'
        if pipeline and isinstance(pipeline, SyncSettings):
            pipeline = dataclass_to_dict(pipeline)
        json_data = cast_params(
            name=name,
            description=description,
            inner_comment=inner_comment,
            pipeline=pipeline,
            is_pipeline_enabled=is_pipeline_enabled,
        )
        resp = self.put(url=url, params=cast_params(organization_id=organization_id), json=json_data)
        return from_dict(data_class=Project, data=resp)

    def archive_projects(self, uids: List[str], organization_id: Optional[str] = None) -> Optional[dict]:
        url = 'api/v0/markup_project/archive'
        if not uids:
            return None

        return self.put(url=url, json=cast_params(uids=uids), params=cast_params(organization_id=organization_id))

    def archive_project(self, project_id: str, organization_id: Optional[str] = None) -> Optional[dict]:
        return self.archive_projects(uids=[project_id], organization_id=organization_id)

    def restore_projects(self, uids: List[str], organization_id: Optional[str] = None) -> Optional[dict]:
        url = 'api/v0/markup_project/restore'
        if not uids:
            return None

        return self.put(url=url, json=cast_params(uids=uids), params=cast_params(organization_id=organization_id))

    def add_users_to_project(self, project_id: str, pool_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/markup_project/{project_id}/pools/{pool_id}'
        self.post(url=url, params=cast_params(organization_id=organization_id))

    def delete_users_from_project(self, project_id: str, pool_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/markup_project/{project_id}/pools/{pool_id}'
        self.delete(url=url, params=cast_params(organization_id=organization_id))

    def get_pools(self, project_id: str, organization_id: Optional[str] = None) -> List[str]:
        project = self.get_project(project_id=project_id, organization_id=organization_id)
        return project.pools

    def get_project_stats(self, project_id: str, organization_id: Optional[str] = None) -> ProjectStatistic:
        url = f'api/v0/statistics/project/{project_id}'
        resp = self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=ProjectStatistic, data=resp)

    def export_project_stats(
        self,
        project_id: str,
        from_date: Union[Tuple[int, int, int], str],  # year, month, day
        to_date: Union[Tuple[int, int, int], str],  # year, month, day
        types: List[Union[ExportTypes, str]] = None,
        file_format: ExportFormat = ExportFormat.CSV,
        organization_id: Optional[str] = None,
    ) -> Tuple[List[TasksStatistic], List[MarkersStatistic]]:
        url = f'api/v0/statistics/project/{project_id}/export'

        if types is None:
            types = [ExportTypes.MARKERS, ExportTypes.TASKS]
        from_date = parse_date_tuple(from_date)
        to_date = parse_date_tuple(to_date)

        # optional parameter for change 'from_date' -> 'from' and 'to_date' -> 'to' and types -> types[]
        params = cast_params(
            from_date=from_date,
            to_date=to_date,
            types=types,
            file_format=file_format,
            organization_id=organization_id,
            map_keys=[('from_date', 'from'), ('to_date', 'to'), ('types', 'types[]'), ('file_format', 'format')],
        )
        with tempfile.TemporaryDirectory() as temporary:
            tmp = Path(temporary)
            # add response_type=ResponseType.RAW_RESPONSE for response as raw bytes
            raw_resp = self.get(url=url, params=params, response_type=ResponseType.RAW_RESPONSE)
            archive = tmp / 'archive.zip'
            target_dir = tmp / 'csv'
            # write data to archive
            with open(archive, 'wb') as f:
                f.write(raw_resp)

            return preprocess_archive(archive, target_dir)

    def export_org_stats(
        self,
        from_date: Union[Tuple[int, int, int], str],  # year, month, day
        to_date: Union[Tuple[int, int, int], str],  # year, month, day
        types: List[Union[ExportTypes, str]] = None,
        file_format: ExportFormat = ExportFormat.CSV,
        organization_id: Optional[str] = None,
    ) -> Tuple[List[TasksStatistic], List[MarkersStatistic]]:
        url = f'api/v0/statistics/organization/{organization_id}/export'

        if types is None:
            types = [ExportTypes.MARKERS, ExportTypes.TASKS]
        from_date = parse_date_tuple(from_date)
        to_date = parse_date_tuple(to_date)

        # optional parameter for change 'from_date' -> 'from' and 'to_date' -> 'to' and types -> types[]
        params = cast_params(
            from_date=from_date,
            to_date=to_date,
            types=types,
            file_format=file_format,
            organization_id=organization_id,
            map_keys=[('from_date', 'from'), ('to_date', 'to'), ('types', 'types[]'), ('file_format', 'format')],
        )
        with tempfile.TemporaryDirectory() as temporary:
            tmp = Path(temporary)
            # add response_type=ResponseType.RAW_RESPONSE for response as raw bytes
            raw_resp = self.get(url=url, params=params, response_type=ResponseType.RAW_RESPONSE)
            archive = tmp / 'archive.zip'
            target_dir = tmp / 'csv'
            # write data to archive
            with open(archive, 'wb') as f:
                f.write(raw_resp)

            return preprocess_archive(archive, target_dir)

    # -----------------------------------------------------------------------------
    #                                  METHOD
    # -----------------------------------------------------------------------------

    def get_method(
        self, method_id: str, task_id: Optional[str] = None, organization_id: Optional[str] = None
    ) -> MethodData:
        url = f'api/v0/method/{method_id}'
        resp = self.get(url=url, params=cast_params(task_id=task_id, organization_id=organization_id))
        return from_dict(data_class=MethodData, data=resp)

    def update_method(self, method: Union[MethodData, dict], organization_id: Optional[str] = None) -> MethodData:
        if isinstance(method, dict):
            method = from_dict(data_class=MethodData, data=method)

        assert isinstance(method, MethodData)
        url = f'api/v0/method/{method.uid}'
        resp = self.put(
            url=url,
            params=cast_params(organization_id=organization_id),
            json=dataclass_to_dict(method, exclude=('uid', 'organization_id', 'person_id', 'modification_date')),
        )
        return from_dict(data_class=MethodData, data=resp)

    # -----------------------------------------------------------------------------
    #                                  ORGANIZATIONS
    # -----------------------------------------------------------------------------

    def get_full_organizations(
        self,
        query: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
    ) -> List[FullOrganization]:
        url = 'api/v0/organizations'
        resp = self.get(
            url=url,
            params=cast_params(
                query=query,
                page=page,
                size=size,
            ),
        )
        return [from_dict(data_class=FullOrganization, data=_) for _ in resp['items']]

    def get_full_organization(self, organization_id: str, with_employees: Optional[bool] = None) -> FullOrganization:
        url = f'api/v0/organization/{organization_id}'
        resp = self.get(url=url, params=cast_params(withEmployees=with_employees))
        return from_dict(data_class=FullOrganization, data=resp)

    def update_organization(
        self, organization_id: str, name: Optional[str] = None, config: Optional[OrganizationConfig] = None
    ) -> FullOrganization:
        url = f'api/v0/organization/{organization_id}'
        resp = self.put(url=url, json=cast_params(name=name, config=dataclass_to_dict(config)))
        return from_dict(data_class=FullOrganization, data=resp)

    # -----------------------------------------------------------------------------
    #                                  TASK
    # -----------------------------------------------------------------------------

    def create_task(
        self,
        task: Union[TaskDataRequest, TaskData, dict],
        organization_id: Optional[str] = None,
    ) -> TaskData:
        url = 'api/v0/tasks'
        if isinstance(task, dict):
            if 'organization_id' not in task:
                task['organization_id'] = self.get_current_organization_id()
            task = from_dict(data_class=TaskDataRequest, data=task)

        if isinstance(task, TaskDataRequest) and task.organization_id is None:
            task.organization_id = self.get_current_organization_id()

        assert isinstance(task, (TaskDataRequest, TaskData))
        task.data_classification_level = task.data_classification_level or self.config.data_category
        task.data_source = task.data_source or self.config.data_source

        resp = self.post(url=url, json=dataclass_to_dict(task), params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskData, data=resp)

    def update_task(
        self,
        task: Union[TaskData, dict],
        organization_id: Optional[str] = None,
    ) -> TaskData:
        if isinstance(task, dict):
            task = from_dict(data_class=TaskData, data=task)

        assert isinstance(task, TaskData)
        url = f'api/v0/tasks/{task.uid}'
        task.data_classification_level = task.data_classification_level or self.config.data_category
        task.data_source = task.data_source or self.config.data_source

        self.put(url=url, json=dataclass_to_dict(task), params=cast_params(organization_id=organization_id))
        return task

    def get_tasks(  # pylint: disable=R0913
        self,
        project_id: Optional[str] = None,
        price_min: Optional[float] = None,
        price_max: Optional[float] = None,
        priority_min: Optional[int] = None,
        priority_max: Optional[int] = None,
        query: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        update_date_from: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> List[TaskData]:
        url = 'api/v0/tasks'
        resp = self.get(
            url=url,
            params=cast_params(
                project_id=project_id,
                price_min=price_min,
                price_max=price_max,
                priority_min=priority_min,
                priority_max=priority_max,
                query=query,
                page=page,
                size=size,
                update_date_from=update_date_from,
                organization_id=organization_id,
            ),
        )
        return [from_dict(data_class=TaskData, data=clear_none(task_data)) for task_data in resp['items']]

    def get_task(self, task_id: str, organization_id: Optional[str] = None) -> TaskData:
        url = f'api/v0/tasks/{task_id}'
        resp = self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskData, data=resp)

    def get_task_hierarchy(self, task_id: str) -> TaskHierarchy:
        url = f'api/v0/tasks/{task_id}/hierarchy_info'
        resp = self.get(url=url)
        return from_dict(data_class=TaskHierarchy, data=resp)

    async def unarchive_task(self, task_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/taskflow/{task_id}/unarchive'
        self.post(url=url, params=cast_params(organization_id=organization_id))

    async def archive_task(self, task_id: str, organization_id: Optional[str]) -> None:
        url = f'api/v0/taskflow/task/{task_id}/archive'
        self.post(url=url, params=cast_params(organization_id=organization_id))

    def start_task(self, task_id: str, organization_id: Optional[str] = None) -> TaskData:
        url = f'api/v0/tasks/{task_id}/start'
        resp = self.post(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskData, data=resp)

    def check_task(self, task_id: str, organization_id: Optional[str] = None) -> CheckTaskResult:
        url = f'api/v0/tasks/{task_id}/check'
        resp = self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=CheckTaskResult, data=resp)

    def stop_task(self, task_id: str, organization_id: Optional[str] = None) -> TaskData:
        url = f'api/v0/tasks/{task_id}/stop'
        resp = self.post(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskData, data=resp)

    def get_task_info(self, task_id: str, organization_id: Optional[str] = None) -> Dict:
        url = f'api/v0/storage/{task_id}/info'
        resp = self.get(url=url, params=cast_params(organization_id=organization_id))
        return resp

    def complete_task(self, task_id: str, organization_id: Optional[str] = None) -> TaskData:
        url = f'api/v0/tasks/{task_id}/complete'
        resp = self.post(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskData, data=resp)

    def remove_task(self, task_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/tasks/{task_id}/remove'
        self.put(url=url, params=cast_params(organization_id=organization_id))

    def get_task_stats(self, task_id: str, organization_id: Optional[str] = None) -> TaskStats:
        url = f'api/v0/statistics/task/{task_id}'
        resp = self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskStats, data=resp)

    def get_task_stats_advanced(self, task_id: str, organization_id: Optional[str] = None) -> TaskStatsAdvanced:
        url = f'api/v0/statistics/task/{task_id}/advanced'
        resp = self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskStatsAdvanced, data=resp)

    def get_list_task_statictics(
        self, task_ids: List[str], update_date_from: Optional[str] = None, organization_id: Optional[str] = None
    ) -> List[TaskStatisticsItem]:
        url = '/api/v0/statistics/tasks'
        resp = self.get(
            url=url,
            params=cast_params(
                task_ids=task_ids,
                update_date_from=update_date_from,
                organization_id=organization_id,
                map_keys=[('task_ids', 'taskId[]')],
            ),
        )
        return [from_dict(data_class=TaskStatisticsItem, data=clear_none(task_stat_data)) for task_stat_data in resp]

    def get_task_results(
        self,
        task_id: str,
        page: Optional[int] = None,
        size: Optional[int] = None,
        organization_id: Optional[str] = None,
    ) -> List[TaskResult]:
        warnings.warn('get_task_results is deprecated, use get_task_assignments instead', DeprecationWarning)
        if page or size:
            raise ValueError('Pagination is not supported yet for get_task_results')

        assignment_index: Dict[str, List[Assignment]] = {}

        for assignment in self.get_task_assignments(task_id, organization_id=organization_id):
            key = assignment.item_id
            if key not in assignment_index:
                assignment_index[key] = []
            assignment_index[key].append(assignment)

        results = []
        for item_id, assignments in assignment_index.items():
            result_item = TaskResult.from_assignments(item_id, assignments)
            results.append(result_item)

        return results

    def get_task_assignments(
        self,
        task_id: str,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> List[Assignment]:
        url = 'api/v0/assignments'
        resp = self.get(
            url=url,
            params=cast_params(
                task_id=task_id,
                date_from=date_from,
                date_to=date_to,
                file_format=ExportFormat.JSON,
                organization_id=organization_id,
                map_keys=[('file_format', 'format')],
            ),
        )
        return [from_dict(data_class=Assignment, data=item) for item in resp]

    def gen_task_url(
        self, project_id: str, task_id: str, organization_id: Optional[str] = None, base_url: Optional[str] = None
    ) -> str:
        organization_id = organization_id or self.get_current_organization_id()
        base_url = base_url or self.get_base_url()
        return f'{base_url}/company/{organization_id}/project/{project_id}/task/{task_id}/overview'

    def gen_project_url(
        self, project_id: str, organization_id: Optional[str] = None, base_url: Optional[str] = None
    ) -> str:
        organization_id = organization_id or self.get_current_organization_id()
        base_url = base_url or self.get_base_url()
        return f'{base_url}/company/{organization_id}/project/{project_id}'

    def gen_file_url(self, file_id: str, base_url: Optional[str] = None) -> str:
        base_url = base_url or self.get_base_url()
        return f'{base_url}/files/{file_id}'

    def delete_items_from_task(self, task_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/delete/{task_id}/all'
        self.delete(url=url, params=cast_params(organization_id=organization_id))
        # TODO: [TAGME-3039] return status

    def delete_some_items_from_task(
        self, task_id: str, files: List[str], organization_id: Optional[str] = None
    ) -> None:
        url = f'/delete/{task_id}'
        self.post(url=url, json=cast_params(uids=files), params=cast_params(organization_id=organization_id))

    def poll_for_task_state(
        self,
        task_id: str,
        state: TaskState,
        retry_amount: int = 15,
        wait_seconds: float = 3,
        organization_id: Optional[str] = None,
    ) -> TaskState:
        task = None
        for _ in range(retry_amount):
            sleep(wait_seconds)
            task = self.get_task(task_id, organization_id=organization_id)
            if task.state is state:
                return state
        else:  # pylint: disable=W0120
            if isinstance(task, TaskData):
                raise ValueError(f'Incorrect task state {task.state}, expected {state}')
        raise ValueError('No task were selected')

    def set_task_payload(self, task_id: str, payload: dict, organization_id: Optional[str] = None) -> dict:
        url = f'api/v0/tasks/{task_id}/payload'
        if 'payload' not in payload:
            payload = dict(payload=payload)
        resp = self.put(url=url, json=payload, params=cast_params(organization_id=organization_id))
        return resp.get('payload', {})

    def get_task_payload(self, task_id: str, organization_id: Optional[str] = None) -> dict:
        url = f'api/v0/tasks/{task_id}/payload'
        resp = self.get(url=url, params=cast_params(organization_id=organization_id))
        return resp.get('payload', {})

    def delete_task_payload(self, task_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/tasks/{task_id}/payload'
        return self.delete(url=url, params=cast_params(organization_id=organization_id))

    # -----------------------------------------------------------------------------
    #                                  Invites
    # -----------------------------------------------------------------------------
    def get_invites(
        self,
        active: bool = True,
        page: Optional[int] = None,
        size: Optional[int] = None,
        organization_id: Optional[str] = None,
    ) -> List[InviteData]:
        url = 'api/v0/invites'
        resp = self.get(
            url=url,
            params=cast_params(
                organization_id=organization_id,
                active=active,
                page=page,
                size=size,
                org_id=organization_id,
                map_keys=[('org_id', 'org_id[]')],
            ),
        )
        return [from_dict(data_class=InviteData, data=item) for item in resp['items']]

    def get_invite(self, uid: str, organization_id: Optional[str] = None) -> InviteData:
        url = f'api/v0/invite/{uid}'
        resp = self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=InviteData, data=resp)

    def delete_invite(self, uid: str, organization_id: Optional[str] = None) -> InviteData:
        url = f'api/v0/invite/{uid}'
        return self.delete(url=url, params=cast_params(organization_id=organization_id))

    def put_invite(self, data: InviteData) -> InviteData:
        url = f'api/v0/invite/{data.uid}'
        resp = self.put(url=url, json=dataclass_to_dict(data), params=cast_params(organization_id=data.organization_id))
        return from_dict(data_class=InviteData, data=resp)

    def create_invite(self, data: InviteRequest) -> InviteData:
        url = 'api/v0/invite'
        resp = self.post(
            url=url, json=dataclass_to_dict(data), params=cast_params(organization_id=data.organization_id)
        )
        return from_dict(data_class=InviteData, data=resp)

    def create_invite_request(self, invite_id: str, organization_id: Optional[str] = None) -> InviteApplication:
        url = 'api/v0/inviterequest'
        resp = self.post(
            url=url,
            json=cast_params(invite_id=invite_id),
            headers=self.marker_header(),
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=InviteApplication, data=resp)

    def get_invites_pending(
        self, organization_id: Optional[str] = None, invite_name: Optional[str] = None, state: str = 'NEW'
    ) -> List[InviteApplication]:
        organization_id = organization_id or self.get_current_organization_id()
        url = 'api/v0/inviterequests'
        resp = self.get(url=url, params=cast_params(state=state, org_id=organization_id))
        decoded_resp = [from_dict(data_class=InviteApplication, data=item) for item in resp['items']]
        if invite_name:
            return [item for item in decoded_resp if item.invite_name == invite_name]
        else:
            return decoded_resp

    def accept_invites(
        self, invite_request_ids: List[str], pool_ids: Optional[List[str]] = None, organization_id: Optional[str] = None
    ) -> None:
        organization_id = organization_id or self.get_current_organization_id()
        url = 'api/v0/inviterequests/approve'
        self.put(
            url=url,
            json=cast_params(pool_ids=pool_ids, invite_request_ids=invite_request_ids, organization_id=organization_id),
        )

    def decline_invites(self, invite_request_ids: List[str], organization_id: Optional[str] = None) -> None:
        organization_id = organization_id or self.get_current_organization_id()
        url = 'api/v0/inviterequests/reject'
        self.put(url=url, json=cast_params(invite_request_ids=invite_request_ids, organization_id=organization_id))

    # -----------------------------------------------------------------------------
    #                                  POOL
    # -----------------------------------------------------------------------------

    def get_organization_pools(
        self, organization_id: Optional[str] = None, page: Optional[int] = None, size: Optional[int] = None
    ) -> List[Pool]:
        organization_id = organization_id or self.get_current_organization_id()
        url = 'api/v0/pools'
        resp = self.get(
            url=url, params=cast_params(withMembersCount=True, organization_id=organization_id, page=page, size=size)
        )
        return [from_dict(data_class=Pool, data=item) for item in resp['items']]

    def attach_user_to_pool(self, pool_id: str, user_id: str, organization_id: Optional[str] = None) -> bool:
        url = f'api/v0/pool/{pool_id}/attach/{user_id}'
        resp = self.post(
            url=url,
            response_type=ResponseType.TEXT_RESPONSE,
            ignore_statuses=404,
            params=cast_params(organization_id=organization_id),
        )
        return resp is not None

    def detach_user_from_pool(self, pool_id: str, user_id: str, organization_id: Optional[str] = None) -> bool:
        url = f'api/v0/pool/{pool_id}/detach/{user_id}'
        resp = self.post(
            url=url,
            response_type=ResponseType.TEXT_RESPONSE,
            ignore_statuses=404,
            params=cast_params(organization_id=organization_id),
        )
        return resp is not None

    def create_pool(self, markers: List[str], name: str, organization_id: Optional[str] = None) -> Pool:
        url = 'api/v0/pool'
        organization_id = organization_id or self.get_current_organization_id()
        json_data = cast_params(markers=markers, name=name, organization_id=organization_id)
        resp = self.post(url=url, json=json_data, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=Pool, data=resp)

    def get_pool(
        self, pool_id: str, with_markers: Optional[bool] = None, organization_id: Optional[str] = None
    ) -> Pool:
        url = f'api/v0/pool/{pool_id}'
        resp = self.get(url=url, params=cast_params(withMarkers=with_markers, organization_id=organization_id))
        if isinstance(resp, dict):
            cleared_members = [item for item in resp.get('members', []) if item.get('person') is not None]
            resp['members'] = cleared_members
        return from_dict(data_class=Pool, data=resp)

    def update_pool(self, pool_id: str, name: str, organization_id: Optional[str] = None) -> Pool:
        url = f'api/v0/pool/{pool_id}'
        json_data = cast_params(name=name)
        resp = self.put(url=url, json=json_data, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=Pool, data=resp)

    def delete_pool(self, pool_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/pool/{pool_id}'
        self.delete(url=url, params=cast_params(organization_id=organization_id))

    def detach_markers(
        self, pool_id: str, uids: List[str], organization_id: Optional[str] = None
    ) -> ErrorMarkersResponse:
        url = f'api/v0/pool/{pool_id}/detach'
        resp = self.post(url=url, json=cast_params(uids=uids), params=cast_params(organization_id=organization_id))
        return from_dict(ErrorMarkersResponse, resp)

    def move_markers(
        self, pool_id: str, target_pool: str, uids: List[str], organization_id: Optional[str] = None
    ) -> ErrorMarkersResponse:
        url = f'api/v0/pool/{pool_id}/move'
        resp = self.post(
            url=url,
            json=cast_params(target_pool=target_pool, uids=uids),
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(ErrorMarkersResponse, resp)

    # -----------------------------------------------------------------------------
    #                                  MARKUP
    # -----------------------------------------------------------------------------

    def get_tasks_for_markup(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
    ) -> List[TaskflowTaskData]:
        url = 'api/v0/taskflow/projects'
        resp = self.get(
            url=url,
            params=cast_params(page=page, size=size, query=query),
            headers=self.marker_header(),
        )

        return [from_dict(data_class=TaskflowTaskData, data=item) for item in resp['items']]

    def download_attachment(self, attachment_url: str, dir_path: str, organization_id: Optional[str] = None) -> str:
        if 'http' in attachment_url:
            url = attachment_url.split('/', 3)[-1]
        else:
            url = attachment_url

        attachment_id = attachment_url.rsplit('/', 1)[-1]

        params = cast_params(organization_id=organization_id)
        content_type, raw_resp = self.get(url=url, params=params, response_type=ResponseType.FILE_RESPONSE)
        fpath = (Path(dir_path) / attachment_id).with_suffix(mimetypes.guess_extension(content_type) or '')
        with open(fpath, 'wb') as f:
            f.write(raw_resp)
        return str(fpath)

    def download_attachments(self, task_id: str, dir_path: str, organization_id: Optional[str] = None) -> List[str]:
        url = 'api/v0/assignments'
        params = cast_params(
            task_id=task_id,
            file_format='json',
            organization_id=organization_id,
            map_keys=[('file_format', 'format')],
        )
        raw_resp = self.get(url=url, params=params)

        result: List[str] = []
        for item in raw_resp:
            for attachment_url in find_attachments(item['result']):
                fname = self.download_attachment(attachment_url, dir_path)
                result.append(fname)
        return result

    def save_attachment(
        self, token: str, data: Union[bytes, str], filename: str, content_type: Optional[str] = None
    ) -> str:
        url = f'api/v0/attachment/{token}'

        content_type = content_type or mimetypes.guess_type(filename)[0] or 'application/octet-stream'

        form = [{'name': 'file', 'value': data, 'filename': filename, 'content_type': content_type}]
        resp = self.post(url=url, form=form, headers=self.marker_header())

        return resp['attachment_id']

    def get_markup_task(self, task_id: str) -> MarkupTask:
        url = f'api/v0/taskflow/task/{task_id}/assignment'
        try:
            resp = self.get(url=url, headers=self.marker_header())
            if resp is None:
                return MarkupTask.build_empty_task()
            return from_dict(data_class=MarkupTask, data=resp)
        except HTTPError as error:
            if error.response and error.response.status_code == 404:
                return MarkupTask.build_empty_task()
            raise

    def submit_markup_task(self, task_id: str, assignment_id: str, markup_result: Dict[str, Any]) -> None:
        url = f'api/v0/taskflow/task/{task_id}/assignment/{assignment_id}'
        self.post(url=url, json=markup_result, headers=self.marker_header())

    def review_markup(self, review: MarkupReview, organization_id: str) -> None:
        url = f'/api/v0/taskflow/assignments/{review.assignment_id}'
        req_body = dataclass_to_dict(review, exclude=('assignment_id',), map_keys=[('comment', 'reviewer_comment')])
        self.put(url=url, json=req_body, organization_id=organization_id)

    def get_markup_result(self, assignment_id: str, organization_id: str) -> Optional[MarkupResult]:
        url = f'/api/v0/taskflow/assignments/{assignment_id}'
        try:
            response = self.get(url=url, organization_id=organization_id)
        except HTTPError as error:
            if error.response and (
                (error.response.status_code == 400 and "Assignment not found" in error.response.reason)
                or error.response.status_code == 404
            ):
                return None
            raise

        return from_dict(data_class=MarkupResult, data=response)

    def get_markup_results(  # pylint: disable=R0913
        self,
        task_id: str,
        organization_id: str,
        marker_ids: Optional[List[str]] = None,
        file_name: Optional[str] = None,
        file_ids: Optional[List[str]] = None,
        statuses: Optional[List[str]] = None,
        file_types: Optional[List[FileType]] = None,
        submitted_ats: Optional[List[date]] = None,
        assignment_ids: Optional[List[str]] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        sort_field: Optional[MarkupResultSortField] = None,
        sort_order: Optional[SortOrder] = None,
    ) -> MarkupResults:
        file_types_assoc = {
            FileType.STUDY: 'study',
            FileType.CONTROL: 'control',
            FileType.DATA: 'data',
        }
        url = '/api/v0/taskflow/assignments'
        params = cast_params(
            task_id=task_id,
            marker_ids=marker_ids,
            file_name=file_name,
            item_ids=file_ids,
            statuses=statuses,
            item_types=[file_types_assoc[t] for t in file_types if t in file_types_assoc] if file_types else None,
            submitted_ats=submitted_ats,
            assignment_ids=assignment_ids,
            page=page,
            size=size,
            sort_field=sort_field,
            sort_order=sort_order,
            map_keys=[
                ('marker_ids', 'marker_id[]'),
                ('item_ids', 'item_id[]'),
                ('statuses', 'status[]'),
                ('item_types', 'item_type[]'),
                ('submitted_ats', 'submitted[]'),
                ('assignment_ids', 'assignment_id[]'),
            ],
        )

        response = self.get(url=url, organization_id=organization_id, params=params)
        return from_dict(data_class=MarkupResults, data=response)

    # -----------------------------------------------------------------------------
    #                                  STORAGE
    # -----------------------------------------------------------------------------

    def wait_until_sdct_done(self, task_id: str, retry_time: int = 10, organization_id: Optional[str] = None) -> None:
        while True:
            sp_res = self.get_storage_proxy_info(task_id=task_id, organization_id=organization_id)
            if sp_res is not None and sp_res.checking_files_count > 0:
                sleep(retry_time)
            else:
                break

    def get_storage_proxy_info(self, task_id: str, organization_id: Optional[str] = None) -> Optional[SPInfo]:
        url = f'api/v0/storage/{task_id}/stat'
        resp = self.get(url=url, ignore_statuses=404, params=cast_params(organization_id=organization_id))
        if resp is None:
            return None
        return from_dict(data_class=SPInfo, data=resp)

    def _get_storage_proxy_files(self, task_id: str, organization_id: Optional[str] = None) -> List[TaskFile]:
        url = f'api/v0/storageproxy/{task_id}'
        resp = self.get(url=url, params=cast_params(organization_id=organization_id))
        return [from_dict(data_class=TaskFile, data=item) for item in resp['items']]

    def upload_folder_to_task(
        self,
        task_id: str,
        folder: Union[str, Path],
        batch_size: int = BATCH_SIZE,
        exclude_ext_filter: Optional[Set[str]] = None,
        organization_id: Optional[str] = None,
    ) -> UploadFilesResult:
        folder = Path(folder)

        files: List[Path] = []
        for f in folder.iterdir():
            if not f.is_file():
                continue
            if exclude_ext_filter is not None and f.suffix in exclude_ext_filter:
                continue
            files.append(f)

        return self.upload_files(task_id, files, batch_size, organization_id=organization_id)

    def upload_files(
        self,
        task_id: str,
        filepaths: Sequence[Union[str, Path]],
        batch_size: int = BATCH_SIZE,
        organization_id: Optional[str] = None,
    ) -> UploadFilesResult:
        url = f'api/v0/stream_upload/{task_id}'

        def check_task_upload(batch_files: List[Union[str, Path]]) -> List[Union[str, Path]]:
            return self._check_task_uploaded(task_id, batch_files)

        return self.upload_files_base(
            url=url,
            filepaths=filepaths,
            batch_size=batch_size,
            organization_id=organization_id,
            check_upload=check_task_upload,
        )

    def upload_files_base(
        self,
        url: str,
        filepaths: Sequence[Union[str, Path]],
        check_upload: Callable,
        batch_size: int = BATCH_SIZE,
        organization_id: Optional[str] = None,
    ) -> UploadFilesResult:
        files_num = len(filepaths)
        logger.debug('Uploading %s files to tagme storage %s', files_num, url)
        result = UploadFilesResult(created_files=[], errors=[])

        for batch_files in chunks(filepaths, n=batch_size, tqdm_on=True):
            for i in range(UPLOAD_ATTEMPTS):
                try:
                    with ExitStack() as stack:
                        files = [
                            (
                                'file',
                                (
                                    path.name,
                                    stack.enter_context(open(path, 'rb')),
                                    mimetypes.guess_type(str(path))[0] or 'application/json',
                                ),
                            )
                            for path in map(Path, batch_files)
                        ]
                        # couldn't use if due to "for" of files
                        resp = self.post(
                            url,
                            files=files,
                            raise_for_status=False,
                            params=cast_params(organization_id=organization_id),
                        )
                    if 'error' in resp:
                        result.errors.append(resp['error'])
                        logger.error('error uploading files: %s', resp['error'])
                        break
                    logger.info(resp)
                    resp = from_dict(data_class=UploadFilesResult, data=resp)
                    result.created_files.extend(resp.created_files)
                    result.errors.extend(resp.errors)
                    break

                except (
                    HTTPError,
                    RuntimeError,
                    json.JSONDecodeError,
                ):
                    sleep(0.5)
                    unaploaded = check_upload(batch_files)
                    logger.info('error uploading files %s\nattempt no. %s', unaploaded, i)
                    batch_files = unaploaded
                    if i == UPLOAD_ATTEMPTS - 1:
                        raise

        return result

    def _check_task_uploaded(
        self, task_id: str, batch_files: List[Union[str, Path]], organization_id: Optional[str] = None
    ) -> List[Union[str, Path]]:
        if self.get_storage_proxy_info(task_id) is not None:
            uploaded = self._get_storage_proxy_files(task_id, organization_id=organization_id)

        else:
            uploaded = self.get_task_files(task_id, organization_id=organization_id)

        pool = {Path(x).name: x for x in batch_files}
        missing = set(pool.keys()).difference(x.name for x in uploaded)
        return [pool[x] for x in missing]

    def update_meta_data(
        self, task_id: str, data: Union[List[Dict], List[UpdateMetaDataRequest]], organization_id: Optional[str] = None
    ) -> dict:
        if data and isinstance(data[0], UpdateMetaDataRequest):
            data = list(map(dataclass_to_dict, data))

        url = f'api/v0/meta/{task_id}'
        return self.patch(url, json=data, params=cast_params(organization_id=organization_id))

    def get_meta_data(
        self, task_id: str, file_uid: str, types: Optional[List[MetaType]] = None, organization_id: Optional[str] = None
    ) -> MetaData:
        url = f'api/v0/storage/{task_id}/meta'
        resp = self.get(
            url=url,
            params=cast_params(
                types=types or (MetaType.PREMARKUP, MetaType.CONTROL, MetaType.EXPLANATION),
                file_uid=file_uid,
                map_keys=[('types', 'types[]')],
                organization_id=organization_id,
            ),
        )
        if resp is None:
            return MetaData()

        return from_dict(data_class=MetaData, data=resp)

    def upload_single_file(self, url: str, file: Path, **kwargs: Any) -> Optional[Dict]:
        attempts = UPLOAD_ATTEMPTS
        file = Path(file)
        while attempts > 0:
            try:
                with open(file.absolute(), mode='rb') as file_object:
                    files = {
                        'file': (
                            file.name,
                            file_object,
                            mimetypes.guess_type(str(file))[0] or 'application/json',
                        )
                    }

                    return self.post(url=url, files=files, **kwargs)

            except HTTPError as exc:
                if attempts <= 1 or (exc.response and exc.response.status_code >= 400):
                    raise
                sleep(0.1)
                attempts -= 1
            except RuntimeError:
                if attempts <= 1:
                    raise
                sleep(0.1)
                attempts -= 1

        return None

    def upload_table(
        self,
        task_id: str,
        file: Path,
        delimeter: Optional[str] = None,
        quotechar: Optional[str] = None,
        escapechar: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> None:
        url = f'api/v0/storage/{task_id}/upload_table_data'
        self.upload_single_file(
            url=url,
            file=file,
            params=cast_params(
                delimeter=delimeter, quotechar=quotechar, escapechar=escapechar, organization_id=organization_id
            ),
            response_type=ResponseType.RAW_RESPONSE,
        )

    def download_table_results(
        self,
        task_id: str,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        file_format: ExportFormat = ExportFormat.CSV,
        organization_id: Optional[str] = None,
    ) -> None:
        url = 'api/v0/assignments'
        params = cast_params(
            task_id=task_id,
            date_from=date_from,
            date_to=date_to,
            file_format=file_format,
            map_keys=[('file_format', 'format')],
            organization_id=organization_id,
        )
        raw_resp = self.get(url=url, params=params, response_type=ResponseType.RAW_RESPONSE)
        results = (Path(__file__).parent / 'results').with_suffix(EXPORT_SUFFIX[file_format])
        with open(results, 'wb') as f:
            f.write(raw_resp)

    def get_task_files(
        self,
        task_id: str,
        query: Optional[str] = None,
        types: Optional[List[Union[FileType, str]]] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        organization_id: Optional[str] = None,
    ) -> List[TaskFile]:
        url = f'api/v0/storage/{task_id}'
        adhoc_types = [t.value.lower() if isinstance(t, FileType) else t.lower() for t in types or []]
        # TODO(cerikoff): remove this adhock when input type will be == output type
        resp = self.get(
            url=url,
            params=cast_params(
                page=page,
                size=size,
                query=query,
                types=adhoc_types,
                map_keys=[('types', 'types[]')],
                organization_id=organization_id,
            ),
        )
        return [from_dict(data_class=TaskFile, data=_) for _ in resp['items']]

    def get_task_files_meta(self, task_id: str, organization_id: Optional[str] = None) -> List[FileMetaData]:
        url = f'api/v0/storage/{task_id}/meta/all'
        resp = self.get(url=url, params=cast_params(organization_id=organization_id))
        return [from_dict(data_class=FileMetaData, data=_) for _ in resp]

    def download_file(self, task_id: str, file_id: str, organization_id: Optional[str] = None) -> bytes:
        url = f'api/v0/storage/{task_id}/{file_id}'
        return self.get(
            url=url, response_type=ResponseType.RAW_RESPONSE, params=cast_params(organization_id=organization_id)
        )

    def disable_control_task(self, task_id: str, file_uid: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/storage/{task_id}/{file_uid}/disable'
        return self.put(
            url=url, response_type=ResponseType.RAW_RESPONSE, params=cast_params(organization_id=organization_id)
        )

    def get_file(self, task_id: str, file_uid: str, organization_id: Optional[str] = None) -> TaskFile:
        url = f'api/v0/storage/{task_id}/{file_uid}/info'
        resp = self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskFile, data=resp)

    def get_all_files(
        self,
        task_id: str,
        query: Optional[str] = None,
        types: Optional[List[Union[FileType, str]]] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        organization_id: Optional[str] = None,
    ) -> List[TaskFile]:
        url = f'api/v0/storage/{task_id}/all_files'
        adhoc_types = [t.value.lower() if isinstance(t, FileType) else t for t in types or []]
        # TODO(cerikoff): remove this adhock when input type will be == output type
        resp = self.get(
            url=url,
            params=cast_params(
                page=page,
                size=size,
                query=query,
                types=adhoc_types,
                map_keys=[('types', 'types[]')],
                organization_id=organization_id,
            ),
        )
        return [from_dict(data_class=TaskFile, data=item) for item in resp['items']]

    # -----------------------------------------------------------------------------
    #                                  EMPLOYEES
    # -----------------------------------------------------------------------------

    def add_employee_to_organization(
        self, person_id: str, roles: List[str] = None, organization_id: str = None
    ) -> Employee:
        url = "api/v0/employee"
        if not roles:
            roles = []
        resp = self.post(
            url=url,
            json=cast_params(person_id=person_id, roles=roles, organization_id=organization_id),
        )
        return from_dict(data_class=Employee, data=resp)

    def set_employee_info(
        self,
        employee_id: str,
        profile: Dict[str, Any] = None,
        report: Dict[str, Any] = None,
        config: Dict[str, Any] = None,
        organization_id: Optional[str] = None,
    ) -> Employee:
        url = f'api/v0/employee/{employee_id}'
        resp = self.put(
            url=url, json=cast_params(profile=profile, report=report, config=config, organization_id=organization_id)
        )
        return from_dict(data_class=Employee, data=resp)

    def update_employee_info(
        self,
        employee_id: str,
        profile: Dict[str, Any] = None,
        report: Dict[str, Any] = None,
        config: Dict[str, Any] = None,
        organization_id: Optional[str] = None,
    ) -> Employee:
        employee = self.get_employee_info(employee_id)
        employee.profile.update(profile or {})
        employee.report.update(report or {})
        employee.config.update(config or {})
        profile = employee.profile
        report = employee.report
        config = employee.config
        url = f'api/v0/employee/{employee_id}'
        resp = self.put(
            url=url, json=cast_params(profile=profile, report=report, config=config, organization_id=organization_id)
        )
        return from_dict(data_class=Employee, data=resp)

    def get_employee_info(
        self,
        employee_id: str,
        with_pools: Optional[bool] = None,
        with_info: Optional[bool] = None,
        organization_id: Optional[str] = None,
    ) -> Employee:
        url = f'api/v0/employee/{employee_id}'
        resp = self.get(
            url=url, params=cast_params(withPools=with_pools, withPersonInfo=with_info, organization_id=organization_id)
        )
        return from_dict(data_class=Employee, data=resp)

    def get_employees(
        self,
        query: Optional[str] = None,
        person_ids: Optional[List[str]] = None,
        with_pools: Optional[bool] = None,
        with_info: Optional[bool] = None,
        organization_id: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        active: Optional[bool] = None,
    ) -> List[Employee]:
        organization_id = organization_id or self.get_current_organization_id()
        url = 'api/v0/employees'
        resp = self.get(
            url=url,
            params=cast_params(
                withPools=with_pools,
                withPersonInfo=with_info,
                query=query,
                org_id=organization_id,
                page=page,
                size=size,
                active=active,
                person_id=person_ids,
                map_keys=[('person_id', 'person_id[]')],
            ),
        )
        return [from_dict(data_class=Employee, data=_) for _ in resp['items']]

    # -----------------------------------------------------------------------------
    #                                  MARKERS
    # -----------------------------------------------------------------------------

    def get_marker_info(
        self, marker_id: str, with_pools: bool, with_info: bool, organization_id: Optional[str] = None
    ) -> Employee:
        employees = self.get_employees(
            with_pools=with_pools, with_info=with_info, person_ids=[marker_id], organization_id=organization_id
        )

        if not employees:
            raise ValueError(f'not found marker with id={marker_id}')

        return employees[0]

    def get_persons(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
        emails: Optional[List[str]] = None,
        with_organizations: Optional[bool] = None,
        organization_id: Optional[str] = None,
        person_ids: Optional[List[str]] = None,
    ) -> List[Person]:
        url = 'api/v0/persons'
        resp = self.get(
            url=url,
            params=cast_params(
                page=page,
                size=size,
                query=query,
                emails=emails,
                withOrganizations=with_organizations,
                organization_id=organization_id,
                person_ids=person_ids,
                map_keys=[('person_ids', 'person_id[]')],
            ),
        )
        return [from_dict(data_class=Person, data=_) for _ in resp['items']]

    def add_marker(
        self, marker_email: str, pools: List[str], organization_id: Optional[str] = None
    ) -> ErrorMarkersResponse:
        return self.add_markers(emails=[marker_email], pools=pools, organization_id=organization_id)

    def add_markers(
        self, emails: List[str], pools: List[str], organization_id: Optional[str] = None
    ) -> ErrorMarkersResponse:
        url = 'api/v0/markers'
        resp = self.post(
            url=url, json=cast_params(emails=emails, pools=pools), params=cast_params(organization_id=organization_id)
        )
        return from_dict(ErrorMarkersResponse, resp)

    def get_marker_project_stats(
        self,
        project_id: str,
        from_date: Union[Tuple[int, int, int], str],  # year, month, day
        to_date: Union[Tuple[int, int, int], str],  # year, month, day
        types: Iterable[str] = ('markers',),  # tasks
        stats_format: str = 'csv',
        organization_id: Optional[str] = None,
    ) -> bytes:
        url = f'api/v0/statistics/project/{project_id}/export'
        from_date = parse_date_tuple(from_date)
        to_date = parse_date_tuple(to_date)
        params = cast_params(
            from_date=from_date,
            to_date=to_date,
            format=stats_format,
            types=types,
            organization_id=organization_id,
            map_keys=[('from_date', 'from'), ('to_date', 'to'), ('types', 'types[]')],
        )
        return self.get(url=url, params=params, response_type=ResponseType.RAW_RESPONSE)

    def get_marker_stats(
        self,
        date_from: str,
        date_to: str,
        types: Iterable[str] = ('markers',),
        stats_format: str = 'csv',
        organization_id: Optional[str] = None,
    ) -> bytes:
        organization_id = organization_id or self.get_current_organization_id()
        url = f'api/v0/statistics/organization/{organization_id}/export'
        params = cast_params(
            organization_id=organization_id,
            date_from=date_from,
            date_to=date_to,
            types=types,
            format=stats_format,
            map_keys=[('date_from', 'from'), ('date_to', 'to'), ('types', 'types[]')],
        )
        return self.get(url=url, params=params, response_type=ResponseType.RAW_RESPONSE)

    # -----------------------------------------------------------------------------
    #                                  SKILLS
    # -----------------------------------------------------------------------------

    def create_skill(self, name: str, organization_id: Optional[str] = None) -> Skill:
        organization_id = organization_id or self.get_current_organization_id()
        url = 'api/v0/skill'
        resp = self.post(url=url, json=cast_params(organization_id=organization_id, name=name))
        return from_dict(data_class=Skill, data=resp)

    def get_skill(self, skill_id: str, organization_id: Optional[str] = None) -> Skill:
        organization_id = organization_id or self.get_current_organization_id()
        url = f'api/v0/skill/{skill_id}'
        resp = self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=Skill, data=resp)

    def disable_skill(self, skill_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/skill/{skill_id}/disable'
        self.post(url=url, params=cast_params(organization_id=organization_id))

    def enable_skill(self, skill_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/skill/{skill_id}/enable'
        self.post(url=url, params=cast_params(organization_id=organization_id))

    def get_skills_list(
        self,
        query: Optional[str] = None,
        with_markers_count: Optional[bool] = None,
        organization_id: Optional[str] = None,
        size: Optional[int] = None,
        page: Optional[int] = None,
    ) -> List[Skill]:
        organization_id = organization_id or self.get_current_organization_id()
        url = 'api/v0/skills'
        params = cast_params(
            orgId=organization_id,
            withMarkersCount=with_markers_count,
            query=query,
            page=page,
            size=size,
        )
        resp = self.get(url=url, params=params)
        return [from_dict(data_class=Skill, data=item) for item in resp['items']]

    def get_markers_skills_list(
        self,
        query: Optional[str] = None,
        size: Optional[int] = None,
        page: Optional[int] = None,
        organization_id: Optional[str] = None,
        with_info: Optional[bool] = None,
    ) -> List[MarkerSkill]:
        organization_id = organization_id or self.get_current_organization_id()
        url = 'api/v0/skills/by_marker'
        params = cast_params(
            orgId=organization_id,
            page=page,
            size=size,
            query=query,
            withPersonInfo=with_info,
        )
        resp = self.get(url=url, params=params)
        return [from_dict(data_class=MarkerSkill, data=_) for _ in resp['items']]

    def set_marker_skill(
        self,
        marker_id: str,
        skill_id: str,
        value: int,
        organization_id: Optional[str] = None,
    ) -> SetMarkerSkillResponse:
        url = f'api/v0/skill/{skill_id}/{marker_id}'
        resp = self.put(url=url, json=cast_params(value=value, organization_id=organization_id))
        return from_dict(data_class=SetMarkerSkillResponse, data=resp)

    def update_skill(
        self,
        skill_id: str,
        name: str,
        window_size: int = 10,
        organization_id: Optional[str] = None,
    ) -> Skill:
        url = f'api/v0/skill/{skill_id}'
        resp = self.put(url=url, json=cast_params(name=name, window_size=window_size, organization_id=organization_id))
        return from_dict(data_class=Skill, data=resp)

    # -----------------------------------------------------------------------------
    #                                  DATASETS
    # -----------------------------------------------------------------------------

    def create_dataset(
        self,
        name: str,
        data_classification_level: Optional[str] = None,
        access: str = 'public',
        data_source: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> Dataset:
        url = 'api/v0/datasets'

        resp = self.post(
            url=url,
            json={
                'name': name,
                'access': access,
                'data_classification_level': data_classification_level or self.config.data_category,
                'data_source': data_source or self.config.data_source,
                'organization_id': organization_id,
            },
        )
        return from_dict(data_class=Dataset, data=resp)

    def update_dataset(
        self,
        dataset_id: str,
        name: str,
        data_classification_level: Optional[str] = None,
        data_source: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> Dataset:
        url = f'api/v0/datasets/{dataset_id}'

        resp = self.put(
            url=url,
            json={
                'id': dataset_id,
                'name': name,
                'data_classification_level': data_classification_level or self.config.data_category,
                'data_source': data_source or self.config.data_source,
                'organization_id': organization_id,
            },
        )
        return from_dict(data_class=Dataset, data=resp)

    def get_dataset(self, dataset_id: str, organization_id: Optional[str] = None) -> Dataset:
        url = f'api/v0/datasets/{dataset_id}'

        resp = self.get(
            url=url,
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=Dataset, data=resp)

    def get_datasets(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> List[Dataset]:
        if size is None:
            size = 100
        url = 'api/v0/datasets'

        resp = {'has_next': True, 'items': []}
        results: List[Dataset] = []

        if page is None:
            page = 1
            while resp['has_next']:
                resp = self.get(
                    url=url,
                    params=cast_params(
                        page=page,
                        size=size,
                        query=query,
                        organization_id=organization_id,
                    ),
                )
                page += 1
                results.extend([from_dict(data_class=Dataset, data=item) for item in resp['items']])  # type: ignore
        else:
            resp = self.get(
                url=url,
                params=cast_params(
                    page=page,
                    size=size,
                    query=query,
                    organization_id=organization_id,
                ),
            )
            results.extend([from_dict(data_class=Dataset, data=item) for item in resp['items']])  # type: ignore
        return results

    # ----------items-----------
    def get_dataset_files(
        self,
        dataset_id: str,
        organization_id: Optional[str] = None,
    ) -> List[DatasetFile]:
        url = f'api/v0/datasets/{dataset_id}/files/info'

        resp = {'has_next': True, 'items': []}
        results: List[DatasetFile] = []
        page = 1
        while resp['has_next']:
            resp = self.get(
                url=url,
                params=cast_params(
                    page=page,
                    size=100,
                    map_keys=[('types', 'types[]')],
                    organization_id=organization_id,
                ),
            )
            page += 1
            results.extend([from_dict(data_class=DatasetFile, data=item) for item in resp['items']])  # type: ignore

        return results

    def get_dataset_file(
        self,
        file_id: str,
        organization_id: Optional[str] = None,
    ) -> DatasetFile:
        url = f"/api/v0/files/{file_id}/info"

        resp = self.get(
            url=url,
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=DatasetFile, data=resp)

    def upload_folder_to_dataset(
        self,
        dataset_id: str,
        folder: Union[str, Path],
        batch_size: int = BATCH_SIZE,
        exclude_ext_filter: Optional[Set[str]] = None,
        organization_id: Optional[str] = None,
    ) -> UploadFilesResult:
        folder = Path(folder)

        files: List[Path] = []
        for f in folder.iterdir():
            if not f.is_file():
                continue
            if exclude_ext_filter is not None and f.suffix in exclude_ext_filter:
                continue
            files.append(f)

        return self.upload_dataset_files(dataset_id, files, batch_size, organization_id=organization_id)

    def upload_dataset_files(
        self,
        dataset_id: str,
        filepaths: Sequence[Union[str, Path]],
        batch_size: int = BATCH_SIZE,
        organization_id: Optional[str] = None,
    ) -> UploadFilesResult:
        url = f'api/v0/datasets/{dataset_id}/files'

        def check_dataset_upload(batch_files: List[Union[str, Path]]) -> List[Union[str, Path]]:
            return self._check_dataset_uploaded(dataset_id, batch_files)

        return self.upload_files_base(
            url=url,
            filepaths=filepaths,
            batch_size=batch_size,
            organization_id=organization_id,
            check_upload=check_dataset_upload,
        )

    def _check_dataset_uploaded(
        self, dataset_id: str, batch_files: List[Union[str, Path]], organization_id: Optional[str] = None
    ) -> List[Union[str, Path]]:
        uploaded = self.get_dataset_files(dataset_id, organization_id=organization_id)

        pool = {Path(x).name: x for x in batch_files}
        missing = set(pool.keys()).difference(x.name for x in uploaded)
        return [pool[x] for x in missing]

    def download_dataset_file(self, file_id: str, organization_id: Optional[str] = None) -> bytes:
        url = f'api/v0/files/{file_id}'
        return self.get(
            url=url, response_type=ResponseType.RAW_RESPONSE, params=cast_params(organization_id=organization_id)
        )

    def remove_dataset(self, dataset_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/datasets/{dataset_id}'
        self.delete(url=url, params=cast_params(organization_id=organization_id))
