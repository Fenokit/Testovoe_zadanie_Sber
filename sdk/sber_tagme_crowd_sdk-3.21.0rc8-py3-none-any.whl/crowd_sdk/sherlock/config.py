from dataclasses import dataclass
from pathlib import Path
from typing import Union

from dacite import from_dict

from crowd_sdk.core.config import CrowdConfig

SECTION_NAME = 'sherlock'


@CrowdConfig.crowd_config_section(SECTION_NAME)
@dataclass
class SherlockConfig:
    url: str
    token: str

    @staticmethod
    def from_any(
        config: Union[str, Path, dict, CrowdConfig, "SherlockConfig"] = None,
    ) -> 'SherlockConfig':
        config_path = ''  # for logging purposes, will not show any if no path specified

        # TODO(volerog): rewrie this on to: detect file type -> parse -> detect config type -> build_class
        if isinstance(config, (str, Path)):
            config_path = str(config)
            config = CrowdConfig.from_path(config)
        elif isinstance(config, dict):
            config = from_dict(data_class=SherlockConfig, data=config)

        if isinstance(config, CrowdConfig):
            sherlock_config = getattr(config, 'SECTION_NAME')
            assert sherlock_config is not None, f'Fill section {SECTION_NAME} in CrowdConfig: {config} {config_path}'
            return sherlock_config

        if isinstance(config, SherlockConfig):
            return config

        raise TypeError(f'Wrong type for the config {type(config)}')
