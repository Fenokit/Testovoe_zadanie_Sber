from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import urllib3
from dacite import Config, from_dict

from crowd_sdk.core.utils.common import cast_params, urljoin_with_path
from crowd_sdk.core.utils.http import SyncHttpWrapper
from crowd_sdk.sherlock.dataclass import GetAllResponse, SearchStatus, SearchThemesFilter

from .config import CrowdConfig, SherlockConfig

urllib3.disable_warnings()


class SyncSherlockClient:
    def __init__(
        self,
        config: Union[str, Path, dict, CrowdConfig, SherlockConfig] = None,
        http: Optional[SyncHttpWrapper] = None,
    ) -> None:
        self.http = http or SyncHttpWrapper()
        self.config = SherlockConfig.from_any(config)

    def api_docs(self, verify: bool = False) -> Dict[str, str]:
        resp = self.http.get(
            urljoin_with_path(self.config.url, "/api.json"),
            params={"token": self.config.token},
            verify=verify,
        )
        resp.raise_for_status()
        return resp.json()

    def get_all(
        self,
        search_bucket: Optional[str] = None,
        search_themes: Optional[List[str]] = None,
        search_themes_filter: Optional[str] = None,
        search_segments: Optional[List[str]] = None,
        search_timestamp: Optional[str] = None,
        search_status: Optional[str] = None,
        search_character: Optional[str] = None,
        additional_params: Optional[Dict[str, Any]] = None,
        verify: bool = False,
    ) -> GetAllResponse:
        if search_themes_filter:
            SearchThemesFilter(search_themes_filter)
        if search_status:
            SearchStatus(search_status)
        additional_params = additional_params or {}
        params = cast_params(
            map_keys=[
                ("search_bucket", "search[bucket]"),
                ("search_themes", "search[themes]"),
                ("search_themes_filter", "search[themes_filter]"),
                ("search_segments", "search[segments]"),
                ("search_timestamp", "search[timestamp]"),
                ("search_status", "search[status]"),
                ("search_character", "search[character]"),
            ],
            token=self.config.token,
            search_bucket=search_bucket,
            search_themes=search_themes,
            search_themes_filter=search_themes_filter,
            search_segments=search_segments,
            search_timestamp=search_timestamp,
            search_status=search_status,
            search_character=search_character,
            **additional_params,
        )
        resp = self.http.get(
            url=urljoin_with_path(self.config.url, "/api/dialogs/all.json"),
            params=params,
            verify=verify,
        )
        return from_dict(data_class=GetAllResponse, data=resp.json(), config=Config(cast=[Enum]))
