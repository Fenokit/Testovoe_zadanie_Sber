import json
import re
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from enum import Enum
from functools import partial
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Type, TypeVar, Union

import numpy as np
import pandas as pd
from dacite import from_dict
from pandas import DataFrame
from psycopg2.extensions import DECIMAL, AsIs, Float
from psycopg2.extensions import connection as Connection
from psycopg2.extensions import cursor as Cursor
from psycopg2.extensions import new_type, register_adapter, register_type
from psycopg2.pool import ThreadedConnectionPool
from tqdm import tqdm

from crowd_sdk.core.utils.common import chunks
from crowd_sdk.db.config import CrowdConfig, DBConfig

DEFAULT_DB_CONFIG_TAG = 'db'
N_POOLS = 8
MetaType = TypeVar('MetaType')


def change_endpoint(url: str, old_endpoint: str, new_endpoint: str) -> str:
    if old_endpoint.endswith('/'):
        old_endpoint = old_endpoint[:-1]
    if not new_endpoint.endswith('/'):
        new_endpoint = new_endpoint + '/'
    return new_endpoint + re.sub(r'^{0}'.format(re.escape(old_endpoint + '/')), '', url)  # pylint: disable=C0209


def nan_to_null(wrapped_object: Any) -> Any:
    if not np.isnan(wrapped_object):
        return Float(wrapped_object)
    return AsIs('NULL')


def register_decimal_to_float_conversion() -> None:
    dec2float = new_type(
        DECIMAL.values,
        'DEC2FLOAT',
        lambda value, curs: float(value) if value is not None else None,
    )
    register_type(dec2float)


# global psycopg2 adapters
register_adapter(np.int64, AsIs)
register_adapter(float, nan_to_null)
register_decimal_to_float_conversion()


class DataBase:
    DEFAULT_CLOUD = 'internal_cloud'

    def __init__(self, config: Union[str, Path, CrowdConfig, DBConfig] = None, n_pools: int = N_POOLS) -> None:
        if isinstance(config, (str, Path)):
            _config = CrowdConfig.from_path(config)
            assert _config.db is not None, f'Fill db section in {config}'
            self.config = _config.db
        elif isinstance(config, CrowdConfig):
            assert config.db is not None, f'Fill db section in {config}'
            self.config = config.db
        elif isinstance(config, DBConfig):
            self.config = config

        # n_pools * 2 for some additional query like select constraint in upload
        self.connection_pool = self.__create_connection_pool(self.config, n_pools * 2)
        self.n_pools = n_pools
        self.constraints_cache: Dict[str, List[str]] = {}

    @staticmethod
    def __create_connection_pool(config: DBConfig, n_pools: int) -> ThreadedConnectionPool:
        add_kwargs: Dict[str, Any] = {}
        if isinstance(config.port, int):
            add_kwargs["port"] = config.port
        return ThreadedConnectionPool(
            1,
            n_pools,
            host=config.host,
            database=config.database,
            user=config.user,
            password=config.password,
            **add_kwargs,
        )

    @staticmethod
    def _execute_select(cursor: Cursor, select: str, **kwargs: Any) -> Tuple[List[str], List[Any]]:
        if not kwargs:
            cursor.execute(select)
        else:
            cursor.execute(select, kwargs)
        column_names = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        return column_names, rows

    def dbselect(self, select: str, **kwargs: Any) -> DataFrame:
        connection: Connection = self.connection_pool.getconn()

        try:
            with connection.cursor() as cursor:
                if kwargs:
                    kwargs = {name: AsIs(value) for name, value in kwargs.items()}
                column_names, rows = self._execute_select(cursor, select, **kwargs)
                return pd.DataFrame(rows, columns=column_names)
        finally:
            self.connection_pool.putconn(connection)

    @staticmethod
    def get_new_device_id(old_id: str) -> str:
        """Transform if necessary old device id to new notation.
        290b100001190e000011393759474e50 -> 3759474e500100001139190e
        return index + 1, file_stem, sounds_array, current_duration, debug_subs
        Args:
            old_id (str): old id
        Returns:
            str: new id
        """
        if old_id.startswith('290b10') and len(old_id) == 32:
            inter = old_id[8:]
            inter = f'{inter[-10:]}{inter[:-10]}'
            return f'{inter[:12]}{inter[16:]}{inter[12:16]}'
        return old_id

    def upload2db(
        self,
        table_name: str,
        dataset: DataFrame,
        conflict_err: bool = True,
        conflict_upd: bool = False,
    ) -> None:
        connection: Connection = self.connection_pool.getconn()
        try:
            with connection.cursor() as cursor:
                dataset = dataset.replace({np.datetime64('NaT'): None})

                insert_cols = ', '.join(dataset.columns)
                insert_vals = ', '.join(['%s' for _ in dataset.columns])
                insert_conflict = '' if conflict_err else 'ON CONFLICT DO NOTHING'

                inserted_rows_count = 0
                for _, row in dataset.iterrows():
                    values: List[Any] = []
                    for col in dataset.columns:
                        if row[col] is pd.NaT:
                            values.append(None)
                        else:
                            values.append(row[col])
                    if not conflict_upd:
                        insert = f"""
                            INSERT INTO {table_name} ({insert_cols})
                            VALUES ({insert_vals}) {insert_conflict};
                            """
                        cursor.execute(insert, values)
                    else:
                        table_constraint_names_val = ', '.join(self.get_table_constraint_names(table_name))
                        insert = f"""
                            INSERT INTO {table_name} ({insert_cols})
                            VALUES ({insert_vals})
                            ON CONFLICT ON CONSTRAINT {table_constraint_names_val} DO UPDATE
                            SET ({insert_cols}) = ({insert_vals});
                            """
                        cursor.execute(insert, values + values)
                    connection.commit()
                    inserted_rows_count += cursor.rowcount
        finally:
            self.connection_pool.putconn(connection)

    @staticmethod
    def _asdict_factory(dataclass: Any) -> Dict[str, Any]:
        def convert_column(field_name: str, value: Any) -> Tuple[str, Any]:
            if isinstance(value, Enum):
                return field_name, value.value
            if isinstance(value, dict):
                return field_name, json.dumps(value)
            return field_name, value

        return dict(convert_column(field_name, val) for field_name, val in dataclass if val is not None)

    def get_table_constraint_names(self, table_name: str) -> List[str]:
        if table_name in self.constraints_cache:
            return self.constraints_cache[table_name]
        if '.' in table_name:
            schema, _, table = table_name.partition(".")
        else:
            schema, table = 'public', table_name
        select_constraint_names = f"""
            SELECT conname as table_constraints
            FROM pg_catalog.pg_constraint con
                    INNER JOIN pg_catalog.pg_class rel
                            ON rel.oid = con.conrelid
                    INNER JOIN pg_catalog.pg_namespace nsp
                            ON nsp.oid = connamespace
            WHERE nsp.nspname = '{schema}'
                AND rel.relname = '{table}';
        """
        constraints_data = self.select(select=select_constraint_names)
        response = [row['table_constraints'] for row in constraints_data] if constraints_data else []

        self.constraints_cache[table_name] = response
        return response

    def upload_dataclass_process(
        self, items: List[Any], table_name: str, conflict_err: bool, conflict_upd: bool
    ) -> int:
        connection: Connection = self.connection_pool.getconn()
        try:
            with connection.cursor() as cursor:
                inserted_rows_count = 0
                for item in items:
                    item = asdict(item, dict_factory=partial(DataBase._asdict_factory))
                    columns = item.keys()
                    values = [item[column] for column in columns]
                    if not conflict_upd:
                        insert_conflict = '' if conflict_err else 'ON CONFLICT DO NOTHING'
                        insert_statement = f'INSERT INTO {table_name} (%s) VALUES %s {insert_conflict}'
                        cursor.execute(insert_statement, (AsIs(','.join(columns)), tuple(values)))
                    else:
                        table_constraint_names = self.get_table_constraint_names(table_name)
                        insert_statement = (
                            f"INSERT INTO {table_name} (%s) VALUES %s ON "
                            "CONFLICT ON CONSTRAINT %s DO UPDATE set (%s) = %s"
                        )
                        cursor.execute(
                            insert_statement,
                            (
                                AsIs(','.join(columns)),
                                tuple(values),
                                AsIs(','.join(table_constraint_names)),
                                AsIs(','.join(columns)),
                                tuple(values),
                            ),
                        )
                    connection.commit()
                    inserted_rows_count += cursor.rowcount
        finally:
            self.connection_pool.putconn(connection)
        return inserted_rows_count

    def upload_dataclass(
        self,
        table_name: str,
        items: List[Any],
        chunk_size: int = 500,
        conflict_err: bool = True,
        conflict_upd: bool = False,
        tqdm_off: bool = False,
    ) -> int:
        items_chunks = []
        for chunk in chunks(items, chunk_size):
            items_chunks.append(chunk)
        upl_part_func = partial(
            self.upload_dataclass_process, table_name=table_name, conflict_err=conflict_err, conflict_upd=conflict_upd
        )

        with ThreadPoolExecutor(max_workers=self.n_pools) as pool:
            inserted_rows_count = sum(
                list(tqdm(pool.map(upl_part_func, items_chunks), total=len(items_chunks), disable=tqdm_off))
            )

        return inserted_rows_count

    def select(self, select: str, **kwargs: Any) -> List[Dict[str, Any]]:
        connection: Connection = self.connection_pool.getconn()
        try:
            with connection.cursor() as cursor:
                if kwargs:
                    kwargs = {name: AsIs(value) for name, value in kwargs.items()}
                column_names, rows = self._execute_select(cursor, select, **kwargs)
            return [dict(zip(column_names, row)) for row in rows]
        finally:
            self.connection_pool.putconn(connection)

    def select_dataclass(self, select: str, class_type: Type[MetaType], **kwargs: Any) -> Sequence[MetaType]:
        dict_rows = self.select(select=select, **kwargs)
        return [from_dict(data_class=class_type, data=row) for row in dict_rows]

    def custom_query(self, query: str, data: Optional[dict] = None) -> int:
        connection: Connection = self.connection_pool.getconn()
        try:
            with connection.cursor() as cursor:
                cursor.execute(query, data)
                rows_count = cursor.rowcount
                connection.commit()

                return rows_count
        finally:
            self.connection_pool.putconn(connection)

    def custom_query_mth(self, queries: List[str], tqdm_off: bool = True) -> int:
        query_part_func = partial(self.custom_query)

        with ThreadPoolExecutor(max_workers=self.n_pools) as pool:
            rows_count = sum(list(tqdm(pool.map(query_part_func, queries), total=len(queries), disable=tqdm_off)))

        return rows_count
