from pathlib import Path
from typing import Any, Callable, Dict, Type, Union

import yaml
from dacite import DaciteError

from crowd_sdk import DEFAULT_CONFIG
from crowd_sdk.core.utils.common import dataclass_to_dict, envsubst, from_dict, logger

crowd_handlers: Dict[str, Type] = {}


class CrowdConfig:
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self.__configs: Dict[str, Any] = {}

        assert not args, f'All args for crowd config init must be named args, got: {args}'
        for k, v in kwargs.items():
            if k in crowd_handlers:
                if isinstance(v, dict):
                    self.__configs[k] = from_dict(data_class=crowd_handlers[k], data=v)
                elif isinstance(v, crowd_handlers[k]):
                    self.__configs[k] = v
                else:
                    raise TypeError(f'Wrong type for config {k} value: {v}')
            else:
                logger.debug(f'Ignoring {k} from config')

    def __getattr__(self, attr: str) -> Any:
        return self.__configs.get(attr)

    @staticmethod
    def crowd_config_section(name: str) -> Callable:
        def decorator(klass: Type) -> Type:
            crowd_handlers[name] = klass
            return klass

        return decorator

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'CrowdConfig':
        try:
            return cls(**data)
        except DaciteError as exp:
            raise TypeError(f'Expecting {data} to be a dict compatible to {cls}') from exp

    @classmethod
    def from_path(cls, config_path: Union[Path, str] = DEFAULT_CONFIG) -> 'CrowdConfig':
        config_path = Path(config_path).expanduser()

        if not config_path.is_file():
            raise ValueError(f'Config path is not a file: {config_path}')

        with config_path.open('r') as f:
            config_data = envsubst(f.read())
            file_data = yaml.safe_load(config_data)

        return cls.from_dict(file_data)

    def to_dict(self) -> dict:
        return {k: dataclass_to_dict(v) for k, v in self.__configs.items()}
