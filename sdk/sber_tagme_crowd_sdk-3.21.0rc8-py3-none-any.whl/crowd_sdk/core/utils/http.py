import asyncio
import logging
import ssl
import time
from dataclasses import dataclass
from functools import wraps
from typing import Any, Awaitable, Callable, Iterable, Optional, TypeVar
from urllib import error

import aiohttp
import aiohttp.client_exceptions
import nest_asyncio
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry  # pylint: disable=E0401
from typing_extensions import ParamSpec

from crowd_sdk.core.utils.common import get_event_loop

logger = logging.getLogger(__name__)
nest_asyncio.apply()

RETRY_HTTP_CODES = [429, 502, 503, 504, 495, 496, 526]
RETRY_USER_EXCEPTIONS_LIST: list = []
DEFAULT_BACKOFF = 2
DEFAULT_RETRIES = 3
DEFAULT_POOL_SIZE = 10
DEFAULT_RATE_LIMIT = 20
HEAD_TIMEOUT = 10

DEFAULT_SYNC_EXCEPTIONS = (
    requests.ConnectionError,
    requests.ReadTimeout,
)
DEFAULT_ASYNC_EXCEPTIONS = (
    aiohttp.client_exceptions.ClientConnectionError,
    aiohttp.client_exceptions.ServerDisconnectedError,
)

RETRY_METHODS_PARM = "allowed_methods" if hasattr(Retry.DEFAULT, "allowed_methods") else "method_whitelist"
Args = ParamSpec("Args")
Output = TypeVar("Output")


@dataclass
class ExponentialBackoffPolicy:
    backoff_factor: float = 1

    def get_timeout(self, retry_attempt: int) -> float:
        return self.backoff_factor * (2 ** (retry_attempt - 1))


def retry_request_sync(
    statuses: Iterable[int] = (),
    retry_policy: ExponentialBackoffPolicy = ExponentialBackoffPolicy(),
    attempts: int = DEFAULT_RETRIES + 1,
    user_exceptions: Iterable = (),
) -> Callable:
    def decorator(func: Callable) -> Callable:
        retry_exceptions = DEFAULT_SYNC_EXCEPTIONS + tuple(user_exceptions)

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            attempt = 0
            while True:
                try:
                    return func(*args, **kwargs)

                except ssl.SSLError:
                    attempt += 1
                    if attempt >= attempts:
                        raise
                    time.sleep(retry_policy.get_timeout(attempt))

                except retry_exceptions:
                    time.sleep(retry_policy.get_timeout(attempt))
                    attempt += 1
                    if attempt >= attempts:
                        raise

                except requests.RequestException as exc:
                    if exc.response and exc.response.status_code in statuses:
                        time.sleep(retry_policy.get_timeout(attempt))
                        attempt += 1
                        if attempt >= attempts:
                            raise
                    else:
                        raise exc

        return wrapper

    return decorator


def retry_request_async(
    statuses: Iterable[int] = (),
    retry_policy: ExponentialBackoffPolicy = ExponentialBackoffPolicy(),
    attempts: int = DEFAULT_RETRIES + 1,
    user_exceptions: Iterable = (),
) -> Callable:
    def decorator(func: Callable) -> Callable:
        retry_exceptions = DEFAULT_ASYNC_EXCEPTIONS + tuple(user_exceptions)

        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            attempt = 0
            while True:
                try:
                    return await func(*args, **kwargs)

                except aiohttp.client_exceptions.ClientResponseError as exc:
                    if exc.status == 403 and 'application/json' in exc.headers.get('Content-Type'):
                        raise
                    if exc.status in statuses:
                        attempt += 1
                        if attempt >= attempts:
                            raise
                        await asyncio.sleep(retry_policy.get_timeout(attempt))
                    else:
                        raise exc

                except retry_exceptions:
                    attempt += 1
                    if attempt >= attempts:
                        raise
                    await asyncio.sleep(retry_policy.get_timeout(attempt))

            raise RuntimeError('This code must be unreachable')

        return wrapper

    return decorator


def retry_request_sync_supress(
    retry_policy: ExponentialBackoffPolicy = ExponentialBackoffPolicy(),
    attempts: int = DEFAULT_RETRIES + 1,
    user_exceptions: Iterable = (),
    statuses: Iterable[int] = (),
) -> Callable[[Callable[Args, Output]], Callable[Args, Output]]:
    def decorator(function: Callable[Args, Output]) -> Callable[Args, Output]:
        retry_exceptions = DEFAULT_SYNC_EXCEPTIONS + tuple(user_exceptions)

        @wraps(function)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            attempt = 0
            while True:
                try:
                    return function(*args, **kwargs)

                except ssl.SSLError:
                    attempt += 1
                    if attempt >= attempts:
                        raise
                    time.sleep(retry_policy.get_timeout(attempt))

                except retry_exceptions:
                    time.sleep(retry_policy.get_timeout(attempt))
                    attempt += 1
                    if attempt >= attempts:
                        raise

                except requests.RequestException as exc:
                    if exc.response and exc.response.status_code in statuses:
                        time.sleep(retry_policy.get_timeout(attempt))
                        attempt += 1
                        if attempt >= attempts:
                            raise
                    else:
                        raise exc

        return wrapper

    return decorator


def retry_request_async_supress(
    retry_policy: ExponentialBackoffPolicy = ExponentialBackoffPolicy(),
    attempts: int = DEFAULT_RETRIES + 1,
    user_exceptions: Iterable = (),
    statuses: Iterable[int] = (),
) -> Callable[[Callable[Args, Awaitable[Output]]], Callable[Args, Awaitable[Output]]]:
    def decorator(function: Callable[Args, Awaitable[Output]]) -> Callable[Args, Awaitable[Output]]:
        retry_exceptions = DEFAULT_ASYNC_EXCEPTIONS + tuple(user_exceptions)

        @wraps(function)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            attempt = 0
            while True:
                try:
                    return await function(*args, **kwargs)

                except aiohttp.client_exceptions.ClientResponseError as exc:
                    if exc.status == 403 and 'application/json' in exc.headers.get('Content-Type'):
                        raise
                    if exc.status in statuses:
                        attempt += 1
                        if attempt >= attempts:
                            raise
                        await asyncio.sleep(retry_policy.get_timeout(attempt))
                    else:
                        raise exc

                except retry_exceptions:
                    attempt += 1
                    if attempt >= attempts:
                        raise
                    await asyncio.sleep(retry_policy.get_timeout(attempt))

        return wrapper

    return decorator


retry_request = retry_request_async  # обратная совместимость


class BaseSyncHttpWrapper:
    def __init__(self, total_retries: int = DEFAULT_RETRIES, backoff_factor: int = DEFAULT_BACKOFF) -> None:
        """
        :param total_retries: number of retries
        :param backoff_factor: upscale factor for next try timeout
        """
        kwargs = {RETRY_METHODS_PARM: ["HEAD", "GET", "POST", "OPTIONS"]}
        retry_strategy = Retry(
            total=total_retries,
            backoff_factor=backoff_factor,
            status_forcelist=RETRY_HTTP_CODES,
            **kwargs,
        )
        adapter = HTTPAdapter(
            max_retries=retry_strategy, pool_connections=DEFAULT_POOL_SIZE, pool_maxsize=DEFAULT_POOL_SIZE
        )

        self.http = requests.Session()
        self.http.mount("https://", adapter)
        self.http.mount("http://", adapter)

    def get(self, *args: Any, **kwargs: Any) -> requests.Response:
        return self.http.get(*args, **kwargs)

    def post(self, *args: Any, **kwargs: Any) -> requests.Response:
        return self.http.post(*args, **kwargs)

    def delete(self, *args: Any, **kwargs: Any) -> requests.Response:
        return self.http.delete(*args, **kwargs)

    def request(self, *args: Any, **kwargs: Any) -> requests.Response:
        return self.http.request(*args, **kwargs)

    def head(self, *args: Any, **kwargs: Any) -> requests.Response:
        return self.http.head(*args, **kwargs)


class SyncHttpWrapper(BaseSyncHttpWrapper):
    @retry_request_sync()
    def get(self, *args: Any, **kwargs: Any) -> requests.Response:
        return super().get(*args, **kwargs)

    @retry_request_sync()
    def post(self, *args: Any, **kwargs: Any) -> requests.Response:
        return super().post(*args, **kwargs)

    @retry_request_sync()
    def delete(self, *args: Any, **kwargs: Any) -> requests.Response:
        return super().delete(*args, **kwargs)

    @retry_request_sync()
    def request(self, *args: Any, **kwargs: Any) -> requests.Response:
        return super().request(*args, **kwargs)

    @retry_request_sync()
    def head(self, *args: Any, **kwargs: Any) -> requests.Response:
        return self.http.head(*args, **kwargs)


class HttpWrapper:
    def __init__(
        self,
        connector: Optional[aiohttp.BaseConnector] = None,
        limit_per_host: int = DEFAULT_POOL_SIZE,
        request_timeout: Optional[float] = None,
    ) -> None:
        self.limit_per_host = limit_per_host
        self.connector = connector
        self.__session: Optional[aiohttp.ClientSession] = None
        self.__request_timeout = aiohttp.ClientTimeout(total=request_timeout)

    async def get_session(self) -> aiohttp.ClientSession:
        if self.connector is None:
            self.connector = aiohttp.TCPConnector(limit_per_host=self.limit_per_host)
        if self.__session is None:
            self.__session = aiohttp.ClientSession(connector=self.connector, timeout=self.__request_timeout)
        return self.__session

    def reinit(self) -> None:
        get_event_loop().run_until_complete(self.close())
        get_event_loop().run_until_complete(self.get_session())

    async def get(self, url: str, *args: Any, **kwargs: Any) -> aiohttp.ClientResponse:
        session = await self.get_session()
        return await session.get(url=url, *args, **kwargs)

    async def post(self, url: str, data: Any, **kwargs: Any) -> aiohttp.ClientResponse:
        session = await self.get_session()
        return await session.post(url=url, data=data, **kwargs)

    async def delete(self, url: str, **kwargs: Any) -> aiohttp.ClientResponse:
        session = await self.get_session()
        return await session.delete(url=url, **kwargs)

    async def request(self, method: str, url: str, **kwargs: Any) -> aiohttp.ClientResponse:
        session = await self.get_session()
        return await session.request(method=method, url=url, **kwargs)

    async def close(self) -> None:
        if self.__session and not self.__session.closed:
            return await self.__session.close()

    def __del__(self) -> None:
        loop = get_event_loop()
        # if it's running inside the event loop, it will throw an error
        if not loop.is_running():
            loop.run_until_complete(self.close())


class RateLimiter:
    def __init__(self, rps: int = DEFAULT_RATE_LIMIT):
        self.rate_limit = rps
        self.current_period = int(time.monotonic())
        self.rate_current = 0

    async def __aenter__(self) -> None:
        while self.__need_waiting():
            await self.__sleep_remaining()

        self.rate_current += 1

    async def __aexit__(self, *_: Any) -> None:
        pass

    def __need_waiting(self) -> bool:
        if self.current_period < int(time.monotonic()):
            self.current_period = int(time.monotonic())
            self.rate_current = 0

        return self.rate_current >= self.rate_limit

    async def __sleep_remaining(self) -> None:
        remaining = self.current_period + 1 - time.monotonic()
        if remaining > 0:
            await asyncio.sleep(remaining)


http = HttpWrapper()
sync_http = SyncHttpWrapper()


def get_file_size(url: str) -> int:
    """
    Get headers from the url, returns content-Length as a size result
    Args:
        url (str): target url

    Returns:
        (int) size
    """
    response = requests.head(url, verify=False, timeout=HEAD_TIMEOUT)
    response.raise_for_status()

    assert 'Content-Length' in response.headers
    return int(response.headers['Content-Length'])


def check_url(url: str) -> bool:
    """
    Get headers from the url, returns if is has headers and returns 2xx code
    Args:
        url (str): target url

    Returns:
        (bool) result
    """
    try:
        response = requests.head(url, verify=False, timeout=HEAD_TIMEOUT)
        return 200 <= response.status_code < 300
    except (error.HTTPError, requests.RequestException):
        pass
    return False
