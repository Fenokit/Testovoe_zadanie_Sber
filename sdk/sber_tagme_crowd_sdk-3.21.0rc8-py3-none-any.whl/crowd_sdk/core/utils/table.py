import csv
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Union


def tsv_load(path: Union[Path, str]) -> Iterable:
    header = None
    with open(path) as f:
        for line in f:
            line_parts = line.rstrip('\r\n').split('\t')
            if header is None:
                header = line_parts
            else:
                row_dict = {k: v for k, v in zip(header, line_parts) if not (not v and k.startswith('GOLDEN:'))}
                yield row_dict


def set_subkey(result: Dict[str, Any], name: str, value: dict) -> None:
    for sub_key, sub_value in value.items():
        if isinstance(sub_value, (dict, list)):
            result[f'{name}:{sub_key}'] = json.dumps(sub_value, ensure_ascii=False, indent=2)
        else:
            result[f'{name}:{sub_key}'] = sub_value


def flatten_row(assignment: Dict[str, Any]) -> Dict[str, Any]:
    result: Dict[str, Any] = {}
    for key, value in assignment.items():
        if key == 'result' and isinstance(value, dict):
            set_subkey(result, 'OUTPUT', value)
        elif key == 'control' and isinstance(value, dict):
            set_subkey(result, 'GOLDEN', value)
        elif key == 'input_data' and isinstance(value, dict):
            set_subkey(result, 'INPUT', value)
        elif value is None:
            pass
        else:
            if isinstance(value, (dict, list)):
                result[f'{key}'] = json.dumps(value, ensure_ascii=False, indent=2)
            else:
                result[f'{key}'] = value
    return result


def results_as_df(results: List[Dict[str, Any]]) -> Any:
    table_data = []

    fields = set()
    for assignment in results:
        row = flatten_row(assignment)
        table_data.append(row)
        fields |= set(row.keys())

    header = sorted(list(fields))

    try:
        import pandas as pd  # pylint: disable=import-outside-toplevel
    except ImportError:
        print('Need pandas to write xlsx')
        print('pip install pandas')
        exit(-1)  # pylint: disable=consider-using-sys-exit

    df = pd.DataFrame(table_data, columns=header)
    dt_cols = df.select_dtypes(include=['datetime64[ns, UTC]']).columns
    for col in dt_cols:
        df[col] = df[col].dt.tz_localize(None)

    return df


def save_results(results: List[Dict[str, Any]], destination: str, ext: str) -> None:
    if ext == 'json':
        with open(destination, 'w') as f:
            json.dump(results, f, default=str)
    else:
        table_data = []

        fields = set()
        for assignment in results:
            row = flatten_row(assignment)
            table_data.append(row)
            fields |= set(row.keys())

        header = sorted(list(fields))

        if ext in ['csv', 'tsv']:
            with open(destination, 'w') as f:
                if ext == 'csv':
                    writer = csv.DictWriter(f, fieldnames=header, dialect='excel')
                else:
                    writer = csv.DictWriter(f, fieldnames=header, delimiter='\t')

                writer.writeheader()
                writer.writerows(table_data)
        elif ext == 'xlsx':
            try:
                import pandas as pd  # pylint: disable=import-outside-toplevel
            except ImportError:
                print('Need pandas to write xlsx')
                print('pip install pandas')
                exit(-1)  # pylint: disable=consider-using-sys-exit

            df = pd.DataFrame(table_data, columns=header)
            dt_cols = df.select_dtypes(include=['datetime64[ns, UTC]']).columns
            for col in dt_cols:
                df[col] = df[col].dt.tz_localize(None)
            df.to_excel(destination, index=False)
        else:
            raise NotImplementedError(f'Not implemented saving to the {ext} format')
