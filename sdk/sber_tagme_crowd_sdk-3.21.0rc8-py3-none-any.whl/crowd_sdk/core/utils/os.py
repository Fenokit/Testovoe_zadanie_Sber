import json
import logging
import os
import random
import shutil
import subprocess as sp
import tempfile
import traceback
from pathlib import Path
from typing import Any, Callable, Iterable, List, Optional, Union

logger = logging.getLogger(__name__)

# pylint: disable = C0209


def write_json(content: Any, output_file: Union[str, Path], **kwargs: Any) -> None:
    """
    Dump json to file with default parameters
    """
    default_arguments = {'indent': 4, 'separators': (',', ': '), 'sort_keys': True}
    for k, v in default_arguments.items():
        if k not in kwargs:
            kwargs[k] = v

    with open(output_file, 'w', encoding='utf-8') as output:
        json.dump(content, output, ensure_ascii=False, **kwargs)


def read_json(input_path: Union[str, Path]) -> dict:
    """
    Reads json from utf-8 file
    """
    with open(input_path, 'r', encoding='utf-8') as fin:
        return json.load(fin)


def mkdir_force(folder: Union[str, Path]) -> None:
    """
    forced mkdir
    :param folder: path to folder
    """
    if os.path.exists(folder):
        if os.path.isdir(folder):
            logging.info(f'Removing folder \"{folder}\"')
            shutil.rmtree(folder)
        else:
            logging.info(f'Removing file \"{folder}\"')
            os.remove(folder)
    os.mkdir(folder)


def walk(path: str, recursive: bool = True, filter_ext: Optional[Iterable] = None) -> Iterable:
    if recursive:
        for subdir, _, files in os.walk(path, followlinks=True):
            subdir_suffix = subdir[len(path) :].lstrip('/')
            for file in files:
                if filter_ext and not any(file.lower().endswith(ext) for ext in filter_ext):
                    continue
                rel_path = os.path.join(subdir_suffix, file)
                full_path = os.path.join(subdir, file)
                if os.path.isfile(full_path):
                    yield rel_path, full_path
    else:
        for file in os.listdir(path):
            if filter_ext and not any(file.lower().endswith(ext) for ext in filter_ext):
                continue
            full_path = os.path.join(path, file)
            if os.path.isfile(full_path):
                yield file, full_path


def bash(cmd: str) -> None:
    if logging.root.level == logging.DEBUG:
        sp.check_output(cmd.split(' '))
    else:
        sp.run(cmd.split(' '), stderr=sp.DEVNULL, stdout=sp.DEVNULL, check=True)


def bash_capture(cmd: str) -> str:
    if logging.root.level == logging.DEBUG:
        result = sp.check_output(cmd.split(' '))  # type: ignore
        return result.decode('utf-8')
    else:
        result = sp.run(cmd.split(' '), capture_output=True, check=True)  # type: ignore
        return result.stdout.decode('utf-8')  # type: ignore


def silent_popen(command: str, cwd: Optional[str] = None) -> None:
    logging.info('Executing \"' + ' '.join(command) + '\"')
    try:
        sp.run(command, cwd=cwd, stdout=sp.PIPE, stderr=sp.PIPE, check=True)
    except sp.CalledProcessError as error:
        raise RuntimeError(error.stderr) from error


class TmpFile:
    def __init__(self, path: Union[str, Path]):
        self.path_ = path

    def __enter__(self) -> Union[str, Path]:
        return self.path_

    def __exit__(self, _type: Any, _value: Any, _traceback: Any) -> None:
        if os.path.isfile(self.path_):
            bash(f'rm {self.path_}')


class RandomFile:
    def __init__(self, ext: str = '.txt', subdir: Optional[Union[str, Path]] = None):
        self.path_: str = self.generate(ext=ext, subdir=subdir)
        while os.path.exists(self.path_):
            self.path_ = self.generate(ext)
        os.makedirs(os.path.dirname(self.path_), exist_ok=True)

    def __str__(self) -> str:
        return self.path_

    def __repr__(self) -> str:
        return self.path_

    def __enter__(self) -> str:
        return self.path_

    def __exit__(self, _type: Any, _value: Any, _traceback: Any) -> None:
        if os.path.isfile(self.path_):
            bash(f'rm {self.path_}')

    @staticmethod
    def generate(ext: str = '.txt', subdir: Optional[Union[str, Path]] = None) -> str:
        if subdir:
            return os.path.join(tempfile.gettempdir(), subdir, 'csdk_' + str(random.randint(1, 10000))) + ext
        else:
            return os.path.join(tempfile.gettempdir(), 'csdk_' + str(random.randint(1, 10000))) + ext


def create_path(dataset_path: Union[str, Path], file: Union[str, Path], file_type: str) -> str:
    """
    Creates full path to file if it exists, throws error otherwise, file_type used for info purposes only

    Input:
     dataset_path: Path to dataset folder in which dataset files will be looked for
     file: filename (of reference or report)
     file_type: indicates if its reference/hypotheses/report for error message
    """
    path = os.path.join(dataset_path, file)
    if not os.path.exists(path):
        raise RuntimeError(f'There is no {file_type}: {path}')

    return path


def delete_dir_handler(function: Callable, path: Union[str, Path], excinfo: List[Any]) -> None:
    """
    Handler compatible with https://docs.python.org/3/library/shutil.html#shutil.rmtree
    Args:
        function: the function which raised the exception
        path: path, will be the path name passed to function
        excinfo: will be the exception information returned by sys.exc_info().
                 Exceptions raised by onerror will not be caught.

    Returns:
        None
    """
    try:
        for fileobj in function(path):
            os.remove(fileobj)
        os.removedirs(path)
    except FileNotFoundError:
        pass
    except (AttributeError, OSError, TypeError):
        traceback.print_exc(*excinfo)
        logger.warning(f"Sorry. Couldn't delete directory {path}.")
        raise


class TempDir:
    """container for temporary directory. Deletes directory when garbage
    collected/zero references"""

    def __init__(self) -> None:
        self.path = tempfile.mkdtemp()
        if not os.path.exists(self.path):
            os.makedirs(self.path, exist_ok=True)

    def __enter__(self) -> str:
        if not self.path:
            self.path = tempfile.mkdtemp()
        if not os.path.exists(self.path):
            os.makedirs(self.path, exist_ok=True)
        return self.path

    def __str__(self) -> str:
        return self.path

    def __repr__(self) -> str:
        return self.path

    def __del__(self) -> None:
        if os.path.exists(self.path):
            shutil.rmtree(self.path, onerror=delete_dir_handler)

    def __exit__(self, *args: Any, **kwargs: Any) -> None:
        self.__del__()

    def force_cleanup(self) -> None:
        if os.path.exists(self.path):
            shutil.rmtree(self.path, onerror=delete_dir_handler)
