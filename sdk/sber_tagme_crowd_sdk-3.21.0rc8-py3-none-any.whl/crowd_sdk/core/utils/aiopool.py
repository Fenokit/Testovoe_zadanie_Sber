from asyncio import Queue, gather
from typing import Any, AsyncGenerator, Awaitable, Callable, Iterable, List

from crowd_sdk.core.utils.common import get_event_loop


class EndSignal:
    pass


async def _run_worker(input_queue: Queue, output_queue: Queue, afunc: Callable[[Any], Awaitable[Any]]) -> None:
    while True:
        arg = await input_queue.get()
        if isinstance(arg, EndSignal):
            await output_queue.put(arg)
            return  # end
        result = await afunc(arg)
        await output_queue.put(result)


async def _queue_args_and_get_results(
    input_queue: Queue, output_queue: Queue, workers: int, args: Iterable[Any]
) -> AsyncGenerator:
    for arg in args:
        await input_queue.put(arg)
    for _ in range(workers):
        await input_queue.put(EndSignal())

    finishedWorkers = 0
    while True:
        result = await output_queue.get()
        if isinstance(result, EndSignal):
            finishedWorkers += 1
            if finishedWorkers == workers:
                break  # end
        else:
            yield result


class AIOPool:
    def __init__(self, workers: int = 1) -> None:
        if workers < 1:
            raise ValueError('Number of workers must be at least 1')
        self.workers = workers

    def __enter__(self) -> 'AIOPool':
        return self

    def __exit__(self, exc_type: Any, exc_value: Any, traceback: Any) -> None:
        return

    async def map_async(self, afunc: Callable[[Any], Awaitable[Any]], args: Iterable[Any]) -> AsyncGenerator:
        input_queue: Queue = Queue()
        output_queue: Queue = Queue()

        worker_tasks = [_run_worker(input_queue, output_queue, afunc) for _ in range(self.workers)]

        async for result in _queue_args_and_get_results(input_queue, output_queue, self.workers, args):
            yield result

        gather(*worker_tasks)

    async def map_sync(self, afunc: Callable[[Any], Awaitable[Any]], args: Iterable[Any]) -> List[Any]:
        result = []
        async for res in self.map_async(afunc, args):
            result.append(res)
        return result

    def map(self, afunc: Callable[[Any], Awaitable[Any]], args: List[Any]) -> List[Any]:
        return get_event_loop().run_until_complete(self.map_sync(afunc, args))
