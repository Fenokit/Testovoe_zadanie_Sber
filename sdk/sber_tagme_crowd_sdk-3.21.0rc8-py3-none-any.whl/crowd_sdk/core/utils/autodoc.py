from functools import wraps
from typing import Any, Callable


def pycharm_typing_fixer(decorator: Callable) -> Callable:
    return decorator


@pycharm_typing_fixer
def section(tag: str):  # type: ignore
    def decorator(func):  # type: ignore
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any):  # type: ignore
            return func(*args, **kwargs)

        wrapper.__autodoc_tag__ = tag
        return wrapper

    return decorator
