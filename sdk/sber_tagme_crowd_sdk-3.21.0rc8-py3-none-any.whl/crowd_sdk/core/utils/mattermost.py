from dataclasses import dataclass
from typing import Optional

from crowd_sdk.core.utils.http import HttpWrapper
from crowd_sdk.tagme.config import DEFAULT_CONFIG, CrowdConfig

SECTION_NAME = "mattermost"


@CrowdConfig.crowd_config_section(SECTION_NAME)
@dataclass
class MattermostConfig:
    token: str
    channel_id: str
    bot_url: str


class MattermostClient:
    def __init__(self, http: Optional[HttpWrapper] = None) -> None:
        self.http = http or HttpWrapper()
        crowd_config = CrowdConfig.from_path(DEFAULT_CONFIG)
        assert crowd_config.mattermost, "Fill mattermost section in crowd config"
        self.config: MattermostConfig = crowd_config.mattermost

    async def send_message(self, text: str) -> None:
        bot_api_headers = {'Authorization': 'Bearer ' + self.config.token}
        default_http_params = {'headers': bot_api_headers, 'raise_for_status': True}
        data = {'channel_id': self.config.channel_id, 'message': text}
        url = f"{self.config.bot_url}/posts"
        await self.http.request('POST', url, json=data, ssl=False, **default_http_params)
