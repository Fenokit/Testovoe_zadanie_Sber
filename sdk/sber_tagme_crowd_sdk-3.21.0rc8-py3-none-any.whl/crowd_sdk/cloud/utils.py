import logging
import os
import tempfile
from functools import partial
from multiprocessing import Pool
from pathlib import Path
from typing import Dict, Iterable, List, Union

from tqdm.autonotebook import tqdm

from crowd_sdk.cloud import Cloud
from crowd_sdk.core.utils.common import md5_mp
from crowd_sdk.core.utils.os import TempDir

logger = logging.getLogger(__name__)


def upload_folder_wavs_to_s3(
    fpath: Union[str, Path], cloud: Cloud, bucket: str, dst: str, tqdm_off: bool = False
) -> Dict[str, str]:
    """Upload wavs from directory to cloud"""
    input_urls = list({str(f) for f in Path(fpath).rglob('*.wav')})

    upl_results = cloud.upload_publish_validate(src=input_urls, bucket=bucket, dst=dst, tqdm_off=tqdm_off)

    filename2url = {filename: url for filename, url, _ in upl_results}

    logger.info(f'There are {len(filename2url)} wavs was uploaded to s3 from folder.')
    return filename2url


def get_wav_hashes_by_urls_list(
    cloud: Cloud, input_urls: Iterable[str], n_pools: int, tqdm_off: bool = False
) -> Dict[str, str]:
    """Compute md5 hash of audio from list of s3 urls. Return mapping audio name to it's md5 hash"""

    with tempfile.TemporaryDirectory() as tmp:
        cloud.download_from_url_list(list(set(input_urls)), dst=tmp, tqdm_off=tqdm_off)
        tmp_dir = Path(tmp)
        name_hash_dict = md5_mp(fnames=list(tmp_dir.rglob('*')), n_pools=n_pools)
    return name_hash_dict


def one_cloud_to_another_from_urls_list(
    s3_urls: List[str],
    src_cloud_config: dict,
    dst_cloud_config: dict,
    dryrun: bool = False,
    skip_existing: bool = False,
    tqdm_off: bool = False,
) -> Dict[str, str]:
    debug_mode = (logging.root.level == logging.DEBUG) or tqdm_off

    cloud_src = Cloud(src_cloud_config)

    s3_urls = list(set(s3_urls))
    upload_result = []
    for s3_urls_chunk in Cloud.chunks(s3_urls, 10000):
        with TempDir() as tmp_dir:
            cloud_src.download_from_url_list(s3_urls_chunk, dst=tmp_dir, tqdm_off=True)
            sources = []
            for url in s3_urls_chunk:
                src_file = os.path.join(tmp_dir, url.split('/')[-1])
                prefix = cloud_src.endpoint + '/'
                dst_file = url[url.startswith(prefix) and len(prefix) :]
                sources.append([src_file, dst_file])

            upl_to_dst_cloud_part_func = partial(
                Cloud.upload_process,
                bucket=None,
                dryrun=dryrun,
                skip_existing=skip_existing,
            )
            with Pool(cloud_src.threads_num, initializer=Cloud.initialize_mp_s3, initargs=(dst_cloud_config,)) as pool:
                upload_result_chunk = list(
                    tqdm(pool.imap(upl_to_dst_cloud_part_func, sources), total=len(sources), disable=debug_mode)
                )
            upload_result += upload_result_chunk

    name_to_url_dict = {url.split('/')[-1]: url for url in s3_urls}
    src_url_to_dst_url_dict = {}
    for upload_bucket, upload_path in upload_result:
        fname = upload_path.split('/')[-1]
        src_url = name_to_url_dict[fname]
        dst_url = os.path.join(dst_cloud_config['endpoint'], upload_bucket, upload_path)
        src_url_to_dst_url_dict[src_url] = dst_url
    return src_url_to_dst_url_dict
