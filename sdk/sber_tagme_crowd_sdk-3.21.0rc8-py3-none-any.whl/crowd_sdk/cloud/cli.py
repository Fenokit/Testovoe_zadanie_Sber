#!/usr/bin/env python3
import logging
import logging.config
from argparse import ArgumentParser
from pathlib import Path
from typing import Any, Union

from crowd_sdk import DEFAULT_CONFIG
from crowd_sdk.cloud import Clouds

logger = logging.getLogger(__name__)


def parse_args(default_config: str) -> Any:
    parser = ArgumentParser(allow_abbrev=False, description='CLI for s3 endpoints')
    parser.add_argument('--config', default=default_config, help='Crowd yaml configuration with cloud section')
    parser.add_argument('--cloud', default='main', help='S3 target from config')
    parser.add_argument('--bucket', help='Specify bucket separately')
    parser.add_argument('--backup', help='Use backup cloud instance for backup')
    parser.add_argument('--verbose', '-v', action='store_true', help='Show debug info')
    parser.add_argument('--dryrun', '-d', action='store_true', help='Dry run for debugging')

    subparsers = parser.add_subparsers(title='commands', dest='command')

    parser_upload = subparsers.add_parser('upload', help='Upload path to the specified s3')
    parser_upload.add_argument('src', help='source path to the directory with files')
    parser_upload.add_argument('dst', help='destination path in the cloud')
    parser_upload.add_argument('--max_age', help='Cache max age in seconds')

    parser_download = subparsers.add_parser('download', help='Download path from the specified s3')
    parser_download.add_argument('src', help='path to the directory with files')
    parser_download.add_argument('dst', help='destination path in the cloud')

    parser_publish = subparsers.add_parser('publish', help='Publish path and print urls to stdout')
    parser_publish.add_argument('path', help='path to directory with files')

    parser_delete = subparsers.add_parser('delete', help='Deletes file or directory by specified s3 path')
    parser_delete.add_argument('--force', '-f', action='store_true', default=False, help='do not confirm deletion')
    parser_delete.add_argument('src', help='path to file/directory to delete')

    subparsers.add_parser('ls_datasets', help='Prints list of existing datasets')

    parser_ls_folder = subparsers.add_parser('ls_folder', help='Prints folder content')
    parser_ls_folder.add_argument('folder', help='path to folder')

    parser_get_tree = subparsers.add_parser('get_tree', help='Prints folder content')
    parser_get_tree.add_argument('prefix', help='path to the file/directory to delete')

    parser_upload = subparsers.add_parser(
        'upload_publish_validate', help='Upload, publish and validate path to the specified s3'
    )
    parser_upload.add_argument('src', help='path to the directory with files')
    parser_upload.add_argument('dst', help='destination path in the cloud')
    parser_upload.add_argument('--max_age', help='Cache max age in seconds')

    parser_cors = subparsers.add_parser(
        'add_public_cors', help='Add cors to the bucket to make it available for sharing files with other web pages'
    )
    parser_cors.add_argument('urls', help='path to directory with files', nargs='+')

    return parser.parse_args()


def main(default_config: Union[str, Path] = DEFAULT_CONFIG) -> None:
    args = parse_args(default_config=str(default_config))
    logging.basicConfig(
        format='[LINE:%(lineno)d] %(levelname)-8s [%(asctime)s] [%(name)s]:  %(message)s',
        level=logging.DEBUG if args.verbose else logging.INFO,
    )
    logging.getLogger('botocore').setLevel(logging.ERROR)
    logging.getLogger('s3transfer').setLevel(logging.ERROR)
    logging.getLogger('urllib3').setLevel(logging.ERROR)

    clouds = Clouds(config=default_config)

    params = {k: v for k, v in vars(args).items() if k not in ['command', 's3', 'verbose']}
    if args.bucket:
        params['bucket'] = args.bucket
    else:
        if args.command == 'publish':
            assert '/' in args.path, 'Need / to split the dst on a bucket and a key'
            params['bucket'], params['path'] = args.path.split('/', 1)
        else:
            assert '/' in args.dst, 'Need / to split the dst on a bucket and a key'
            params['bucket'], params['dst'] = args.dst.split('/', 1)

    if args.backup:
        params['backup_config'] = clouds.get_config(args.backup)

    res = clouds.get(args.cloud).run_command(args.command, **params)

    # For some commands we always want to see debug logs
    if args.command in ['ls_folder', 'ls_datasets']:
        logger.setLevel(logging.DEBUG)
    elif args.command in ['delete']:
        logger.setLevel(logging.INFO)

    if isinstance(res, list):
        for item in res:
            logger.debug(item)
    else:
        logger.debug(res)


if __name__ == '__main__':
    main()
