import hashlib
import logging
import multiprocessing as mp
import os
import tarfile
import zipfile
import zlib
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from functools import partial
from multiprocessing import Pool
from pathlib import Path
from typing import Any, List, Optional, Tuple, Union
from zipfile import ZipFile

import click
from Crypto import Random
from Crypto.Cipher import AES
from tqdm import tqdm

logger = logging.getLogger(__name__)

N_POOLS = mp.cpu_count() - 1


@dataclass
class UntarEntryDataclass:
    from_path: Path
    to_path: Optional[Path] = None
    conflict_err: bool = True
    del_tar: bool = False


def md5(s: Union[str, bytes]) -> bytes:
    if isinstance(s, bytes):
        return hashlib.md5(s).digest()
    elif isinstance(s, str):
        return hashlib.md5(s.encode()).digest()
    else:
        raise TypeError(f'md5 doesn\'t not support {type(s)} yet')


def make_tarfile(input_dir: Path, output_dir: Optional[Path] = None, compresslevel: int = 9) -> Path:
    """compresslevel=9 is default"""
    if not output_dir:
        output_filename = input_dir.parent / f'{input_dir.name}.tar'
    else:
        output_filename = output_dir / f'{input_dir.name}.tar'
    with tarfile.open(output_filename, 'w:gz', compresslevel=compresslevel) as tar:
        tar.add(input_dir, arcname=Path(input_dir).name)
    return output_filename


def untar_file(item: UntarEntryDataclass) -> Optional[Path]:  # pylint: disable=R0912
    if item.from_path is None:
        raise RuntimeError('Input filename is incorrect!')
    if item.to_path is None:
        item.to_path = item.from_path.parent
    item.to_path.mkdir(parents=True, exist_ok=True)
    filename = None
    new_path = None
    try:
        with tarfile.open(item.from_path, 'r:*') as tar:
            tar_content = list(tar)
            if len(tar_content) == 1:
                filename = tar_content[0].name
            elif len(tar_content) == 0:
                if item.conflict_err:
                    raise RuntimeError(f'tar file at {item.from_path} has no files inside.')
                logger.error('tar file at %s has no files inside.', item.from_path)
            tar.extractall(path=item.to_path)
        if filename is not None:
            new_path = item.to_path / filename
    except (tarfile.ReadError, EOFError) as e:
        if item.conflict_err:
            raise Exception('tarfile.ReadError: empty header') from e
        logger.error('Empty header %s', item.from_path)
    except zlib.error as e:
        if item.conflict_err:
            raise
        logger.error('Raised zlib.error with args %s from file %s', e.args, item.from_path)
    finally:
        if item.del_tar:
            item.from_path.unlink()
    return new_path


def untar_file_mp(
    items: List[UntarEntryDataclass], n_pools: int = N_POOLS, tqdm_off: bool = False
) -> List[Optional[Path]]:
    with ProcessPoolExecutor(max_workers=n_pools) as pool:
        new_pathes_list = list(tqdm(pool.map(untar_file, items), total=len(items), disable=tqdm_off))
    return new_pathes_list


def split_to_chunks(input_path: Path, chunk_size: int) -> List[Path]:
    """chunk_size: size each output file in MB"""
    input_path = Path(input_path)
    chunk_size = chunk_size * 1024 * 1024
    chunk_files = []
    file_number = 1
    with open(input_path, 'rb') as f:
        chunk = f.read(chunk_size)
        while chunk:
            with open(f'{str(input_path)}.{file_number}', 'wb') as chunk_file:
                chunk_file.write(chunk)
                chunk_files.append(Path(chunk_file.name))
            file_number += 1
            chunk = f.read(chunk_size)
    input_path.unlink()
    return chunk_files


def join_chunks(file_chunks: List[Path], output_file: Path, del_chunks: bool = True) -> Path:
    """chunk_size: size each output file in MB"""
    with open(output_file, 'wb') as dst:
        for file in file_chunks:
            with open(file, 'rb') as f:
                chunk = f.read()
            dst.write(chunk)

    if del_chunks:
        for file in file_chunks:
            file.unlink()
    return output_file


def pad(value: bytes) -> Tuple[bytes, int]:
    pad_size = (AES.block_size - len(value) % AES.block_size) % AES.block_size
    return value + b"\0" * pad_size, pad_size


def encode_pad_size(pad_size: int, bytes_: int = 1) -> bytes:
    return pad_size.to_bytes(bytes_, 'big')


def decode_pad_size(message: bytes, bytes_: int = 1) -> Tuple[int, bytes]:
    pad_info = message[:bytes_]
    other_message = message[bytes_:]
    return int.from_bytes(pad_info, 'big'), other_message


def encrypt(message: bytes, key: bytes) -> bytes:
    message, pad_size = pad(message)
    incom_val = Random.new().read(AES.block_size)
    cipher = AES.new(key, AES.MODE_CBC, incom_val)
    pad_val = encode_pad_size(pad_size)
    return pad_val + incom_val + cipher.encrypt(message)


def decrypt(ciphertext: bytes, key: bytes) -> bytes:
    if os.environ.get('LORA_LEGACY_ENCRYPTION', '0') == '1' and len(ciphertext) % AES.block_size == 0:
        # legacy encryption supported only for wavs
        incom_val = ciphertext[: AES.block_size]
        cipher = AES.new(key, AES.MODE_CBC, incom_val)
        plaintext = cipher.decrypt(ciphertext[AES.block_size :])
        inferred_size = int.from_bytes(plaintext[4:8], 'little') + 8
        if 0 <= len(plaintext) - inferred_size < AES.block_size:
            plaintext = plaintext[:inferred_size]
        else:
            logger.critical(
                'Was not able to successfully infer wav file size for wav encrypted using bugged compression.'
                'Will leave possible trailing zeros in the files.'
            )
        return plaintext
    else:
        pad_val, ciphertext = decode_pad_size(ciphertext)
        incom_val = ciphertext[: AES.block_size]
        cipher = AES.new(key, AES.MODE_CBC, incom_val)
        plaintext = cipher.decrypt(ciphertext[AES.block_size :])
        if pad_val > 0:
            return plaintext[:-pad_val]
        else:
            return plaintext


def encrypt_file(input_fname: Union[str, Path], key: str, output_fname: Optional[Union[str, Path]] = None) -> Any:
    key_hash = md5(key)
    input_fname = Path(input_fname)
    if not output_fname:
        output_fname = input_fname.with_suffix(f'{input_fname.suffix}.enc')
    with open(input_fname, 'rb') as open_file:
        data = open_file.read()
    enc = encrypt(data, key_hash)
    with open(output_fname, 'wb') as open_file:
        open_file.write(enc)
    return output_fname


def decrypt_file(input_fname: Optional[Path], key: str, output_fname: Optional[Path] = None) -> Path:
    assert input_fname, 'No file to decrypt!'
    key_hash = md5(key)
    input_fname = Path(input_fname)
    if not output_fname:
        output_fname = input_fname.with_suffix('')
    with open(input_fname, 'rb') as open_file:
        data = open_file.read()
    dec = decrypt(data, key_hash)
    with open(output_fname, 'wb') as open_file:
        open_file.write(dec)
    return output_fname


def zip_file(filename: Union[str, Path]) -> str:
    with ZipFile(f'{filename}.zip', 'w', compression=zipfile.ZIP_BZIP2) as zipf:
        zipf.write(filename, arcname=Path(filename).name)
    return f'{filename}.zip'


def zip_dir(dirpath: str, hidden: bool = False) -> str:
    abs_dirpath = os.path.abspath(dirpath)
    with ZipFile(f'{dirpath}.zip', 'w', compression=zipfile.ZIP_BZIP2) as zipf:
        for root, _, files in os.walk(dirpath):
            abs_root = os.path.abspath(root)
            rel_root = abs_root[len(abs_dirpath) + 1 :]
            zipf.write(abs_root, arcname=Path(rel_root))

            for file in files:
                if not hidden and file[0] == '.':
                    continue
                abs_filename = os.path.abspath(os.path.join(root, file))
                filename = abs_filename[len(abs_dirpath) + 1 :]
                zipf.write(abs_filename, arcname=Path(filename))
    return f'{abs_dirpath}.zip'


def unzip_file(filename: Path, dst: Optional[Path] = None, conflict_err: Optional[bool] = True) -> Path:
    if not dst:
        dst = filename.parent
    try:
        with zipfile.ZipFile(filename, 'r') as zip_ref:
            zip_ref.extractall(dst)
        return dst
    except zipfile.BadZipfile as e:
        if conflict_err:
            raise RuntimeError(f'ZIP file {filename} opening error') from e
    except zipfile.LargeZipFile as e:
        if conflict_err:
            raise RuntimeError(f'ZIP file {filename} opening error') from e
    raise RuntimeError('Unreachable')


def encrypt_and_zip(filename: Union[str, Path], key: str, del_file: bool = True) -> None:
    assert Path(filename).is_file(), f'Is no a file {filename}'
    encrypt_file(input_fname=filename, key=key, output_fname=filename)
    zip_file(filename)
    if del_file:
        Path(filename).unlink()


def decrypt_and_unzip(filename: Union[str, Path], key: str, del_file: bool = True) -> Path:
    filename = Path(filename)
    assert filename.is_file(), f'Is no a file {filename}'
    unziped_fname = unzip_file(filename, conflict_err=True)
    unziped_fname = unziped_fname / Path(filename).name[:-4]
    if del_file:
        filename.unlink()
    decrypt_file(input_fname=unziped_fname, key=key, output_fname=unziped_fname)
    return unziped_fname


def full_pack(input_dir: Path, output_dir: Path, key: str, chunk_size: int, compresslevel: int, n_pools: int) -> None:
    input_tarfile = make_tarfile(input_dir=input_dir, output_dir=output_dir, compresslevel=0)
    chunk_files = split_to_chunks(input_path=input_tarfile, chunk_size=chunk_size)

    make_tarfile_proc = partial(make_tarfile, output_dir=output_dir, compresslevel=compresslevel)
    with Pool(n_pools) as pool:
        tar_chunk_files = list(tqdm(pool.imap(make_tarfile_proc, chunk_files), total=len(chunk_files), disable=False))

    for chunk_file in chunk_files:
        chunk_file.unlink()

    logger.info('Encrypt and zip tar chunks:')
    encrypt_and_zip_func = partial(encrypt_and_zip, key=key, del_file=True)
    with Pool(n_pools) as pool:
        list(tqdm(pool.imap(encrypt_and_zip_func, tar_chunk_files), total=len(tar_chunk_files), disable=False))


def full_unpack(input_dir: Path, output_dir: Path, key: str, n_pools: int) -> None:
    input_dir = Path(input_dir)
    input_files = list(input_dir.glob('*.tar.zip'))
    logger.info('Decrypt and unzip files:')
    decrypt_and_unzip_func = partial(decrypt_and_unzip, key=key, del_file=True)
    with Pool(n_pools) as pool:
        list(tqdm(pool.imap(decrypt_and_unzip_func, input_files), total=len(input_files), disable=False))

    unziped_fnames = [f for f in input_dir.glob('*.tar') if f.name.split('.')[-2].isdigit()]
    unziped_data = [
        UntarEntryDataclass(from_path=fname, to_path=input_dir, conflict_err=True, del_tar=True)
        for fname in unziped_fnames
    ]
    with Pool(n_pools) as pool:
        list(tqdm(pool.imap(untar_file, unziped_data), total=len(unziped_data), disable=False))

    for f in input_dir.glob('*.tar'):
        if f.name.split('.')[-2].isdigit():
            f.unlink()

    output_tarfile_chunks = sorted(
        [f for f in input_dir.glob('*') if f.name.split('.')[-1].isdigit()], key=lambda x: int(x.name.split('.')[-1])
    )
    assert output_tarfile_chunks, f'There is no files to unpack in {input_dir}'
    output_file = output_tarfile_chunks[0].with_suffix('')

    output_tarfile = join_chunks(file_chunks=output_tarfile_chunks, output_file=output_file, del_chunks=True)

    output_file_untar = untar_file(
        item=UntarEntryDataclass(from_path=output_tarfile, to_path=output_dir, conflict_err=True, del_tar=True)
    )

    logger.info(f'Unpacked to {output_file_untar}')


def pack_single_file(input_fname: Union[str, Path], key: str) -> Path:
    enc_file = encrypt_file(input_fname=input_fname, key=key, output_fname=None)
    tar_fname = make_tarfile(input_dir=enc_file, output_dir=None, compresslevel=9)
    if tar_fname:
        enc_file.unlink()
    return tar_fname


def unpack_single_file(input_fname: Path, key: str) -> Path:
    untar_fname = untar_file(
        item=UntarEntryDataclass(from_path=input_fname, to_path=None, conflict_err=True, del_tar=True)
    )
    dec_file = decrypt_file(
        input_fname=untar_fname, key=key, output_fname=Path(str(input_fname).split('.enc', maxsplit=1)[0])
    )
    if dec_file and untar_fname:
        untar_fname.unlink()
    return dec_file


@click.group()
def cli() -> None:
    pass


@cli.command('pack')
@click.argument('input-dir', nargs=1, type=click.Path(exists=True))
@click.option('--output-dir', '-out', type=click.Path(), default=None, show_default=True)
@click.option('--key', '-k', type=str)
@click.option('--chunk-size', '-s', type=int, default=400, show_default=True)
@click.option('--compresslevel', '-c', type=int, default=9, show_default=True)
def pack(input_dir: Path, output_dir: Path, chunk_size: int, key: str, compresslevel: int) -> None:
    input_dir = Path(input_dir).absolute()

    if not output_dir:
        output_dir = Path().absolute()
    else:
        output_dir = Path(output_dir).absolute()
    if not output_dir.exists():
        raise ValueError(f'Path {output_dir} does not exists!')

    full_pack(
        input_dir=input_dir,
        output_dir=output_dir,
        chunk_size=chunk_size,
        key=key,
        compresslevel=compresslevel,
        n_pools=N_POOLS,
    )


@cli.command('unpack')
@click.argument('input_dir', nargs=1, type=click.Path(exists=True))
@click.option('--output-dir', '-out', type=click.Path(), default=None, show_default=True)
@click.option('--key', '-k', type=str, show_default=True)
def unpack(input_dir: str, output_dir: str, key: str) -> None:
    input_dir_p = Path(input_dir).absolute()
    output_dir_p = Path(output_dir).absolute() if output_dir else input_dir_p

    input_dir_p = input_dir_p.parent if not input_dir_p.is_dir() else input_dir_p
    output_dir_p = output_dir_p.parent if not output_dir_p.is_dir() else output_dir_p

    full_unpack(input_dir=input_dir_p, output_dir=output_dir_p, key=key, n_pools=N_POOLS)


if __name__ == '__main__':
    cli()
