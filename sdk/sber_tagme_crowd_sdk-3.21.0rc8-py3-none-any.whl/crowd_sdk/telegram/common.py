import shutil
import tempfile
import zipfile
from functools import partial
from pathlib import Path
from typing import Callable, Dict, List, Optional, Union
from zipfile import ZIP_BZIP2, ZIP_DEFLATED, ZIP_LZMA, ZIP_STORED

import pyzipper  # pylint: disable=E0401
from aiogram.types import Message  # pylint: disable=E0401

DEFAULT_BOT_COMMANDS = 'botik'


def filter_by_chat(available_chats: List[int]) -> Callable[[Message], bool]:
    def filter_(message: Message) -> bool:
        return message.chat.id in available_chats

    return filter_


def filter_bot_commands(message: Message, bot_commands: str = DEFAULT_BOT_COMMANDS) -> bool:
    """
    bot_name like CTO, Pumba etc.
    """
    return bot_commands in message.text.lower()


def multiple_filters(filters: List[Callable[[Message], bool]]) -> Callable[[Message], bool]:
    def apply_filters(message: Message) -> bool:
        return all(f(message) for f in filters)

    return apply_filters


def full_feedback_files_archive(
    files: List[Path],
    base_name: str,
    target_dir: Union[str, Path],
    password: Optional[str] = None,
    compression_algo: Optional[int] = ZIP_BZIP2,
    compression_level: Optional[int] = 9,
    file_types: Optional[Dict[str, Optional[str]]] = None,
) -> str:
    """
    A function to make archive with feedback using a variety of compression algorithms.

    Args:
        files (List[Path]): data for archivation.
        base_name (str): name of output file without .zip extension.
        target_dir (Union[str, Path]): output directory.
        password (Optional[str]): password for archive, defaults to None (no password).
        compression_algo (Optional[int]): algorithm for compression.
            Defaults to ZIP_BZIP2 as the most efficient algo. More info in zipfile.Zipfile docs.
        compression_level (Optional[int]): int from 0 to 9 or None. Do not affect sertain compresion algos.
            Defaults to 9 (minimizing filesize). More info in zipfile.Zipfile docs.
        file_types (Optional[Dict[str, Optional[str]]]):
            Keys of this dictionary specifiy file extentions which will be added to archive.
            When a value corresponding to key is not None, it specifies which directory to place the files in

    Raises:
        ValueError: if get strange compression_algo.

    Returns:
        str: path to archive.
    """
    if compression_algo not in (ZIP_STORED, ZIP_DEFLATED, ZIP_BZIP2, ZIP_LZMA):
        raise ValueError(
            f"""Can't use '{compression_algo}' as compression_algo!
            Accepted algos: {(ZIP_STORED, ZIP_DEFLATED, ZIP_BZIP2, ZIP_LZMA)},
            which stands for ZIP_STORED, ZIP_DEFLATED, ZIP_BZIP2, ZIP_LZMA respectively"""
        )
    if isinstance(target_dir, str):
        target_dir = Path(target_dir)
    tmp: Union[str, Path]
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        for file in files:
            shutil.copy(file, tmp)
        if password is None:
            context_manager = partial(
                zipfile.ZipFile, target_dir / f'{base_name}.zip', 'w', compression_algo, compression_level
            )
        else:
            context_manager = partial(
                pyzipper.AESZipFile,  # pylint: disable=E0401
                target_dir / f'{base_name}.zip',
                'w',
                compression_algo,
                compression_level,
                encryption=pyzipper.WZ_AES,  # pylint: disable=E0401
            )
        with context_manager() as zip_file:
            if password is not None:
                zip_file.setpassword(password.encode('utf-8'))
            zip_files_one_type(path=tmp, file_type='wav', zipf=zip_file, to_dir='wav')
            zip_files_one_type(path=tmp, file_type='tsv', zipf=zip_file)
            zip_files_one_type(path=tmp, file_type='xlsx', zipf=zip_file)
            if file_types:
                for file_type, directory in file_types.items():
                    zip_files_one_type(path=tmp, file_type=file_type, zipf=zip_file, to_dir=directory)
        return str(target_dir / f'{base_name}.zip')


def zip_files_one_type(
    path: Path, file_type: str, zipf: Union[pyzipper.AESZipFile, zipfile.ZipFile], to_dir: Optional[str] = None
) -> None:  # pylint: disable=E0401
    """
    A function to add to archive files with specific extension.

    Args:
        path (Path): path to files.
        file_type (str): file extension without . (dot).
        zipf (Union[pyzipper.AESZipFile, zipfile.ZipFile]): context_manager.
            De facto a function that adds into the archive.
        to_dir (Optional[str]): name of a directory for this file type.
            Defaults to None, which puts files to the root of the archive.
    """
    if to_dir is None:
        to_dir = ''
    else:
        to_dir += '/'  # add separator between dir and file
    for file in path.rglob(f'*.{file_type}'):
        zipf.write(file, arcname=(to_dir + file.name))
