from dataclasses import dataclass
from typing import Callable

from aiogram.types import ContentType  # pylint: disable=import-error


@dataclass
class TGBotConfig:
    token: str
    base: str = 'https://nlb-nlbagent-ng-cloud-ift-003.delta.sbrf.ru/bot{token}/{method}'
    file: str = 'https://nlb-nlbagent-ng-cloud-ift-003.delta.sbrf.ru/file/bot{token}/{path}'


@dataclass
class TGHandler:
    func: Callable
    pattern: str
    help_: str
    ignore_help: bool = False
    content_type: ContentType = ContentType.TEXT


@dataclass
class HandlerTools:
    pass
