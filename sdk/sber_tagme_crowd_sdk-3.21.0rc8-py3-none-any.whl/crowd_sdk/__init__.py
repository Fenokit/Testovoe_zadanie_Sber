import os
from pathlib import Path

DEFAULT_CONFIG = Path(os.getenv('CROWD_CONFIG', '~/.crowd.cfg')).expanduser()
