import logging
from collections import defaultdict
from dataclasses import dataclass
from typing import List

import numpy as np

from crowd_sdk.aggregation.majority import (
    DEFAULT_IF_TIE_IN_MAJORITY,
    MajorityEntryDataclass,
    MajoritySpecialMode,
    aggregate_field,
)

WORDS_THRESHOLD = 0.51
MAJORITY_THRESHOLD = 0.25
ROUNDING_ORDER = 2
MIN_SEGMENT_DURATION = 0.05
MAX_AUDIO_DURATION = 100

logger = logging.getLogger(__file__)


@dataclass
class SoundsSegmentationEntryDataclass:
    task: str
    worker: str
    word_type: str
    start: float
    end: float


@dataclass
class SoundsSegmentationInnerDataclass:
    task: str
    start_pred: float
    end_pred: float


@dataclass
class SoundsSegmentationResultDataclass:
    task: str
    word_type_pred: str
    start_pred: float
    end_pred: float


def aggregate_one_task(  # pylint: disable=too-many-branches
    task_segments: List[SoundsSegmentationEntryDataclass],
    majority_threshold: float = MAJORITY_THRESHOLD,
    rounding_order: int = ROUNDING_ORDER,
    words_threshold: float = WORDS_THRESHOLD,
    min_segment_duration: float = MIN_SEGMENT_DURATION,
    max_audio_duration: float = MAX_AUDIO_DURATION,
) -> List[SoundsSegmentationResultDataclass]:
    if not task_segments:
        return []
    task = task_segments[0].task
    workers_count = len({row.worker for row in task_segments})
    need_sum = max(2, workers_count * majority_threshold)

    multiplicator = 10**rounding_order

    segment_arrays: List[List[int]] = []
    for row in task_segments:
        start = round(row.start, rounding_order) * multiplicator
        end = round(row.end, rounding_order) * multiplicator
        if start < max_audio_duration * multiplicator < end:
            logger.warning(
                'In task: %s (start: %s, end: %s) may be problem with end of region.'
                'Algorithm processes audio up to 100 sec long',
                task,
                row.start,
                row.end,
            )
        elif start > max_audio_duration * multiplicator:
            logger.warning(
                'Markup in task: %s (start: %s, end: %s) skipped because start of '
                'region bigger aggregation region (100 sec)',
                task,
                row.start,
                row.end,
            )
            continue
        array = [1 if start <= i <= end else 0 for i in range(max_audio_duration * multiplicator)]
        segment_arrays.append(array)

    result_segments_as_array = [1 if i >= need_sum else 0 for i in np.sum(segment_arrays, axis=0)]

    result_segments_borders: List[SoundsSegmentationInnerDataclass] = []
    segment_start = -1
    segment_end = -1
    for i, val in enumerate(result_segments_as_array):
        if val > 0 and segment_start == -1:
            segment_start = i / multiplicator
        if val > 0:
            segment_end = i / multiplicator
        if val == 0 and segment_start > 0:
            if segment_end - segment_start > min_segment_duration:
                result_segments_borders.append(
                    SoundsSegmentationInnerDataclass(task=task, start_pred=segment_start, end_pred=segment_end)
                )
            segment_start = -1
            segment_end = -1
    if segment_end - segment_start > min_segment_duration:  # region with end at end of audio
        result_segments_borders.append(
            SoundsSegmentationInnerDataclass(task=task, start_pred=segment_start, end_pred=segment_end)
        )

    resulting_segments: List[SoundsSegmentationResultDataclass] = []
    for result_segment in result_segments_borders:
        words_types_to_agg_data = []
        for input_segment in task_segments:
            start = round(input_segment.start, rounding_order)
            end = round(input_segment.end, rounding_order)
            if (
                start <= result_segment.start_pred <= end
                or start <= result_segment.end_pred <= end
                or (result_segment.start_pred <= start and result_segment.end_pred >= end)
            ):
                one_word_type_data = MajorityEntryDataclass(
                    task=input_segment.task,
                    worker=input_segment.worker,
                    label=input_segment.word_type,
                )
                words_types_to_agg_data.append(one_word_type_data)

        word_types_pred_list = aggregate_field(
            data=words_types_to_agg_data, threshold=words_threshold, special_mode=MajoritySpecialMode.TIEBREAKER.value
        )
        word_type_pred = str(word_types_pred_list[0].pred) if word_types_pred_list else DEFAULT_IF_TIE_IN_MAJORITY
        resulting_segments.append(
            SoundsSegmentationResultDataclass(
                task=result_segment.task,
                word_type_pred=word_type_pred,
                start_pred=result_segment.start_pred,
                end_pred=result_segment.end_pred,
            )
        )
    return resulting_segments


def aggregate_segments(
    data: List[SoundsSegmentationEntryDataclass],
    majority_threshold: float = MAJORITY_THRESHOLD,
    rounding_order: int = ROUNDING_ORDER,
    words_threshold: float = WORDS_THRESHOLD,
    min_segment_duration: float = MIN_SEGMENT_DURATION,
    max_audio_duration: float = MAX_AUDIO_DURATION,
) -> List[SoundsSegmentationResultDataclass]:
    tasks_segments_dict: defaultdict = defaultdict(list)
    for segment_data in data:
        tasks_segments_dict[segment_data.task].append(segment_data)

    aggregated_segments: List[SoundsSegmentationResultDataclass] = []
    for task_segmets in tasks_segments_dict.values():
        task_pred = aggregate_one_task(
            task_segments=task_segmets,
            majority_threshold=majority_threshold,
            rounding_order=rounding_order,
            words_threshold=words_threshold,
            min_segment_duration=min_segment_duration,
            max_audio_duration=max_audio_duration,
        )
        aggregated_segments += task_pred
    return aggregated_segments
