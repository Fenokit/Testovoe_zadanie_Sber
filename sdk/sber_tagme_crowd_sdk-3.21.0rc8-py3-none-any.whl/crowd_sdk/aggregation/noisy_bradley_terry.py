from dataclasses import dataclass
from typing import Any, List

import pandas as pd
from crowdkit.aggregation import NoisyBradleyTerry  # pylint: disable=import-error


@dataclass
class NoisyBradleyTerryInput:
    question: Any
    worker: str
    left: str
    right: str
    label: str


@dataclass
class NoisyBradleyTerryOutput:
    question: Any
    label: str
    score: float


def get_noisy_bradley_terry_pred(data: List[NoisyBradleyTerryInput]) -> List[NoisyBradleyTerryOutput]:
    data_df = pd.DataFrame(data)
    for column in ("left", "right", "label"):
        data_df[column] = list(zip(data_df["question"], data_df[column]))
    result = NoisyBradleyTerry(n_iter=1000).fit_predict(data_df)
    # Separate results
    result.index = pd.MultiIndex.from_tuples(result.index, names=["question", "label"])
    result = pd.DataFrame(result).reset_index()
    result.agg_score = result.agg_score.astype(float)

    result_pairs_dict = {}
    for row in result.to_dict("records"):
        if row["question"] not in result_pairs_dict:
            result_pairs_dict[row["question"]] = {"label": row["label"], "agg_score": row["agg_score"]}
        elif result_pairs_dict[row["question"]]["agg_score"] < row["agg_score"]:
            result_pairs_dict[row["question"]] = {"label": row["label"], "agg_score": row["agg_score"]}

    aggregated_data = []
    for question, results in result_pairs_dict.items():
        row = NoisyBradleyTerryOutput(
            question=question,
            label=results["label"],
            score=results["agg_score"],
        )
        aggregated_data.append(row)
    return aggregated_data
