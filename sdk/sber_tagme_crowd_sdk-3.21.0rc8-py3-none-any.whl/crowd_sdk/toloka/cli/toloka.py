#!/usr/bin/env python3
""" Console util for toloka managing """

import argparse
import logging

from crowd_sdk import DEFAULT_CONFIG
from crowd_sdk.toloka.cli.client import CLITolokaClient


def parse_args() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(allow_abbrev=False, description='Uses toloka sdk to handle pools and tasks')
    parser.add_argument('--sandbox', action='store_true', help='Is sandbox')
    parser.add_argument('--verbose', '-v', action='store_true', help='Logging level=debug')
    parser.add_argument('--config', default=DEFAULT_CONFIG, help='Project config')
    subparsers = parser.add_subparsers(title='commands', dest='command')

    parser_add_pool = subparsers.add_parser('add_pool', help='Clone from base pool and upload tasks from the file')
    parser_add_pool.set_defaults(func='create_pool_from_base_cli')
    parser_add_pool.add_argument('tasks_path', type=str, help='File with te tasks')
    parser_add_pool.add_argument('pool_name', type=str, help='pool name')
    parser_add_pool.add_argument('base_pool_id', type=int, help='base pool id')

    parser_download_pool = subparsers.add_parser('download_assignments', help='Download pool from toloka')
    parser_download_pool.set_defaults(func='download_assignments')
    parser_download_pool.add_argument('pool_id', help='Pool id to load')
    parser_download_pool.add_argument('out_file', help='Out dir')

    parser_download_attachments = subparsers.add_parser('download_attachments', help='Download pool from toloka')
    parser_download_attachments.set_defaults(func='download_attachments_cli')
    parser_download_attachments.add_argument('pool_id', help='Pool id to load')
    parser_download_attachments.add_argument('out_dir', help='Out dir')

    parser_accept_file = subparsers.add_parser('accept_assignments', help='Download pool from toloka')
    parser_accept_file.set_defaults(func='accept_assignments_cli')
    parser_accept_file.add_argument('path', help='Path to file with tasks ids to accept')

    parser_set_skill = subparsers.add_parser('set_skill', help='Set skill by the tsv given')
    parser_set_skill.set_defaults(func='set_skill_cli')
    parser_set_skill.add_argument('path', help='TSV to set')
    parser_set_skill.add_argument('skill_id', help='Skill id')

    parser_status = subparsers.add_parser('status', help='Print pools statuses for the project_id')
    parser_status.set_defaults(func='print_status')
    parser_status.add_argument('--project_id', help='Project id to show statuses for')

    return parser


def main() -> None:
    parser = parse_args()

    args = parser.parse_args()

    logging.basicConfig(
        format='[LINE:%(lineno)d] %(levelname)-8s [%(asctime)s]  %(message)s',
        level=logging.DEBUG if args.verbose else logging.INFO,
    )

    client = CLITolokaClient(config=args.config)

    params = {k: v for k, v in vars(args).items() if k not in ('command', 'func', 'config')}
    if args.command:
        client.run_command(args.func, **params)
    else:
        parser.print_help()
        parser.exit(status=1, message='No command specified\n')


if __name__ == '__main__':
    main()
