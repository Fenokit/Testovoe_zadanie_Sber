import json
import logging
import random
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple, Union

import pandas as pd
import tqdm

from crowd_sdk.core.utils.func import Runnable
from crowd_sdk.core.utils.table import tsv_load
from crowd_sdk.toloka import TolokaSyncClient

logger = logging.getLogger(__name__)

if 'IPython' in sys.modules:
    from IPython import get_ipython  # pylint: disable=E0401

    if type(get_ipython()).__module__.startswith('ipykernel.'):
        from tqdm import tqdm_notebook as tqdm
    else:
        from tqdm import tqdm
else:
    from tqdm import tqdm


class CLITolokaClient(TolokaSyncClient, Runnable):
    def __init__(self, config: str, is_sandbox: bool = False):
        super().__init__(config=config, is_sandbox=is_sandbox)

    def set_skill_cli(self, path: Union[Path, str], skill_id: Union[int, str]) -> None:  # pylint: disable=W0237
        users = list(tsv_load(path))
        super().set_skill(users, skill_id)

    def read_tasks(self, path: Union[Path, str]) -> Iterable:
        if str(path).endswith('.tsv'):
            task_list = list(tsv_load(path))
        elif str(path).endswith('.json'):
            with open(path) as f:
                task_list = json.load(f)
        else:
            raise ValueError(f'path {path} has unknown extention, should be one of [\'tsv\', \'json\']')

        assert task_list, f'Tasks file "{path}" is empty'
        for task_row in task_list:
            if str(path).endswith('.tsv'):
                yield self.row_to_task(task_row)
            else:
                yield task_row

    def add_suites2(self, pool_id: Union[int, str], tasks: List[Dict[str, Any]], overlap: int) -> None:
        tasks_per_suite = 1

        task_suites = []
        suite = []
        for i, task in enumerate(tasks):
            suite.append(self.row_to_task(task))
            if len(suite) == tasks_per_suite:
                random.shuffle(suite)
                task_suites.append(
                    {
                        'pool_id': pool_id,
                        'tasks': suite,
                        'overlap': overlap,
                    }
                )
                suite = []
        if suite:
            task_suites.append(
                {
                    'pool_id': pool_id,
                    'tasks': suite,
                    'overlap': overlap,
                }
            )

        for i in range(0, len(task_suites), self.UPLOAD_LIMIT):
            response = self.post(
                'task-suites', params={'allow_defaults': 'true'}, json=task_suites[i : i + self.UPLOAD_LIMIT]
            )
            response.raise_for_status()

    def create_pool_from_base_cli(
        self, tasks_path: Union[Path, str], pool_name: str, base_pool_id: Union[int, str], with_honeypots: bool = True
    ) -> Tuple[int, int]:  # pylint: disable=W0237
        pool_data = self.read_tasks(tasks_path)
        pool_data = list(pool_data)
        return super().create_pool_from_base(pool_data, pool_name, base_pool_id, with_honeypots)

    @staticmethod
    def toloka_style_key(key: str) -> str:
        key_type, key_name = key.split('_', 1)
        return key_type.upper() + ':' + key_name

    def print_status(self, project_id: Union[int, str]) -> None:
        pools_list = list(self.get_pools(project_id=project_id))

        assert pools_list, 'No items in response.'
        for pool_info in pools_list:
            if pool_info['status'] == self.STATUS.ARCHIVED.value:
                continue
            logger.info(
                f'{pool_info["id"]}\t{pool_info["status"]}\t{pool_info["created"]}\t{pool_info["private_name"]}'
            )

    def wait_for_results_cli(self, pool_id: Union[int, str], prefix: Union[Path, str, None] = None) -> Path:
        super().wait_for_results(pool_id)
        today = datetime.today().strftime('%d-%m-%Y')
        assignments = Path(f'{pool_id}_{today}.tsv')

        if prefix:
            prefix = Path(prefix)
            if not prefix.exists():
                prefix.mkdir(parents=True)
            assignments = prefix / assignments
        self.download_assignments(pool_id, assignments)
        return assignments

    def download_assignments(self, pool_id: Union[int, str], out_file: Union[Path, str]) -> int:
        assert out_file, 'out_file is required in TolokaASRClient'
        out_file = Path(out_file).expanduser().resolve()
        assignments = []
        for i in tqdm(super().get_assignments_table(pool_id), desc=f'Gathering assignments for {pool_id}'):
            assignments.append(i)
        assignments_df = pd.DataFrame(assignments)
        out_file.parent.mkdir(parents=True, exist_ok=True)
        assignments_df.to_csv(out_file, sep='\t', index=False)
        return len(assignments)

    def accept_assignments_cli(self, path: Union[Path, str]) -> None:  # pylint: disable=W0237
        with open(path) as f:
            super().accept_assignments(list(f))

    def download_attachments_cli(self, pool_id: Union[int, str], out_dir: Union[Path, str]) -> pd.DataFrame:
        out_dir = Path(out_dir)
        attachments = []
        for i in tqdm(super().download_attachments(pool_id, out_dir), desc='Gathering attachments'):
            attachments.append(i)
        attachments_df = pd.DataFrame(
            attachments, columns=['id', 'path', 'assignment_id', 'attachment_id', 'attachment_name', 'user_id']
        )
        out_dir.mkdir(parents=True, exist_ok=True)
        attachments_path = out_dir / 'attachments.tsv'
        logger.info('Writing %s', attachments_path)
        attachments_df.to_csv(attachments_path, sep='\t', index=False)
        return attachments_df

    def upload_task_to_toloka(
        self,
        tasks_list: List[Dict[str, Any]],
        base_pool_id: int,
        pool_name: str,
        honey_tsv_path: str,
        overlap: int,
        open_pool: bool = True,
    ) -> str:
        """
        Duplicate pool "base_pool_id" with settings, add "honey_tsv_path" hoenypots and "tasks_list"
        """
        assert overlap > 0, ValueError(f'Overlap {overlap} is less then zero')
        pool_id, _ = self.create_pool_from_base_cli(
            tasks_path=honey_tsv_path, pool_name=pool_name, base_pool_id=base_pool_id
        )
        len_tasks = self.add_tasks(pool_id, tasks_list, overlap=overlap)
        logger.info(f'There are {len_tasks} tasks was uploaded.')
        if open_pool:
            self.open_pool(pool_id)
        return str(pool_id)
