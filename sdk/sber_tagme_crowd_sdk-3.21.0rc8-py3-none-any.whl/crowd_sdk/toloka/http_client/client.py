# pylint: disable=C0302,W0613
import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, AsyncIterable, Dict, Generator, List, Optional, Tuple, Union

import aiohttp
import aiohttp.web
import nest_asyncio
from tqdm import tqdm

from crowd_sdk.core.utils.common import format_datetime_for_toloka, get_event_loop, parse_date
from crowd_sdk.core.utils.http import (
    DEFAULT_POOL_SIZE,
    RETRY_HTTP_CODES,
    RETRY_USER_EXCEPTIONS_LIST,
    ExponentialBackoffPolicy,
    check_url,
    retry_request,
)
from crowd_sdk.core.utils.http_client import HttpMethod, HttpWrapper, JsonAPI
from crowd_sdk.toloka.config import DEFAULT_CONFIG, TolokaConfig

logger = logging.getLogger(__name__)
nest_asyncio.apply()

ASSIGNMENT_KEY_MAPPING = {
    'id': 'assignment_id',
    'task_suite_id': 'task_suite_id',
    'user_id': 'worker_id',
    'status': 'status',
    'created': 'started',
    'submitted': 'submitted',
    'accepted': 'accepted',
    'rejected': 'rejected',
    'skipped': 'skipped',
    'expired': 'expired',
    'reward': 'reward',
}

# Seconds to wait after request to toloka pool if it is not ready yet
AWAKE_EVERY = 60

# stop wait pool, if it closed manualy for N days
POOL_MANUAL_CLOSED_THRESHOLD_DAYS = 14


class OperationStatus(Enum):
    FAIL = 'FAIL'
    SUCCESS = 'SUCCESS'


class PoolStatus(Enum):
    OPEN = 'OPEN'
    CLOSED = 'CLOSED'
    LOCKED = 'LOCKED'
    ARCHIVED = 'ARCHIVED'
    COMPLETED = 'COMPLETED'


class PoolLastCloseReason(Enum):
    MANUAL = 'MANUAL'  # закрыт заказчиком.
    EXPIRED = 'EXPIRED'  # истек срок, указанный в ключе will_expire.
    COMPLETED = 'COMPLETED'  # закрыт автоматически, так как все задания в пуле выполнены.
    NOT_ENOUGH_BALANCE = 'NOT_ENOUGH_BALANCE'  # закрыт автоматически, так как закончились деньги на счете в Толоке.
    ASSIGNMENTS_LIMIT_EXCEEDED = 'ASSIGNMENTS_LIMIT_EXCEEDED'  # закрыт автоматически, так как превышен лимит
    # выданных страниц заданий(не более 2 млн).
    BLOCKED = 'BLOCKED'  # закрыт автоматически, так как аккаунт заказчика заблокирован администратором Толоки.
    FOR_UPDATE = 'FOR_UPDATE'  # пул закрыт на время редактирования.


class AssignmentStatus(Enum):
    FAIL = 'FAIL'
    SUCCESS = 'SUCCESS'
    OPEN = 'OPEN'
    CLOSED = 'CLOSED'
    ARCHIVED = 'ARCHIVED'
    ACCEPTED = 'ACCEPTED'
    EXPIRED = 'EXPIRED'
    SKIPPED = 'SKIPPED'
    SUBMITTED = 'SUBMITTED'


def filter_attachment_id(filename: str) -> str:
    return filename.replace('.', '_')


class TolokaClient(JsonAPI):  # pylint: disable=R0904
    DOWNLOAD_LIMIT: int = 10000
    UPLOAD_LIMIT: int = 100

    def __init__(
        self,
        http: Optional[HttpWrapper] = None,
        config: Union[str, Path, dict, TolokaConfig] = DEFAULT_CONFIG,
        is_sandbox: bool = False,
    ) -> None:
        http = http or HttpWrapper()
        self.loop = get_event_loop()

        if isinstance(config, (str, Path)):
            config = Path(config).expanduser()
            assert config.is_file(), f'No toloka config found in `{config}`'
            config = TolokaConfig.from_global_config(config, is_sandbox=is_sandbox)
        elif isinstance(config, dict):
            config = TolokaConfig.from_dict(config, is_sandbox=is_sandbox)
        elif not isinstance(config, TolokaConfig):
            raise TypeError(f'Wrong config type {type(TolokaConfig)}')

        url = config.url
        token = config.token

        assert token, 'Set up toloka token= or config.token='
        assert url, 'Set up url= or config.url='

        super().__init__(http=http, url=f'https://{url}/api/v1/', token=token, auth_type=config.auth_type)
        self.raw_api = JsonAPI(http=http, url=f'https://{url}/', token=token, auth_type=config.auth_type)
        concurrency = DEFAULT_POOL_SIZE if http is None else http.limit_per_host
        self.thread_pool = ThreadPoolExecutor(concurrency)

    @staticmethod
    def toloka_style_key(key: str) -> str:
        key_type, key_name = key.split('_', 1)
        return key_type.upper() + ':' + key_name

    @staticmethod
    def get_unreached_urls(urls: List[str]) -> Generator[str, None, None]:
        for url in urls:
            if check_url(url):
                continue
            yield url

    async def close(self) -> None:
        await self.http.close()

    # -----------------------------------------------------------------------------
    #                   HTTP MENTHOS retries redefenition
    # -----------------------------------------------------------------------------
    # backoff factor = 1.8
    # attempts = 13 (including zero attempt)
    # retries = 12
    # wait periods num = 12
    # wait periods [0.9, 1.8, 3.6, 7.2, 14.4, 28.8, 57.6, 115.2, 230.4, 460.8, 921.6, 1843.2]
    # total wait 61 minutes

    @retry_request(
        statuses=RETRY_HTTP_CODES,
        attempts=13,
        retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8),
        user_exceptions=RETRY_USER_EXCEPTIONS_LIST,
    )
    async def post(self, url: str, **kwargs: Any) -> Any:
        return await self.request(method=HttpMethod.POST, url=url, **kwargs)

    @retry_request(
        statuses=RETRY_HTTP_CODES,
        attempts=13,
        retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8),
        user_exceptions=RETRY_USER_EXCEPTIONS_LIST,
    )
    async def get(self, url: str, **kwargs: Any) -> Any:
        return await self.request(method=HttpMethod.GET, url=url, **kwargs)

    @retry_request(
        statuses=RETRY_HTTP_CODES,
        attempts=13,
        retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8),
        user_exceptions=RETRY_USER_EXCEPTIONS_LIST,
    )
    async def put(self, url: str, **kwargs: Any) -> Any:
        return await self.request(method=HttpMethod.PUT, url=url, **kwargs)

    @retry_request(
        statuses=RETRY_HTTP_CODES,
        attempts=13,
        retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8),
        user_exceptions=RETRY_USER_EXCEPTIONS_LIST,
    )
    async def patch(self, url: str, **kwargs: Any) -> Any:
        return await self.request(method=HttpMethod.PATCH, url=url, **kwargs)

    @retry_request(
        statuses=RETRY_HTTP_CODES,
        attempts=13,
        retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8),
        user_exceptions=RETRY_USER_EXCEPTIONS_LIST,
    )
    async def delete(self, url: str, **kwargs: Any) -> Any:
        return await self.request(method=HttpMethod.DELETE, url=url, **kwargs)

    # -----------------------------------------------------------------------------
    #                                  PROJECT
    # -----------------------------------------------------------------------------

    async def get_projects(  # pylint: disable=R0913
        self,
        status: Optional[str] = None,
        sort: Optional[str] = None,
        owner: Optional[str] = None,
        limit: Optional[int] = None,
        id_gt: Optional[int] = None,
        id_gte: Optional[int] = None,
        id_lt: Optional[int] = None,
        id_lte: Optional[int] = None,
        created_gt: Optional[str] = None,
        created_gte: Optional[str] = None,
        created_lt: Optional[str] = None,
        created_lte: Optional[str] = None,
    ) -> AsyncIterable[dict]:
        params = {k: v for k, v in locals().items() if k not in ['params', 'self'] and v is not None}
        async for i in self.gather('projects', **params):
            yield i

    async def get_project(self, project_id: int) -> dict:
        return await self.get(f'projects/{project_id}')

    async def set_project(self, project_id: int, project_config: dict) -> dict:
        return await self.put(f'projects/{project_id}', json=project_config)

    async def create_project(self, project_id: int, project_config: dict) -> dict:
        return await self.post(f'projects/{project_id}', json=project_config)

    async def archive_project(self, project_id: int) -> dict:
        return await self.put(f'projects/{project_id}/archive')

    # -----------------------------------------------------------------------------
    #                                  POOL
    # -----------------------------------------------------------------------------

    async def get_pools(  # pylint: disable=R0913
        self,
        project_id: Optional[Union[str, int]] = None,
        status: Optional[str] = None,
        sort: Optional[str] = None,
        limit: Optional[int] = None,
        id_gt: Optional[int] = None,
        id_gte: Optional[int] = None,
        id_lt: Optional[int] = None,
        id_lte: Optional[int] = None,
        created_gt: Optional[str] = None,
        created_gte: Optional[str] = None,
        created_lt: Optional[str] = None,
        created_lte: Optional[str] = None,
        last_started_gt: Optional[str] = None,
        last_started_gte: Optional[str] = None,
        last_started_lt: Optional[str] = None,
        last_started_lte: Optional[str] = None,
    ) -> AsyncIterable[dict]:
        params = {k: v for k, v in locals().items() if k not in ['params', 'self'] if v is not None}
        async for i in self.gather('pools', **params):
            yield i

    async def get_pool(self, pool_id: Union[str, int]) -> dict:
        return await self.get(f'pools/{pool_id}')

    async def set_pool(self, pool_id: Union[str, int], pool_params: dict) -> dict:
        return await self.put(f'pools/{pool_id}', json=pool_params)

    async def open_pool(self, pool_id: Union[str, int]) -> dict:
        return await self.post(f'pools/{pool_id}/open', json={})

    async def close_pool(self, pool_id: Union[str, int]) -> dict:
        return await self.post(f'pools/{pool_id}/close', json={})

    async def archive_pool(self, pool_id: Union[str, int]) -> dict:
        return await self.post(f'pools/{pool_id}/archive', json={})

    async def fix_mixer_config(self, pool_id: Union[str, int]) -> None:
        """
        Fix tasks mixer to avoid strict order when show golden tasks
        """
        logger.debug('Configure clonned pool %s', pool_id)
        pool_params = await self.get(f'pools/{pool_id}')
        if 'mix_tasks_in_creation_order' in pool_params.get('mixer_config', {}):
            pool_params['mixer_config']['mix_tasks_in_creation_order'] = False
        await self.put(f'pools/{pool_id}', json=pool_params)

    async def clone_pool_and_fix(self, pool_id: Union[str, int]) -> int:
        """
        Special cloning function.
        It applies fix for tasks mixer to avoid strict order when show golden tasks
        """
        operation = await self.post(f'pools/{pool_id}/clone', json={})
        clonned_pool_id = int(await self.wait_operation(operation, 'pool_id'))
        logger.debug('Pool cloned from %s to %s', pool_id, clonned_pool_id)
        await self.fix_mixer_config(clonned_pool_id)
        return clonned_pool_id

    async def wait_pool(self, pool_id: Union[str, int]) -> None:
        logger.info('Start wait for pool %s...', pool_id)
        period_start = datetime.now()
        while True:
            pool_info = await self.get_pool(pool_id)
            if (
                pool_info['status'] == PoolStatus.OPEN.value
                and (datetime.now() - period_start).total_seconds() >= 5 * 60
            ):  # 5 minutes
                logger.info('Pool %s is open, still wait for it...', pool_id)
                period_start = datetime.now()
            if (
                pool_info['status'] == PoolStatus.CLOSED.value
                and pool_info.get('last_close_reason') == PoolLastCloseReason.COMPLETED.value
                or pool_info['status'] in [PoolStatus.CLOSED.value, PoolStatus.ARCHIVED.value]
                and pool_info.get('last_stopped', None) is not None
                and (datetime.now() - parse_date(pool_info['last_stopped'])).days >= POOL_MANUAL_CLOSED_THRESHOLD_DAYS
            ):
                return
            await asyncio.sleep(AWAKE_EVERY)

    async def create_pool(self, pool_params: dict, pool_name: Optional[str] = None) -> str:
        if pool_name:
            pool_params['private_name'] = pool_name
        if 'id' in pool_params:
            del pool_params['id']
        return (await self.post('pools', json=pool_params)).get('id')

    async def create_pool_from_base(
        self,
        pool_data: Any,
        pool_name: str,
        base_pool_id: int,
        with_honeypots: bool = True,
        overlap: Optional[int] = None,
    ) -> Tuple[int, int]:
        pool_id = await self.clone_pool_and_fix(pool_id=base_pool_id)
        pool_params = await self.get_pool(pool_id=pool_id)

        pool_params['private_name'] = pool_name
        if overlap is None:
            overlap = pool_params['defaults']['default_overlap_for_new_task_suites']
        else:
            pool_params['defaults']['default_overlap_for_new_task_suites'] = overlap
        if 'mix_tasks_in_creation_order' in pool_params.get('mixer_config', {}):
            pool_params['mixer_config']['mix_tasks_in_creation_order'] = False
        if not with_honeypots:
            pool_params['mixer_config']['golden_tasks_count'] = 0
            pool_params['mixer_config']['training_tasks_count'] = 0

        await self.set_pool(pool_id=pool_id, pool_params=pool_params)

        return pool_id, await self.add_tasks(pool_id=pool_id, tasks_list=pool_data, overlap=overlap)

    async def create_pool_from_params(
        self,
        pool_data: List[Dict[str, Any]],
        pool_name: str,
        pool_params: dict,
    ) -> Tuple[str, int]:
        overlap = pool_params['defaults']['default_overlap_for_new_task_suites']
        pool_id = await self.create_pool(pool_params=pool_params, pool_name=pool_name)
        return pool_id, await self.add_tasks(pool_id=pool_id, tasks_list=pool_data, overlap=overlap)

    async def get_pools_by_statuses(
        self,
        project_id: Union[int, str],
        statuses: Optional[list] = None,
        limit: Optional[int] = None,
        created_gte: Optional[datetime] = None,
        created_lte: Optional[datetime] = None,
        last_started_gte: Optional[datetime] = None,
        last_started_lte: Optional[datetime] = None,
    ) -> AsyncIterable[dict]:
        additional_args = {}
        if created_gte is not None:
            additional_args['created_gte'] = format_datetime_for_toloka(created_gte)
        if created_lte is not None:
            additional_args['created_lte'] = format_datetime_for_toloka(created_lte)
        if last_started_gte is not None:
            additional_args['last_started_gte'] = format_datetime_for_toloka(last_started_gte)
        if last_started_lte is not None:
            additional_args['last_started_lte'] = format_datetime_for_toloka(last_started_lte)

        if statuses is None:
            statuses = [None]
        for status in statuses:
            async for pool in self.get_pools(
                status=status, project_id=project_id, limit=limit, **additional_args  # type: ignore
            ):
                yield pool

    async def set_pool_priority(self, pool_id: int, priority: int) -> None:
        await self.patch(f'pools/{pool_id}', json={'priority': priority})

    # -----------------------------------------------------------------------------
    #                              OPERATIONS
    # -----------------------------------------------------------------------------

    async def get_operation(self, op_id: str) -> dict:
        return await self.get(f'operations/{op_id}')

    async def wait_operation(self, operation: Any, key: str) -> Any:
        i = 0
        while operation['status'] != OperationStatus.SUCCESS.value:
            if operation['status'] == OperationStatus.FAIL.value or i > 60:  # 5 minutes of retry
                possible_cloned_pool_id = operation.get('details', {}).get('pool_id', 'None')
                raise RuntimeError(
                    'Pool clone failed. Status='
                    + str(operation['status'])
                    + f', clone pool id = {possible_cloned_pool_id},'
                    f' operation id = {operation["id"]}'
                )
            logger.debug('Cloning in progress... Sleep(5)')
            await asyncio.sleep(5)
            operation = await self.get_operation(operation['id'])
            i += 1
        return operation['details'][key]

    # -----------------------------------------------------------------------------
    #                                  TASKS
    # -----------------------------------------------------------------------------

    @staticmethod
    def task_suite_to_rows(task_suite: dict) -> Generator[dict, None, None]:
        """
        Converts json for of the task_suite to dataframe-ready key-value dicts
        """
        for task, solution in zip(task_suite['tasks'], task_suite['solutions']):
            answer = {}
            for k, v in task['input_values'].items():
                answer['input_' + k] = v
            if 'output_values' in solution:
                for k, v in solution['output_values'].items():
                    if 'audio' in k:
                        answer['output_' + k] = filter_attachment_id(v)
                    else:
                        answer['output_' + k] = v
            if 'known_solutions' in task and len(task['known_solutions']) > 0:
                for k, v in task['known_solutions'][0]['output_values'].items():
                    answer['golden_' + k] = v
            for task_key, assingment_key in ASSIGNMENT_KEY_MAPPING.items():
                answer['assignment_' + assingment_key] = task_suite.get(task_key, '')
            answer['assignment_task_id'] = task['id']
            yield answer

    async def get_tasks(  # pylint: disable=R0913
        self,
        pool_id: Optional[Union[str, int]] = None,
        sort: Optional[str] = None,
        overlap: Optional[int] = None,
        limit: Optional[int] = None,
        id_gt: Optional[int] = None,
        id_gte: Optional[int] = None,
        id_lt: Optional[int] = None,
        id_lte: Optional[int] = None,
        created_gt: Optional[str] = None,
        created_gte: Optional[str] = None,
        created_lt: Optional[str] = None,
        created_lte: Optional[str] = None,
        overlap_gt: Optional[int] = None,
        overlap_gte: Optional[int] = None,
        overlap_lt: Optional[int] = None,
        overlap_lte: Optional[int] = None,
    ) -> AsyncIterable[dict]:
        """
        Searchs tasks by the variety of conditions, most common cases are to search by pool_id,
        or use pagination: limit and aome of sort, gt, lt options
        """
        params = {k: v for k, v in locals().items() if k not in ['params', 'self'] and v is not None}
        async for i in self.gather('tasks', **params):
            yield i

    async def get_control_tasks(self, pool_id: int) -> AsyncIterable[dict]:
        async for task in self.get_tasks(pool_id=pool_id):
            if task.get('known_solutions', False):
                item = {'INPUT:' + k: v for k, v in task['input_values'].items()}

                for solution in task['known_solutions']:
                    item_w_golden = deepcopy(item)
                    item_w_golden.update({'GOLDEN:' + k: v for k, v in solution['output_values'].items()})
                    yield item_w_golden

    async def get_task_suite(self, task_suite_id: str) -> Dict[str, Any]:
        return await self.get(url=f'task-suites/{task_suite_id}')

    async def get_task(self, task_id: str) -> Dict[str, Any]:
        return await self.get(url=f'tasks/{task_id}')

    async def add_exam_tasks(self, pool_id: int, tasks_list: List[Dict[str, str]], overlap: int = 3) -> int:
        tasks = {'pool_id': str(pool_id), 'tasks': tasks_list, 'overlap': overlap}
        _ = await self.post('task-suites', params={'allow_defaults': 'true'}, json=tasks)
        return len(tasks)

    async def change_task_suite_overlap(
        self, task_suite_id: str, overlap: Optional[int] = None, infinite_overlap: bool = False
    ) -> Dict[str, Any]:
        json = {k: v for k, v in locals().items() if k not in ['params', 'self'] and v is not None}
        return await self.patch(url=f'task-suites/{task_suite_id}', json=json)

    async def change_task_overlap(
        self, task_id: str, overlap: Optional[int] = None, infinite_overlap: bool = False
    ) -> Dict[str, Any]:
        json = {k: v for k, v in locals().items() if k not in ['params', 'self'] and v is not None}
        return await self.patch(url=f'/tasks/{task_id}/set-overlap-or-min', json=json)

    async def add_tasks(self, pool_id: Union[int, str], tasks_list: List[Dict[str, str]], overlap: int = 3) -> int:
        tasks = []
        for task in tasks_list:
            task['pool_id'] = str(pool_id)
            if 'known_solutions' in task:
                task['infinite_overlap'] = 'true'
            else:
                task['overlap'] = str(overlap)
            tasks.append(task)
        tasks_range = range(0, len(tasks), self.UPLOAD_LIMIT)
        for i in tqdm(tasks_range, total=len(tasks_range)):
            _ = await self.post('tasks', params={'allow_defaults': 'true'}, json=tasks[i : i + self.UPLOAD_LIMIT])
        return len(tasks)

    @staticmethod
    def row_to_task(row: Dict[str, Any]) -> Dict[str, Any]:  # pylint: disable=R0912
        res: Dict[str, Any] = {'input_values': {}}
        # check is golden massives equal length
        row_golden = dict(
            filter(
                lambda x: x[0].startswith('GOLDEN:') and not (isinstance(x[1], (str, list)) and not x[1]), row.items()
            )
        )

        golden_vars_list_length = 0
        for k, v in row_golden.items():
            if isinstance(v, list):
                if golden_vars_list_length and len(v) != golden_vars_list_length:
                    raise ValueError(
                        f'golden_vars_list_length({golden_vars_list_length}) != '
                        f'golden_vars_list_length({golden_vars_list_length})'
                    )
                if not golden_vars_list_length and len(v) != golden_vars_list_length:
                    golden_vars_list_length = len(v)

        if row_golden:
            golden_vars_list_length = golden_vars_list_length if golden_vars_list_length else 1

        known_solutions: List[Dict[str, Any]] = []
        for _ in range(golden_vars_list_length):
            known_solutions.append({})

        for k, v in row.items():
            if k.startswith('INPUT:'):
                n = k.split(':', 1)[1]
                res['input_values'][n] = v
            if k.startswith('GOLDEN:') and not (isinstance(v, (str, list)) and not v):
                n = k.split(':', 1)[1]
                if isinstance(v, list):
                    for i, v_var in enumerate(v):
                        known_solutions[i][n] = v_var
                elif isinstance(v, (str, int, float, bool, dict)):
                    for i in range(golden_vars_list_length):
                        known_solutions[i][n] = v
                else:
                    raise TypeError(f'Unknown golden task type: {type(v)}')
            if k.startswith('HINT:') and v:
                res['message_on_unknown_solution'] = v

        if known_solutions:
            res['known_solutions'] = []
            for known_solution in known_solutions:
                solution = {
                    'correctness_weight': 1,
                    'output_values': known_solution,
                }
                res['known_solutions'].append(solution)
            res['infinite_overlap'] = True
        return res

    async def stop_assigning_task(self, task_id: str) -> Dict[str, Any]:
        json = {"overlap": 0, "infinite_overlap": 'false'}
        return await self.patch(f'tasks/{task_id}/set-overlap-or-min', json=json)

    # -----------------------------------------------------------------------------
    #                                  RESULTS
    # -----------------------------------------------------------------------------

    async def billing(self, date_from: str, date_to: str) -> List[Dict[str, Any]]:
        url = '/api/billing/requester/expense-log'
        result = await self.raw_api.get(
            url,
            params={
                'from': date_from,
                'to': date_to,
                'timezone': '+03:00',
            },
        )

        return result

    async def get_stats(
        self,
        project_id: str,
    ) -> AsyncIterable[dict]:
        url = f'api/new/requester/projects/{project_id}/pools/stats'
        has_results = None
        page = 0
        while has_results is not False:
            result = await self.raw_api.get(
                url,
                params={
                    'page': page,
                    'fields': 'displayStatus,expectedFinishTimeMillis,expectedTolokaFee,avgSubmitAssignmentMillis',
                },
            )
            page += 1
            for item in result['content']:
                yield item
            has_results = result['numberOfElements'] > 0

    async def get_stats_count(
        self,
        project_id: str,
    ) -> list:
        url = f'api/new/requester/projects/{project_id}/pools/stats'
        result = await self.raw_api.get(
            url,
            params={
                'size': 1,
                'fields': 'displayStatus,expectedFinishTimeMillis,expectedTolokaFee,avgSubmitAssignmentMillis',
            },
        )
        return result['totalElements'] > 0

    async def get_assignments(  # pylint: disable=R0913,R0914
        self,
        pool_id: Optional[Union[str, int]] = None,
        status: Optional[str] = None,
        task_id: Optional[str] = None,
        task_suite_id: Optional[str] = None,
        user_id: Optional[str] = None,
        sort: Optional[str] = None,
        limit: Optional[int] = None,
        id_gt: Optional[int] = None,
        id_gte: Optional[int] = None,
        id_lt: Optional[int] = None,
        id_lte: Optional[int] = None,
        created_gt: Optional[str] = None,
        created_gte: Optional[str] = None,
        created_lt: Optional[str] = None,
        created_lte: Optional[str] = None,
        submitted_gt: Optional[int] = None,
        submitted_gte: Optional[int] = None,
        submitted_lt: Optional[int] = None,
        submitted_lte: Optional[int] = None,
        accepted_gt: Optional[int] = None,
        accepted_gte: Optional[int] = None,
        accepted_lt: Optional[int] = None,
        accepted_lte: Optional[int] = None,
        rejected_gt: Optional[int] = None,
        rejected_gte: Optional[int] = None,
        rejected_lt: Optional[int] = None,
        rejected_lte: Optional[int] = None,
        skipped_gt: Optional[int] = None,
        skipped_gte: Optional[int] = None,
        skipped_lt: Optional[int] = None,
        skipped_lte: Optional[int] = None,
        expired_gt: Optional[int] = None,
        expired_gte: Optional[int] = None,
        expired_lt: Optional[int] = None,
        expired_lte: Optional[int] = None,
    ) -> AsyncIterable[dict]:
        params = {k: v for k, v in locals().items() if k not in ['params', 'self'] and v is not None}
        async for i in self.gather('assignments', **params):
            yield i

    async def get_assignments_table(self, pool_id: Union[str, int]) -> AsyncIterable[dict]:
        async for answer in self.get_pool_results(pool_id=pool_id):
            yield {self.toloka_style_key(k): v for k, v in answer.items()}

    async def accept_assignment(self, assignment_id: str) -> None:
        assignment_id = assignment_id.rstrip('\r\n')
        assignment = await self.get(f'assignments/{assignment_id}')
        if assignment['status'] != AssignmentStatus.SUBMITTED.value:
            return
        await self.patch(f'assignments/{assignment_id}', json={'status': AssignmentStatus.ACCEPTED.value})

    async def accept_assignments(self, assignments: List[str]) -> AsyncIterable:
        for assignment in assignments:
            yield self.accept_assignment(assignment)

    async def get_pool_results_info(self, pool_id: Union[str, int], accepted_only: bool = True) -> AsyncIterable[dict]:
        async for task_suite in self.gather('assignments', pool_id=pool_id):
            if task_suite['status'] != AssignmentStatus.ACCEPTED.value and accepted_only:
                continue
            if task_suite['status'] != AssignmentStatus.SUBMITTED.value:
                continue
            for task, solution in zip(task_suite['tasks'], task_suite['solutions']):
                answer = {
                    'user_id': task_suite['user_id'],
                    'task_suite_id': task_suite['task_suite_id'],
                    'task_id': task['id'],
                    'input_values': task['input_values'],
                    'output_values': solution['output_values'],
                }
                yield answer

    async def get_pool_results(self, pool_id: Union[str, int]) -> AsyncIterable[dict]:
        async for task_suite in self.get_assignments(pool_id=pool_id):
            if task_suite['status'] not in [AssignmentStatus.ACCEPTED.value, AssignmentStatus.SUBMITTED.value]:
                continue
            for answer in self.task_suite_to_rows(task_suite):
                yield answer

    async def wait_for_results(self, pool_id: Union[str, int]) -> AsyncIterable[dict]:
        await self.wait_pool(pool_id)
        async for item in self.get_assignments_table(pool_id):
            yield item

    async def get_pool_expenses(self, pool_id: Union[str, int], date_from: Optional[str] = None) -> float:
        money = 0.0
        async for task_suite in self.get_assignments(pool_id=pool_id, created_gte=date_from):
            if task_suite['status'] not in [AssignmentStatus.ACCEPTED.value, AssignmentStatus.SUBMITTED.value]:
                continue
            money += task_suite['reward']
        return money

    # -----------------------------------------------------------------------------
    #                                  ATTACHMENTS
    # -----------------------------------------------------------------------------

    async def download_attachment(self, fpath: Union[str, Path], attachment_id: str) -> None:
        fpath = Path(fpath)
        tmp_path = fpath.with_suffix(fpath.suffix + '._tmp')
        with open(tmp_path, 'wb') as f:
            response = await self.raw_request(HttpMethod.GET, f'attachments/{attachment_id}/download')
            async for chunk in response.content.iter_chunked(8192):
                if chunk:
                    f.write(chunk)
        tmp_path.rename(fpath)

    async def download_attachments(
        self,
        pool_id: int,
        out_dir: Union[str, Path],
        skip_existing: bool = True,
    ) -> AsyncIterable[dict]:
        out_dir = Path(out_dir)
        logger.info('download_attachments %s %s', pool_id, out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        async for attachment_info in self.gather('attachments', pool_id=pool_id, limit=100):
            if str(attachment_info['details']['pool_id']) != str(pool_id):
                continue

            db_id = attachment_info['details']['assignment_id'] + '_' + filter_attachment_id(attachment_info['id'])
            fpath = out_dir / db_id

            if '.' in attachment_info['name']:
                fpath = fpath.with_suffix('.' + attachment_info['name'].rsplit('.', 1)[1])

            if skip_existing and not fpath.exists():
                await self.download_attachment(fpath, attachment_info['id'])

            yield {
                'id': db_id,
                'path': fpath.name,
                'attachment_id': attachment_info['id'],
                'assignment_id': attachment_info['details']['assignment_id'],
                'attachment_name': attachment_info['name'],
                'user_id': attachment_info['details']['user_id'],
            }

    # -----------------------------------------------------------------------------
    #                                  SKILLS
    # -----------------------------------------------------------------------------

    async def create_skill(
        self,
        name: str,
        private_comment: Optional[str] = None,
        hidden: bool = True,
        skill_ttl_hours: Optional[int] = None,
    ) -> Dict[str, Any]:
        params = {k: v for k, v in locals().items() if k not in ['params', 'self', 'hidden'] and v is not None}
        params['hidden'] = 'true' if hidden else 'false'
        return await self.post(url='skills', json=params)

    async def get_skill_exact_value(self, user_id: int, skill_id: int) -> Optional[float]:
        try:
            data = await self.get(f'user-skills/{skill_id}', params={'user_id': user_id})
            return data['exact_value']
        except aiohttp.ClientResponseError as exp:
            if exp.status == 404:
                return None
            else:
                raise

    async def get_skill(self, worker_id: int, skill_id: int) -> Optional[float]:
        data = await self.get('user-skills', params={'user_id': worker_id, 'skill_id': skill_id})
        request_response_info = f'response = {data}, worker_id = {worker_id}, skill_id = {skill_id}'

        items = data.get('items', [])
        if not items:
            logger.warning('Couldn\'t extract items from response\n%s', request_response_info)
            return None

        value = items[0].get('value')
        if value is None:
            logger.warning('Couldn\'t extract skill value from response\n%s', request_response_info)
            return None

        return value

    async def set_skill(
        self, users: List[Dict[str, Union[str, float]]], skill_id: int
    ) -> AsyncIterable[Tuple[bool, Union[float, str]]]:
        for item in users:
            worker_id = item.pop('worker_id')
            skill_value = item.pop('skill_value')
            try:
                params = dict(item)
                params['skill_id'] = str(skill_id)
                params['value'] = skill_value
                params['user_id'] = worker_id
                await self.put('user-skills', json=params)
                yield True, worker_id
            except aiohttp.web.HTTPNotFound:
                pass
            except aiohttp.web.HTTPException:
                yield False, worker_id
                logger.error('Can\'t set %s for %s with %s', skill_id, worker_id, skill_value)

    # -----------------------------------------------------------------------------
    #                                  MESSAGE
    # -----------------------------------------------------------------------------

    async def send_message(self, user_id: Union[str, int], text: str, topic: str, answerable: bool = True) -> dict:
        json = {
            'topic': {'RU': topic},
            'text': {'RU': text},
            'recipients_select_type': 'DIRECT',
            'recipients_ids': [str(user_id)],
            'answerable': str(answerable).lower(),
        }
        return await self.post('message-threads/compose', json=json)

    async def get_messages(  # pylint: disable=R0913
        self,
        folder: Optional[str] = None,
        folder_ne: Optional[str] = None,
        sort: str = None,
        limit: Optional[int] = None,
        id_gt: Optional[int] = None,
        id_gte: Optional[int] = None,
        id_lt: Optional[int] = None,
        id_lte: Optional[int] = None,
        created_gt: Optional[str] = None,
        created_gte: Optional[str] = None,
        created_lt: Optional[str] = None,
        created_lte: Optional[str] = None,
    ) -> AsyncIterable:
        params = {k: v for k, v in locals().items() if k not in ['params', 'self'] and v is not None}
        async for item in self.gather('message-threads', **params):
            yield item

    # -----------------------------------------------------------------------------
    #                                  BLOCK
    # -----------------------------------------------------------------------------

    async def get_blocked_users(  # pylint: disable=R0913
        self,
        scope: Optional[str] = None,
        project_id: Optional[Union[str, int]] = None,
        pool_id: Optional[Union[str, int]] = None,
        sort: Optional[str] = None,
        limit: Optional[int] = None,
        id_gt: Optional[int] = None,
        id_gte: Optional[int] = None,
        id_lt: Optional[int] = None,
        id_lte: Optional[int] = None,
        created_gt: Optional[str] = None,
        created_gte: Optional[str] = None,
        created_lt: Optional[str] = None,
        created_lte: Optional[str] = None,
    ) -> AsyncIterable[dict]:
        params = {k: v for k, v in locals().items() if k not in ['params', 'self'] and v is not None}
        async for item in self.gather('user-restrictions', **params):
            yield item

    async def block_user(
        self,
        scope: str,
        user_id: str,
        project_id: Optional[str] = None,
        pool_id: Optional[str] = None,
        private_comment: Optional[str] = None,
        will_expire: Optional[str] = None,
    ) -> Dict[str, str]:
        params = {k: v for k, v in locals().items() if k not in ['params', 'self'] and v is not None}
        return await self.put(url='user-restrictions', json=params)

    async def unblock_user(self, ban_id: str) -> None:
        await self.delete(url=f'user-restrictions/{ban_id}')

    # -----------------------------------------------------------------------------
    #                                  MONEY
    # -----------------------------------------------------------------------------

    async def give_reward(
        self,
        user_id: str,
        amount: float,
        assignment_id: Optional[str] = None,
        private_comment: Optional[str] = None,
        public_title: Optional[str] = None,
        public_message: Optional[str] = None,
        without_message: bool = False,
    ) -> None:
        params = {
            k: v
            for k, v in locals().items()
            if k not in ['params', 'self', 'public_title', 'public_message'] and v is not None
        }
        if public_title is not None:
            params['public_title'] = {'RU': public_title}
        if public_message is not None:
            params['public_message'] = {'RU': public_message}
        await self.post(url='user-bonuses', json=params)

    async def balance(self) -> dict:
        return await self.get('requester')
